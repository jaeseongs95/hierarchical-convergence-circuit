# 계층적 수렴-회로 가설 구현 가능성 점검

`구현가능성_검토.md`를 먼저 읽는다. 기존 v091 source의 교체본이나 v092 실험 배포본이 아니다.

`convergence_probe.py`는 문서의 일부에 대응하는 수치 업데이트를 실제 실행한 작은 시험이다. 실제 인지·학습 성과가 아니다. graph expansion/compilation/plasticity는 이 코드에서 구현하지 않았다.

Python 표준 라이브러리만 사용하며 외부 서버·LLM 호출이 없다.

```text
python -X utf8 -B -m unittest -v test_convergence_probe
python -X utf8 -B convergence_probe.py --out <새_결과파일.json>
```

출력 경로에 기존 파일이 있으면 덮어쓰지 않는다. `dynamics_results.json`은 이번 실행의 실제 수치 결과이고 `tests.log`는 14개 시험 기록이다. `review_receipt.json`은 첨부 문서 및 검토한 v091 내장 ZIP의 해시와 점검 범위다.

파라미터와 synthetic 입력은 검토자가 지정했다. 정답은 kernel 함수 인자가 아니며 결과 뒤의 toy 검증에만 쓰인다. 수렴은 유한 허용오차·지속 시간 기준이고, 모든 가능한 설정에서의 수렴 증명이 아니다. 두 표현 수준도 직접 명세한 숫자 상태이지 학습된 감각/개념 표현이 아니다.
