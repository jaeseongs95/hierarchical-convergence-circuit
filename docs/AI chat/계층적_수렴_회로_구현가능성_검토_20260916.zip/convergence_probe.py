"""계층적 수렴-회로 가설의 좁은 수치 구현 가능성 점검.

문서의 F_M을 확정한 구현이 아니다. 임의로 선택한 bounded 경쟁 업데이트 하나다.
가소성/graph compiler/실제 지각/LLM 추론은 구현하거나 호출하지 않는다.
같은 커널을 모든 표현 수준에 적용하고, 정답은 커널 밖에서만 비교한다.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict, replace
import argparse
import json
import math
from pathlib import Path


@dataclass(frozen=True)
class Config:
    gain: float = .8
    inhibition: float = .4
    beta: float = 4.
    damping: float = .5
    tolerance: float = 1e-9
    stable_window: int = 5
    min_margin: float = .2
    max_steps: int = 1000

    def validate(self) -> None:
        values = (self.gain, self.inhibition, self.beta, self.damping,
                  self.tolerance, self.min_margin)
        if not all(math.isfinite(x) for x in values):
            raise ValueError('설정은 유한값이어야 한다')
        if self.gain < 0 or self.inhibition < 0 or self.beta <= 0:
            raise ValueError('gain/inhibition/beta 범위')
        if not 0 < self.damping <= 1 or self.tolerance <= 0:
            raise ValueError('damping/tolerance 범위')
        if not 0 <= self.min_margin <= 1 or self.stable_window < 1 or self.max_steps < 1:
            raise ValueError('window/margin/budget 범위')


def settle(drives: list[list[float]], coupling: list[list[float]] | None = None,
           initial: list[list[float]] | None = None, cfg: Config = Config()) -> dict:
    """후보 활성화/경쟁/억제/층간 recurrence의 동기 수치 업데이트.

    drives에는 evidence와 prior의 합을 호출자가 명시적으로 넣는다.
    정답, outcome 평가, 학습 update, graph 확장은 함수에 전달하지 않는다.
    부호 있는 coupling[a][b]는 b 수준이 a 수준에 미치는 영향이다.
    결과는 유한 tolerance 관측이며 attractor의 일반 수학적 증명은 아니다.
    """
    cfg.validate()
    if not drives or not drives[0] or len(drives[0]) < 2:
        raise ValueError('각 수준에 후보가 최소 두 개 필요하다')
    levels, count = len(drives), len(drives[0])
    if any(len(row) != count for row in drives) or not all(math.isfinite(v) for r in drives for v in r):
        raise ValueError('입력 차원/유한값 오류')
    weights = [[0.]*levels for _ in drives] if coupling is None else [r[:] for r in coupling]
    if len(weights) != levels or any(len(r) != levels for r in weights):
        raise ValueError('coupling 차원 오류')
    if not all(math.isfinite(v) for r in weights for v in r) or any(weights[a][a] != 0 for a in range(levels)):
        raise ValueError('coupling 유한값/대각 오류')
    x = [[1/count]*count for _ in drives] if initial is None else [r[:] for r in initial]
    if len(x) != levels or any(len(r) != count for r in x):
        raise ValueError('initial 차원 오류')
    if any(any(not math.isfinite(v) or v < 0 for v in r) or abs(sum(r)-1) > 1e-9 for r in x):
        raise ValueError('initial은 확률 simplex 형태의 활성값이어야 한다')
    trajectory = [[r[:] for r in x]]
    consecutive = 0
    delta = math.inf
    for step in range(1, cfg.max_steps+1):
        nxt = []
        for a in range(levels):
            z = [drives[a][i] + cfg.gain*x[a][i]
                 - cfg.inhibition*sum(x[a][j] for j in range(count) if j != i)
                 + sum(weights[a][b]*x[b][i] for b in range(levels))
                 for i in range(count)]
            maximum = max(z)
            expz = [math.exp(cfg.beta*(v-maximum)) for v in z]
            den = sum(expz)
            nxt.append([(1-cfg.damping)*x[a][i]+cfg.damping*expz[i]/den for i in range(count)])
        delta = max(abs(nxt[a][i]-x[a][i]) for a in range(levels) for i in range(count))
        x = nxt
        trajectory.append([r[:] for r in x])
        consecutive = consecutive+1 if delta <= cfg.tolerance else 0
        if consecutive >= cfg.stable_window:
            break
    stable = consecutive >= cfg.stable_window
    margins = [sorted(r, reverse=True)[0]-sorted(r, reverse=True)[1] for r in x]
    winners = [max(range(count), key=lambda i: r[i]) if stable and margins[a] >= cfg.min_margin else None
               for a, r in enumerate(x)]
    status = 'settled' if stable and all(v is not None for v in winners) else 'ambiguous_stable' if stable else 'budget_exhausted'
    return {'status': status, 'stable': stable, 'steps': step, 'state': x, 'margin': margins,
            'winners': winners, 'last_delta': delta, 'trajectory': trajectory}


def demonstrations() -> dict:
    cfg = Config()
    normal = settle([[.6,-.6]])
    basin_a = settle([[0.,0.]], initial=[[.6,.4]])
    basin_b = settle([[0.,0.]], initial=[[.4,.6]])
    tie = settle([[0.,0.]])
    coupling = [[0.,.8],[.8,0.]]
    no_prior = settle([[.2,-.2],[0.,0.]], coupling)
    strong_prior = settle([[.2,-.2],[-1.,1.]], coupling)
    # 외부 evidence의 변화를 모사한 개입이다. 자발적 학습은 아니다.
    lower_corrected = settle([[2.,-2.],[-1.,1.]], coupling, initial=strong_prior['state'])
    # 이 recurrence 약화도 외부에서 정한 개입이다. 학습된 정책이 아니다.
    weakened = replace(cfg, gain=.2, inhibition=.1)
    revised = settle([[2.,-2.],[0.,0.]], coupling, initial=strong_prior['state'], cfg=weakened)
    oscillatory = settle([[0.,0.],[0.,0.]], [[0.,-2.],[-2.,0.]], initial=[[.9,.1],[.9,.1]],
                         cfg=replace(cfg, gain=0., inhibition=0., damping=1., max_steps=40))
    cases = dict(normal=normal, ambiguous_from_A=basin_a, ambiguous_from_B=basin_b,
                 stable_tie=tie, two_levels_no_prior=no_prior, two_levels_strong_prior=strong_prior,
                 stronger_bottom_evidence=lower_corrected, explicit_feedback_and_weakened_recurrence=revised,
                 inhibitory_cycle=oscillatory)
    # 채점은 커널 실행 후, 별도 지정한 toy truth=0과 비교한다.
    return {'contract':'hierarchical-convergence-feasibility-probe-r1', 'config':asdict(cfg),
            'cases':cases, 'external_toy_check':{'truth_index':0,
                'prior_case_lower_correct':strong_prior['winners'][0] == 0,
                'revised_lower_correct':revised['winners'][0] == 0},
            'limits':['합성 입력과 명시적으로 선택한 파라미터다. 인간 감각/직관 또는 LLM 성능 시험이 아니다.',
                      '수렴은 tolerance/window 기준의 수치 판정이다. 임의 설정에서의 수렴 보장이 아니다.',
                      'feedback과 recurrence 약화는 외부에서 정한 개입이다. 학습한 제어 정책이 아니다.',
                      'graph 확장, binding 학습, graph compiler, 구조 가소성, 물리 하드웨어는 구현하지 않았다.'],
            'network_calls':0, 'llm_calls':0, 'changes_to_existing_experiments':False}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    result = demonstrations()
    with args.out.open('x',encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2, allow_nan=False)
    print(json.dumps({k:{p:v[p] for p in ('status','steps','winners','margin')} for k,v in result['cases'].items()},ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
