import unittest
from dataclasses import replace
from copy import deepcopy
from convergence_probe import Config, settle, demonstrations

class FeasibilityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.d = demonstrations()
    def test_normal_converges(self): self.assertEqual(self.d['cases']['normal']['winners'], [0])
    def test_same_input_supports_two_basin_outcomes(self):
        self.assertEqual(self.d['cases']['ambiguous_from_A']['winners'], [0])
        self.assertEqual(self.d['cases']['ambiguous_from_B']['winners'], [1])
    def test_tie_is_not_falsely_a_decision(self):
        self.assertEqual(self.d['cases']['stable_tie']['status'], 'ambiguous_stable')
        self.assertEqual(self.d['cases']['stable_tie']['winners'], [None])
    def test_same_update_function_across_two_levels(self):
        self.assertEqual(self.d['cases']['two_levels_no_prior']['winners'], [0,0])
    def test_wrong_stability_is_not_correctness(self):
        self.assertEqual(self.d['cases']['two_levels_strong_prior']['status'], 'settled')
        self.assertEqual(self.d['cases']['two_levels_strong_prior']['winners'], [1,1])
        self.assertFalse(self.d['external_toy_check']['prior_case_lower_correct'])
    def test_lower_correction_does_not_ensure_upper_correction(self):
        self.assertEqual(self.d['cases']['stronger_bottom_evidence']['winners'], [0,1])
    def test_explicit_intervention_can_escape_previous_state(self):
        self.assertEqual(self.d['cases']['explicit_feedback_and_weakened_recurrence']['winners'], [0,0])
    def test_inhibition_does_not_guarantee_convergence(self):
        self.assertEqual(self.d['cases']['inhibitory_cycle']['status'], 'budget_exhausted')
    def test_small_perturbations_return_same_two_basins(self):
        for x in (.55,.6,.7,.9): self.assertEqual(settle([[0.,0.]],initial=[[x,1-x]])['winners'], [0])
        for x in (.45,.4,.3,.1): self.assertEqual(settle([[0.,0.]],initial=[[x,1-x]])['winners'], [1])
    def test_state_simplex_and_finite(self):
        for case in self.d['cases'].values():
            for state in case['trajectory']:
                for row in state:
                    self.assertAlmostEqual(sum(row),1)
                    self.assertTrue(all(0 <= x <= 1 for x in row))
    def test_input_is_not_mutated(self):
        evidence=[[.2,-.2],[0.,0.]]; initial=[[.6,.4],[.7,.3]]; cp=deepcopy((evidence,initial))
        settle(evidence, initial=initial)
        self.assertEqual((evidence,initial),cp)
    def test_no_answer_argument_to_kernel(self):
        import inspect
        self.assertNotIn('truth',inspect.signature(settle).parameters)
        self.assertNotIn('correct_answer',inspect.signature(settle).parameters)
    def test_bad_dimensions_rejected(self):
        with self.assertRaises(ValueError): settle([[0.,0.]], [[1.]])
        with self.assertRaises(ValueError): settle([[0.,0.],[0.]])
    def test_nonfinite_and_invalid_configs_rejected(self):
        with self.assertRaises(ValueError): settle([[float('nan'),0.]])
        with self.assertRaises(ValueError): settle([[0.,0.]], cfg=replace(Config(),damping=2.))
        with self.assertRaises(ValueError): settle([[0.,0.]], initial=[[.9,.9]])

if __name__=='__main__': unittest.main(verbosity=2)
