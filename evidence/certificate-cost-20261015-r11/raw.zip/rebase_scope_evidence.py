from control import *
import shutil
shutil.copyfile(OP/'baseline.json',OP/'baseline.initial-working-tree.json')
req={'schemaVersion':'1.0.0','mode':'capture','repositoryRoot':str(REPO),'comparisonTarget':'commit','commit':BASE,'taskEnvelope':read(OP/'TASK.json'),'maxFiles':100000}
put(OP/'expanded-capture.request.json',req)
base=json.loads(run(['node',SK/'change-scope-guardian/scripts/capture-workspace-baseline.mjs',OP/'expanded-capture.request.json'],'expanded-capture.actual'))
with (OP/'baseline.json').open('w',encoding='utf-8',newline='\n') as f:json.dump(base,f,ensure_ascii=False,indent=2);f.write('\n')
put(OP/'SCOPE-EXPANSION.actual.json',{'reason':'specific new-launcher LF custody fix requires one .gitattributes rule; current user implementation/commitpush scope implies routine delivery fix',
 'original_baseline_preserved':True,'old_baseline_verified_clean_at_BASE':BASE,
 'new_baseline_kind':'read-only immutable original BASE commit under expanded explicit task; not a synthetic working tree',
 'new_baseline_digest':base['manifestSha256'],'first_old_baseline_task_mismatch_preserved':True,'utc':now()})
cp=OP/'control.py';s=cp.read_text(encoding='utf-8')
# Subsequent scope comparisons cover committed work against the immutable original source commit.
s=s.replace("'comparisonTarget':'working-tree','taskEnvelope':task,'baseline':base", "'comparisonTarget':'commit','commit':'HEAD','taskEnvelope':task,'baseline':base")
cp.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps({'baseline':base['manifestSha256'],'kind':'original BASE commit'}))
