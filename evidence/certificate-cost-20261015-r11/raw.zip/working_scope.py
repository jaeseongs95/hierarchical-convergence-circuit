from control import *
import shutil
assert not run(['git','status','--porcelain'],'post-fix-clean').strip()
files=run(['git','diff','--name-only',BASE,'HEAD'],'post-fix-files').splitlines()
allowed={'.gitattributes','Run-HCR-Certificate-Cost.cmd','tools/analysis/termination_certificate_cost.py','tools/analysis/test_certificate_cost.py'}
assert all(p in allowed or p.startswith(REL+'/') for p in files),files
for ref in read(OP/'source-pins.json'):assert sha(REPO/ref['path'])==ref['sha256']
put(OP/'launcher-fix.manual-scope.json',{'verdict':'PASS_direct_exact_diff','base':BASE,'head':run(['git','rev-parse','HEAD'],'post-fix-head').strip(),
 'paths':files,'old_sourcepins_exact':True,'formal_scope_receipt':'initial6filePASS; first expansion rejected expected task digest; no retroactive rebind',
 'next_baseline':'fresh current clean working-tree under expanded task for future result unit only',
 'commit_capture_aborted':'42091 entries would spawn per-file git-show commands; owned read-only node terminated, no science/helper mutation',
 'utc':now()})
req={'schemaVersion':'1.0.0','mode':'capture','repositoryRoot':str(REPO),'comparisonTarget':'working-tree','taskEnvelope':read(OP/'TASK.json'),'maxFiles':100000}
put(OP/'expanded-working-capture.request.json',req)
base=json.loads(run(['node',SK/'change-scope-guardian/scripts/capture-workspace-baseline.mjs',OP/'expanded-working-capture.request.json'],'expanded-working-capture.actual'))
with (OP/'baseline.json').open('w',encoding='utf-8',newline='\n') as f:json.dump(base,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'new_working_baseline':base['manifestSha256'],'direct_path_check':'PASS'}))
