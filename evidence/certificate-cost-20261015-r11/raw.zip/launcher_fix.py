from control import *
import shutil
p=REPO/'Run-HCR-Certificate-Cost.cmd';working=p.read_bytes()
r=subprocess.run(['git','show','origin/main:Run-HCR-Certificate-Cost.cmd'],cwd=REPO,capture_output=True);assert r.returncode==0
assert b'\r\n' in working and b'\r' not in r.stdout and working.replace(b'\r\n',b'\n')==r.stdout
assert not (OP/'run').exists()
put(OP/'LAUNCHER-DIAGNOSIS.actual.json',{'status':'CAUSE_CONFIRMED','symptom':'remote byte check fails and pre-launch contract rejects r11 code pin',
 'mechanism':'text=auto plus local Git checkout converts new launcher LF -> CRLF; committed blob remains LF',
 'direct_discriminator':'working.replace(CRLF,LF)==origin/main blob; all other source pins checked separately',
 'working_sha256':hashlib.sha256(working).hexdigest(),'remote_blob_sha256':hashlib.sha256(r.stdout).hexdigest(),
 'remote_push_already_succeeded':True,'initial_implementation_commit':'226f77ca512d1edde6961f011f3a6ab80817b6ca',
 'scientific_cells_started':0,'failed_prelaunch_preserved':True,'utc':now()})
task=read(OP/'TASK.json');shutil.copyfile(OP/'TASK.json',OP/'TASK.initial.json')
task['scope']['excluded'].remove('.gitattributes');task['scope']['included'].append('.gitattributes')
task['workUnits'][0]['writeTargets'].append('.gitattributes')
task['constraints'].append('Only new launcher gets exact LF transport rule; old launcher/raw/numerics unchanged')
with (OP/'TASK.json').open('w',encoding='utf-8',newline='\n') as f:json.dump(task,f,ensure_ascii=False,indent=2);f.write('\n')
run(['git','branch','-m','research/certificate-cost-launcher-fix'],'fix-branch-rename')
attributes=REPO/'.gitattributes';before=attributes.read_bytes();newline=b'\r\n' if b'\r\n' in before else b'\n'
assert b'Run-HCR-Certificate-Cost.cmd' not in before
attributes.write_bytes(before+b'Run-HCR-Certificate-Cost.cmd text eol=lf'+newline)
p.write_bytes(r.stdout)
for ref in read(PUB/'execution-contract.json')['code_pins']:assert sha(REPO/ref['path'])==ref['sha256'],ref['path']
cfg=read(PUB/'execution-contract.json');shutil.copyfile(PUB/'execution-contract.json',OP/'execution-contract.pre-launcher-fix.json')
cfg.update(revision=4,previous_preexecution_contract_sha256=sha(PUB/'execution-contract.json'),
 transport_pins=[{'path':'.gitattributes','sha256':sha(attributes),'bytes':attributes.stat().st_size}],
 transport_correction='new launcher exact LF rule; prelaunch failure0scientificcells; numerical code pins unchanged',freeze_utc=now())
with (PUB/'execution-contract.json').open('w',encoding='utf-8',newline='\n') as f:json.dump(cfg,f,ensure_ascii=False,indent=2);f.write('\n')
put(PUB/'launcher-custody-fix.json',{'schema':'HCCLauncherCustodyFix.v1','status':'CORRECTED_BEFORE_FIRST_SCIENTIFIC_CELL',
 'failure':'initial push readback .cmd EOL mismatch; initial --execute refused before creating output/run',
 'cause':'Git checkout text=auto transformation','fix':'one exact launcher LF attribute, original numerical code unchanged',
 'previous_contract_sha256':cfg['previous_preexecution_contract_sha256'],'current_contract_sha256':sha(PUB/'execution-contract.json'),
 'old_implementation_commit':'226f77ca512d1edde6961f011f3a6ab80817b6ca','scientific_retry_count':0})
run(['cmd.exe','/d','/c','Run-HCR-Certificate-Cost.cmd'],'launcher-fixed-selftest')
print(json.dumps({'status':'fixed','science_started':False,'contract_sha':sha(PUB/'execution-contract.json')}))
