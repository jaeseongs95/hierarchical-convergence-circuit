from control import *
def canonical(o):return json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
task=read(OP/'TASK.json');files=run(['git','diff','--name-only',BASE,'HEAD'],'final.changed-files').splitlines()
allowed={'.gitattributes','Run-HCR-Certificate-Cost.cmd','tools/analysis/termination_certificate_cost.py','tools/analysis/test_certificate_cost.py','README.md'}
assert files and all(p in allowed or p.startswith(REL+'/') for p in files)
for ref in read(PUB/'execution-contract.json')['code_pins']:assert sha(REPO/ref['path'])==ref['sha256']
manifest=[{'path':p,'sha256':sha(REPO/p),'bytes':(REPO/p).stat().st_size} for p in files]
put(OP/'FINAL.manifest.json',manifest);target='sha256:'+hashlib.sha256(canonical(manifest)).hexdigest()
head=run(['git','rev-parse','HEAD'],'final.head').strip();assert head==read(OP/'results.delivery.json')['head']
assert not run(['git','status','--porcelain'],'final.clean').strip()
assert read(OP/'run/study/verification/result.json')['status']=='PASS'
assert read(OP/'results.scope.json')['verdict']=='PASS'
assert read(OP/'run/execution-end.json')['supervision']['active_processes']==0
facts=[(PUB/'execution-contract.json',['AC-001','AC-003'],'Final source/recipe/model/cold3order/perpolicy1800/global6900 frozen before first actual scientific cell; zero retry'),
 (PUB/'deliberation-summary.json',['AC-001'],'Two blind failure-functions, conditional cross-exam; partial integration/inheritedmodelunknown, existing source/result followup not independent'),
 (PUB/'pre-execution-verification.json',['AC-002'],'Analytic5PASS, same-test isolated2eps->eps mutation detected; original full-suite timing limitation preserved'),
 (PUB/'post-execution-verification.json',['AC-001','AC-002'],'Historical precheck contract and final custody-amended contract bridged by exact unchanged code-pin set and actual current source verification'),
 (PUB/'launcher-custody-fix.json',['AC-001','AC-005'],'First push readback and prelaunch pin failure preserved; exact new launcher LF rule fixed with zero scientific cells'),
 (OP/'run/execution-start.json',['AC-003'],'One actual explicit outer Job launch, frozen contract binding, no automatic retry'),
 (OP/'run/execution-end.json',['AC-003'],'Actual outer physical wall and overlapping CPU accounting, inactive0, overrun flag'),
 (OP/'run/study/verification/result.json',['AC-002','AC-004'],'All C1 cadence original predicates/tick continuity/attempt completeness, common whole7/canonical success certificate equality; no nonlinear prefix replay'),
 (PUB/'comparison.json',['AC-003','AC-004'],'All3 denominators/candidate outcomes, disjoint phasewallCPU and unattributed, actual costs and counters, oldr10 attribution limit'),
 (PUB/'raw-manifest.json',['AC-003','AC-005'],'Source/raw/counter/phase/seal/evaluation/failure-record bundle all inventory sizehashCRC verified'),
 (PUB/'report.ko.md',['AC-004'],'Numeric negative-only dominance and fixedmodel domain, currentobservations not general causal/universal/adoption claims'),
 (OP/'results.scope.json',['AC-005'],'Fresh expanded working baseline resultunit scopePASS; original6scope and custody direct exact diff tracked separately'),
 (OP/'launcher-fix.manual-scope.json',['AC-005'],'Exact final implementation/custody diff paths checked against originalBASE and original sourcepins preserved; not retroactive formal rebind'),
 (OP/'implementation.verify-signature.json',['AC-005'],'Implementation OpenPGP actualgood signature'),
 (OP/'launcher-fix.verify-signature.json',['AC-005'],'Custodyfix OpenPGP actualgood signature'),
 (OP/'results.verify-signature.json',['AC-005'],'Results OpenPGP actualgood signature'),
 (OP/'results.delivery.json',['AC-005'],'Ordinary origin/main push/readback/newrawbytes exact except .gitattributes preexistingCRLF canonicalizedLF, clean')]
evidence=[]
for p,ids,msg in facts:
    assert p.is_file()
    if p.name.endswith('verify-signature.json'):
        r=read(p);assert r['exit_code']==0 and 'Good signature' in r['stderr']
    evidence.append({'id':'E'+str(len(evidence)+1),'kind':'document','locator':str(p),'digest':'sha256:'+sha(p),
     'targetDigest':target,'verified':True,'criterionIds':ids,'direction':'supports','observedResult':msg})
request={'schemaVersion':'1.0.0','taskEnvelope':task,'target':{'kind':'commit','identifier':head,'digest':target},
 'evidence':evidence,'verificationCommands':[],'criterionOverrides':[],
 'knownLimitations':['single selected graph/allopen authoredsynthetic world; discovery0; no fullEngine/adoption/generalaccuracy',
 'eachvariantonce, randomizedorderonce notbalancedreplicate; hostloaduncontrolled; no statistical speed claim',
 'r10 time difference notcausallyidentified; newphases currentobserved accounting only',
 'C1 exactsuccess/predicate for fixeddefinedmodel; fullnegativeproof omitted; no errorlowerbound or arbitrarymodel exception equivalence',
 'sharednumerichelpers/acceptedoldanchor; no nonlinear fullprefix replay; energy/RSSunknown',
 'firstprelauncherror cooperative tool-output summary not originalseparate rawreceipt; allactualscience3singleattempts no retry',
 'scope old6PASS/custody directdiff/freshpostfixbaseline separated, commitfilescanaborted; no retroactivebaseline rebind',
 'originalfullsuite24PASS1timingfailure preserved; newanalytic5PASS and targetedmutation only',
 'dotreplyNOT_OBSERVED in limitedrecentcoverage/statusunknown, no duplicateresend; inheritedactualmodelunknown']}
put(OP/'ACCEPTANCE.request.json',request);tool=SK/'acceptance-evidence-validator/scripts'
report=json.loads(run(['node',tool/'cli.mjs','--input',OP/'ACCEPTANCE.request.json'],'ACCEPTANCE-RUN'))
put(OP/'ACCEPTANCE.actual.json',report);assert report['verdict']=='PASS',report
pin={'artifactId':'certificate-cost-acceptance-'+head[:8],
 'schemaId':'https://agent-governance-skills.local/acceptance-evidence-validator/contracts/acceptance-evidence-input.v1.schema.json',
 'locator':str(OP/'ACCEPTANCE.request.json'),'digest':'sha256:'+hashlib.sha256(canonical(request)).hexdigest()}
put(OP/'ACCEPTANCE.request-pin.json',pin)
check=json.loads(run(['node',tool/'validate-report.mjs','--request',OP/'ACCEPTANCE.request.json','--request-artifact',OP/'ACCEPTANCE.request-pin.json','--report',OP/'ACCEPTANCE.actual.json'],'ACCEPTANCE-VALIDATE-RUN'))
put(OP/'ACCEPTANCE-VALIDATE.actual.json',check);assert check['valid']
print(json.dumps({'verdict':'PASS','valid':True,'criteria':5,'head':head}))
