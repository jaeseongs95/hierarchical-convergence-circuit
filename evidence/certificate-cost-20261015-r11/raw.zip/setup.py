from pathlib import Path
import json, subprocess, hashlib
OP=Path(__file__).resolve().parent
REPO=Path('D:/codex/리드/ai-research-resume-20261008-r01/repository')
SK=Path('C:/Users/Lenovo/.codex/plugins/cache/agent-governance/agent-governance-suite/2.9.0/skills')
REL='evidence/certificate-cost-20261015-r11'
BASE='34650ccb5444e2d4dd72a64e8b68989ddd972a27'
def put(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
def run(a):
    p=subprocess.run(a,cwd=REPO,capture_output=True,text=True,encoding='utf-8');assert p.returncode==0,p.stderr;return p.stdout
assert run(['git','rev-parse','HEAD']).strip()==BASE
assert not run(['git','status','--porcelain']).strip()
task=json.loads(Path('D:/codex/리드/ai-termination-sixcell-20261015-r10/TASK.json').read_text(encoding='utf-8'))
task.update(taskId='ai-certificate-cost-20261015-r11',objective='C/F 비용 원인 phase분해와 현재잔차 음성필터의 동일정보/총예산 검증',
 scope={'included':[REL+'/**','tools/analysis/termination_certificate_cost.py','tools/analysis/test_certificate_cost.py','Run-HCR-Certificate-Cost.cmd','README.md'],
        'excluded':['src/**','HCR-Evidence/**','archive/**','configs/**','.github/**','experiments/**','.gitattributes','tools/analysis/termination_compare_core.py','tools/analysis/termination_compare_runner.py','tools/analysis/check_termination_comparison.py','tools/analysis/test_termination_comparison.py']},
 workUnits=[{'id':'implementation','objective':'토론·비용분해/음성필터·동결/검증','dependencies':[],'writeTargets':[REL+'/**','tools/analysis/termination_certificate_cost.py','tools/analysis/test_certificate_cost.py','Run-HCR-Certificate-Cost.cmd']},{'id':'results','objective':'cold3셀/후검산/비교보고','dependencies':['implementation'],'writeTargets':[REL+'/**','README.md']}],
 acceptanceCriteria=['[AC-001] 독립토론/교차검토·source/정보/예산 사전동결','[AC-002] 음성전용 prefilter 현재입력/성공인증식 보존 검증','[AC-003] C0/C1/F cold단회 동일1800총6900·phase비용·실패보존','[AC-004] 모든cadence predicate/공통whole7/성공certificate/world 사후검산과 원인한계','[AC-005] rawbundle/hash/범위/작업단위GPGcommitpush·원격clean'],
 constraints=['samegraph/model/grid30/cadence16/eps1e-6/radius1e-5/tickcap6144','F/C0/C1 cold각1800 setup180 eval120 cleanup10 analysis600 global6900; repeat0','no oldorbit/anchor/truth in policy, world/anchor postseal only','R081closed/native/fullEngine/API/Cloud/install/globalconfig0'],
 authorization={'allowedActions':['bounded3coldcells','scopeimplementation/evidence','signedcommit/mainFF/localbranchdelete/ordinaryoriginmainpush/readback'],'prohibitedActions':['forcepush','deploy','globalconfig','native','R081resume','paidAPI'],'approvalRequired':[]})
put(OP/'TASK.json',task)
req={'schemaVersion':'1.0.0','mode':'capture','repositoryRoot':str(REPO),'comparisonTarget':'working-tree','taskEnvelope':task,'maxFiles':100000}
put(OP/'capture.request.json',req)
baseline=json.loads(run(['node',str(SK/'change-scope-guardian/scripts/capture-workspace-baseline.mjs'),str(OP/'capture.request.json')]))
put(OP/'baseline.json',baseline)
run(['git','switch','-c','research/certificate-cost-implementation'])
(REPO/REL).mkdir(parents=True,exist_ok=False)
old=Path('D:/codex/리드/ai-termination-sixcell-20261015-r10/control.py').read_text(encoding='utf-8')
# Reuse the proven receipt/preflight/delivery paths; prepare is never invoked here.
old=old.replace('ai-termination-sixcell-20261015-r10','ai-certificate-cost-20261015-r11').replace('termination-sixcell-20261015-r10','certificate-cost-20261015-r11').replace("BASE='0adb9d359d680d029ec636afbf5e505723e6d7ee'",f"BASE='{BASE}'")
old=old.replace('이제 구현한 비교기로 같은 graph의 실제 6셀 실험을 실행하고 세 종료정책의 정확도·커버리지·예산을 비교해줘.','C가 더 적은 tick으로 끝나도 F보다 느린 원인을 분석하고, 인증 비용을 줄이는 방법을 같은 정보·총예산 조건에서 검증해줘.')
with (OP/'control.py').open('x',encoding='utf-8',newline='\n') as f:f.write(old)
pins=json.loads(Path('D:/codex/리드/ai-termination-sixcell-20261015-r10/source-pins.json').read_text(encoding='utf-8'))
put(OP/'source-pins.json',pins)
put(OP/'TEST-PLAN.json',{'requirements':['negative filter cannot suppress certified predicate','geometry/input failures preserved','exact successful certificate','information barrier','budget interruption'],
 'cases':['analytic zero-model cert/equality boundary','negative residual upper rejection','malformed geometry','source pins','expired clock','original pending-C test .8s limitation retained'],
 'oracle':'exact Fraction analytic model + unchanged original certificate; new sealed current-state predicates afterrun',
 'scope':'stdlib unittest; no original full-suite repeat until affected evidence justifies','mutation':'isolated threshold 2eps -> eps detects boundary false rejection'})
print(json.dumps({'baseline':baseline['manifestSha256'],'branch':'research/certificate-cost-implementation'}))
