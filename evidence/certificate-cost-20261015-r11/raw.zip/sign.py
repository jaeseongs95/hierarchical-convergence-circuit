from control import *
unit=sys.argv[1];branch='research/certificate-cost-'+unit
assert run(['git','branch','--show-current'],unit+'.sign-branch').strip()==branch
files=[REL,'tools/analysis/termination_certificate_cost.py','tools/analysis/test_certificate_cost.py','Run-HCR-Certificate-Cost.cmd'] if unit=='implementation' else [REL,'README.md']
if unit=='launcher-fix':files=[REL,'.gitattributes','Run-HCR-Certificate-Cost.cmd']
for ref in read(OP/'source-pins.json'):assert sha(REPO/ref['path'])==ref['sha256']
run(['git','add','--']+files,unit+'.add');run(['git','diff','--cached','--check'],unit+'.diff-check')
message='research: freeze profiled certificate residual filter comparison' if unit=='implementation' else 'research: report certificate cost controlled comparison'
if unit=='launcher-fix':message='fix: preserve certificate cost launcher frozen LF bytes'
run(['git','-c','gpg.format=openpgp','-c','gpg.program=C:/Program Files/Git/usr/bin/gpg.exe','-c','user.signingkey=AB7B6A55CA1AC0E6761502B5968D3ABAD2FE4B3A','commit','-S','-m',message],unit+'.commit')
head=run(['git','rev-parse','HEAD'],unit+'.signed-head').strip()
run(['git','-c','gpg.program=C:/Program Files/Git/usr/bin/gpg.exe','verify-commit',head],unit+'.verify-signature')
run(['git','switch','main'],unit+'.switch-main');run(['git','merge','--ff-only',branch],unit+'.main-ff');run(['git','branch','-d',branch],unit+'.delete-branch')
print(json.dumps({'unit':unit,'signed_commit':head,'main_ff':True,'branch_deleted':True}),flush=True)
