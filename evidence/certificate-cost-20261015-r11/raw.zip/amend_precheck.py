from control import *
import shutil
assert not (OP/'run').exists()
old=read(PUB/'execution-contract.json');shutil.copyfile(PUB/'execution-contract.json',OP/'execution-contract.pre-review.json')
shutil.copyfile(PUB/'pre-execution-verification.json',OP/'pre-execution-verification.pre-review.json')
shutil.copyfile(OP/'FREEZE.actual.json',OP/'FREEZE.pre-review.json')
run([PY,'-B','-X','utf8',REPO/'tools/analysis/test_certificate_cost.py'],'analytic-reviewed-green')
probe=OP/'mutation-reviewed';shutil.copytree(OP/'mutation',probe)
shutil.copyfile(REPO/'tools/analysis/test_certificate_cost.py',probe/'test_certificate_cost.py')
r=subprocess.run([str(PY),'-B','-X','utf8',str(probe/'test_certificate_cost.py')],capture_output=True,text=True,encoding='utf-8')
put(OP/'analytic-reviewed-mutation.json',{'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'same_test_sha':sha(probe/'test_certificate_cost.py')==sha(REPO/'tools/analysis/test_certificate_cost.py')})
assert r.returncode and 'test_equality_must_not_screen' in r.stderr
prior=sha(PUB/'execution-contract.json')
for ref in old['code_pins']:
    if ref['path']=='tools/analysis/test_certificate_cost.py':ref.update(sha256=sha(REPO/ref['path']),bytes=(REPO/ref['path']).stat().st_size)
old.update(revision=2,previous_preexecution_contract_sha256=prior,
 preexecution_amendment='review found all-cadence coverage needed independent tick-count/attempt/stop binding; added before science, no numeric policy change',freeze_utc=now())
with (PUB/'execution-contract.json').open('w',encoding='utf-8',newline='\n') as f:json.dump(old,f,ensure_ascii=False,indent=2);f.write('\n')
pre=read(PUB/'pre-execution-verification.json');pre.update(freeze_sha256=sha(PUB/'execution-contract.json'),coverage_review_fix='independent tick count, attempt continuity, stop binding; partial verification explicit')
with (PUB/'pre-execution-verification.json').open('w',encoding='utf-8',newline='\n') as f:json.dump(pre,f,ensure_ascii=False,indent=2);f.write('\n')
put(OP/'FREEZE.reviewed.json',{'contract_sha256':sha(PUB/'execution-contract.json'),'previous_sha256':prior,'science_started':False,'utc':now()})
print(json.dumps({'analytic':5,'mutation_detected':True,'freeze_sha':sha(PUB/'execution-contract.json')}))
