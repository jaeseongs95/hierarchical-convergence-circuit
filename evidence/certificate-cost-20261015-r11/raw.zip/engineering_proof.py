from control import *
import shutil
assert read(OP/'run/execution-end.json')['supervision']['active_processes']==0
work=OP/'engineering-proof';work.mkdir(exist_ok=False)
names=['termination_certificate_cost.py','termination_compare_core.py','termination_compare_runner.py',
       'check_termination_comparison.py','check_on_basins.py','check_on_fixed_points.py',
       'check_on_convergence_gate.py','check_on_online_convergence_gate.py','test_certificate_cost.py']
for name in names:shutil.copyfile(REPO/'tools/analysis'/name,work/name)
put(work/'files.json',names)
cli=SK/'test-engineering/scripts/run.mjs'
def command(args,name,expected=0):
    argv=['node',str(cli)]+list(map(str,args));r=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
    put(work/(name+'.command.json'),{'argv':argv,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'utc':now()})
    assert r.returncode==expected,(name,r.stderr)
    result=json.loads(r.stdout)
    with (work/(name+'.json')).open('x',encoding='utf-8',newline='\n') as f:f.write(r.stdout)
    return result
argv=[str(PY),'-B','-X','utf8','test_certificate_cost.py']
plan={'schemaVersion':'1.0.0','kind':'engineering-test-plan','taskId':'r11-current-analytic-boundary',
 'contractDigest':'sha256:'+sha(OP/'TASK.json'),'requirements':['COST-BOUNDARY'],
 'scopeFiles':names,'runner':'existing stdlib unittest (same frozen five tests)',
 'environment':'Windows bundled Python; local unsigned receipt, not host attestation',
 'cases':[{'id':'analytic-boundary','requirementIds':['COST-BOUNDARY'],
  'scenario':'exact zero-model success, equality2eps, negative-only, geometry, sourcepin/budget boundary',
  'entryPoint':'screened_certificate via unchanged frozen unittest', 'level':'unit',
  'expectedBehavior':'all five pass; isolated false rejection threshold must fail equality',
  'oracle':'hand exact G=0,H=0,v=r analytic bound and unchanged original certificate',
  'testFiles':['test_certificate_cost.py'],'required':True,'sensitivity':'mutation',
  'sensitivityReason':'strict rejection threshold 2eps -> eps falsely rejects certified equality', 'argv':argv}],
 'exclusions':['scientific rerun','operating poller','full Engine','generic arbitrary-model exception equivalence','external environment/interpreter attestation']}
put(work/'plan.json',plan)
planned=command(['check-plan','--root',work,'--plan','plan.json'],'plan-check')
p=work/'termination_certificate_cost.py';original=p.read_bytes();text=original.decode('utf-8')
assert text.count('if max(r)>2*core.EPSILON:')==1
p.write_text(text.replace('if max(r)>2*core.EPSILON:','if max(r)>core.EPSILON:'),encoding='utf-8',newline='\n')
command(['snapshot','--root',work,'--files','files.json'],'red-snapshot')
red=command(['run','--root',work,'--snapshot','red-snapshot.json','--timeout-ms','30000','--']+argv,'red',1)
assert red['status']=='FAIL' and 'test_equality_must_not_screen' in red['stderr'] and 'AssertionError' in red['stderr']
p.write_bytes(original)
snapshot=command(['snapshot','--root',work,'--files','files.json'],'green-snapshot')
green=command(['run','--root',work,'--snapshot','green-snapshot.json','--timeout-ms','30000','--']+argv,'green')
assert green['status']=='PASS'
proof={'schemaVersion':'1.0.0','kind':'engineering-test-proof','planDigest':planned['planDigest'],
 'candidate':snapshot,'proofs':[{'caseId':'analytic-boundary','status':'DEMONSTRATED',
  'red':{'path':'red.json','digest':'sha256:'+sha(work/'red.json')},
  'green':{'path':'green.json','digest':'sha256:'+sha(work/'green.json')},
  'mutationPaths':['termination_certificate_cost.py'],'assertionWitness':'test_equality_must_not_screen',
  'reason':'Actual isolated production mutation only, identical test bytes and argv, red followed by green; no science repeated'}]}
put(work/'proof.json',proof)
result=command(['check-proof','--root',work,'--plan','plan.json','--proof','proof.json'],'proof-check')
assert result['verdict']=='CONSISTENT'
for name in names:assert sha(work/name)==sha(REPO/'tools/analysis'/name)
put(OP/'ENGINEERING-PROOF.actual.json',{'plan':'engineering-proof/plan.json','proof':'engineering-proof/proof.json',
 'result':result,'source_candidates_equal_repo':True,'same_tests_as_prefreeze':True,
 'additional_run_reason':'complete canonical current test/candidate/receipt binding not captured by earlier cooperative precheck receipts',
 'scientific_retries':0,'unsigned_local_consistency_only':True,'utc':now()})
print(json.dumps({'verdict':result['verdict'],'same_source':True,'science_rerun':False}))
