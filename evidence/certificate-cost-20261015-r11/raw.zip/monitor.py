from pathlib import Path
import json
OP=Path(__file__).resolve().parent
out=OP/'run';rows=[]
for v in ('F','C0','C1'):
    p=out/'study'/v;states=list(p.glob('state-*.json')) if p.exists() else []
    row={'variant':v,'highest_file_tick_NOT_ACK':max((int(f.stem.split('-')[1]) for f in states),default=None)}
    sealed=p/'row.json'
    if sealed.exists():
        s=json.loads(sealed.read_text(encoding='utf-8'));row.update(status=s['status'],wall=s['policy_supervision']['wall_seconds_after_report'])
        if (p/'sealed-cell.json').exists():
            c=json.loads((p/'sealed-cell.json').read_text(encoding='utf-8'));row['last_committed_tick']=c['last_complete']['snapshot']['tick'] if c['last_complete'] else None
    rows.append(row)
print(json.dumps({'rows':rows,'verification_started':(out/'study/verification').exists(),'summary_sealed':(out/'study/summary.json').exists(),'execution_sealed':(out/'execution-end.json').exists()}))
