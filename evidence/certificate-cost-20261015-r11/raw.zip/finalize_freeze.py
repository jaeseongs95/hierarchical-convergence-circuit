from control import *
import shutil
sys.path.insert(0,str(REPO/'tools/analysis'))
import termination_compare_runner as r
from fractions import Fraction as Q
cfg=read(PUB/'execution-contract.json')
public=r.prepare_input(REPO,read(REPO/PLAN));model=r.validate_input(public)
b=list(map(Q,model['b']));G=[list(map(Q,row)) for row in model['G']]
bounds=[abs(b[i])+sum(map(abs,G[i])) for i in range(7)]
assert max(bounds)<49
prior=sha(PUB/'execution-contract.json');shutil.copyfile(PUB/'execution-contract.json',OP/'execution-contract.revision2.json')
cfg.update(revision=3,previous_preexecution_contract_sha256=prior,
 model_digest=r.core.digest(model),model_global_preactivation_bounds=list(map(str,bounds)),
 fixed_model_Taylor_domain_proof='All valid current/region coordinates |x|<1 imply |b+Gx|<=row bound<49; exp_positive(2|u|)<98=degree96+2.',
 predicate_equivalence_scope='fixed validated model where original arithmetic defined; not general exception behavior for arbitrary G',freeze_utc=now())
with (PUB/'execution-contract.json').open('w',encoding='utf-8',newline='\n') as f:json.dump(cfg,f,ensure_ascii=False,indent=2);f.write('\n')
shutil.copyfile(PUB/'pre-execution-verification.json',OP/'pre-execution-verification.revision2.json')
pre=read(PUB/'pre-execution-verification.json');pre.update(freeze_sha256=sha(PUB/'execution-contract.json'),fixed_model_Taylor_domain=True,model_digest=cfg['model_digest'])
with (PUB/'pre-execution-verification.json').open('w',encoding='utf-8',newline='\n') as f:json.dump(pre,f,ensure_ascii=False,indent=2);f.write('\n')
put(PUB/'deliberation-summary.json',{'schema':'HCCDeliberationExecutionSummary.v1','not_canonical_attested_DecisionRecord':True,
 'case':'C wall vs F and predicate-preserving certificate cost filter','risk':'MEDIUM','execution_assurance':'degraded_ok','assurance':'partially_independent',
 'workers':[{'id':'/root/cert_cost_r11','role':'numeric cost/predicate invariants','blind_round1':True,'fork_turns':'none','delegation_allowed':False},
            {'id':'/root/cert_fairness_r11','role':'budget/causal validity','blind_round1':True,'fork_turns':'none','delegation_allowed':False}],
 'actual_model_and_effort':'UNKNOWN inherited; no Astra override','fresh_judge':None,'specialist':None,'reserve_used':False,
 'cross_examination':[{'id':'X1','reviewer':'/root/cert_fairness_r11','origin':'cost','trigger':'negative prefilter hidden premise/denominator fairness','outcome':'conditional accept strict upper-witness dominance; equality/geometry/context preserved; exact negative witness not equivalent'},
                      {'id':'X2','reviewer':'/root/cert_cost_r11','origin':'fairness','trigger':'6900 total vs repeated1800 cells; predicate coverage','outcome':'single3cell frozen, allcadence source fix, fixedmodel Taylor bound checked'}],
 'coordinator_verified':['r10 counters and source cost paths','v=r+Kv>=r logic','reservation180+3*(1800+120+10)+600=6570','analytic5PASS and isolated threshold mutation detected','allcadence completeness now tied to independent tick/attempt/stop','fixed model row bound<49'],
 'consensus':'conditional_consensus','conditions':['allC1cadence original recheck','common full7 and successful certificate exact','observed wall only, no universal speed claim'],
 'non_independent_followup':'existing cost reviewer reviewed candidate source; coordinator integrated, not fresh review',
 'scope_notes':['No physics launched before frozen signed implementation','No new independent graph/discovery','No error-lower-bound interpretation','Generic exception equivalence not claimed'],
 'dot':'prior original advice NOT_OBSERVED in latest2turn coverage; hasMore true; previous unknown status not resend; no new advice message sent',
 'contract_sha256':sha(PUB/'execution-contract.json'),'utc':now()})
put(OP/'FREEZE.final.json',{'contract_sha256':sha(PUB/'execution-contract.json'),'source_pins':cfg['code_pins'],'model_bounds':list(map(str,bounds)),'science_started':False,'utc':now()})
print(json.dumps({'contract_sha':sha(PUB/'execution-contract.json'),'max_model_bound':str(max(bounds)),'science_started':False}))
