from control import *
import secrets, shutil
new=['tools/analysis/termination_certificate_cost.py','tools/analysis/test_certificate_cost.py','Run-HCR-Certificate-Cost.cmd']
# Preserve launcher's bytes as committed Git canonical bytes; cmd accepts LF.
assert (REPO/new[2]).read_bytes().count(b'\r')==0
green=run([PY,'-B','-X','utf8',REPO/new[2].replace('Run-HCR-Certificate-Cost.cmd','tools/analysis/test_certificate_cost.py')],'analytic-green')
probe=OP/'mutation';probe.mkdir(exist_ok=False)
names=list((REPO/'tools/analysis').glob('*.py'))
for p in names:shutil.copyfile(p,probe/p.name)
p=probe/'termination_certificate_cost.py';source=p.read_text(encoding='utf-8')
assert source.count('if max(r)>2*core.EPSILON:')==1
p.write_text(source.replace('if max(r)>2*core.EPSILON:','if max(r)>core.EPSILON:'),encoding='utf-8',newline='\n')
r=subprocess.run([str(PY),'-B','-X','utf8',str(probe/'test_certificate_cost.py')],capture_output=True,text=True,encoding='utf-8')
put(OP/'analytic-threshold-mutation.json',{'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,
 'isolated':True,'test_sha':sha(probe/'test_certificate_cost.py'),'original_test_sha':sha(REPO/new[1]),
 'mutation':'2eps strict reject threshold -> eps','observed_utc':now()})
assert r.returncode!=0 and 'test_equality_must_not_screen' in r.stderr and 'AssertionError' in r.stderr
assert sha(probe/'test_certificate_cost.py')==sha(REPO/new[1])
order=['F','C0','C1'];seed=secrets.token_hex(16)
import random
random.Random(seed).shuffle(order)
impl=read(REPO/IMPL);pins=list(read(OP/'source-pins.json'))
for rel in new:pins.append({'path':rel,'sha256':sha(REPO/rel),'bytes':(REPO/rel).stat().st_size})
for ref in pins:assert sha(REPO/ref['path'])==ref['sha256']
cfg={'schema':'HCCCertificateCostExecutionContract.v1','source_commit':BASE,
 'plan_sha256':sha(REPO/PLAN),'implementation_sha256':sha(REPO/IMPL),'code_pins':pins,
 'variants':['F','C0','C1'],'sequential_order':order,'order_seed':seed,'order_selection':'one preregistered pseudorandom permutation; no balance/repeat claim',
 'per_variant_policy_wall_seconds':1800,'evaluation_cap_seconds':120,'cleanup_cap_seconds':10,
 'setup_cap_seconds':180,'offline_verification_cap_seconds':600,'outer_global_wall_seconds':6900,
 'conservative_reserved_seconds':6570,'unallocated_seconds':330,'unused_budget_reallocation':False,
 'cold_x0_per_variant':True,'automatic_scientific_retries':False,
 'model_grid_cadence_epsilon_radius_tickcap':'unchanged r09 input recipe; 6144 /16 /grid30 /1e-6 /1e-5',
 'numerical_input_fields':['model','current_x_box','radius_x_exact','epsilon_p_exact'],
 'intervention':'C1 computes unchanged current residual first; strict max(r)>2eps rejects original component predicate only; no actual error lower bound',
 'negative_full_proof':'NOT_EVALUATED; full negative result not equivalent',
 'proof':'valid K>=0,qK<1 => v=r+Kv>=r => max(r)>2eps implies max(v)/2>eps; invalid region cannot certify; equality falls through',
 'successful_certificate':'unchanged local_certificate(payload,numeric,residual=same_current_witness)',
 'cached_numeric_results':False,'historical_oracle_in_policy':False,
 'metrics':['policy physical wall','Job tree CPU','committed virtual peak (not RSS)','advance/certificate/persistence wall and CPU','certificate attempts/region/residual/Taylor counts'],
 'falsification':['any skipped original CERTIFIED','different common full7/first certified/success certificate','no observed C1 wall reduction vs C0','no observed C1 wall reduction vs F'],
 'postseal_verification':'all C1 cadence original predicate; all common full7; original evaluator world/anchor after seals; no nonlinear prefix replay',
 'limitations':['one run per variant; host load uncontrolled','one selected known graph/all-open authored synthetic world; discovery0','trusted shared numeric helpers/old anchor','previous selftest24/25 timing failure not relabeled','actual collision reader unknown; no mutable observation'],
 'observer':'enumerate state filenames and read only immutable sealed outputs; filename maximum not committed tick',
 'freeze_utc':now()}
put(PUB/'execution-contract.json',cfg)
put(OP/'FREEZE.actual.json',{'contract_sha256':sha(PUB/'execution-contract.json'),'code_pins':pins,'science_started':False,'observed_utc':now()})
put(PUB/'pre-execution-verification.json',{'schema':'HCCCertificateCostPrecheck.v1','analytic_tests':5,'analytic_status':'PASS',
 'threshold_mutation_detected':True,'mutation_test_bytes_exact':True,'source_pins_checked':True,
 'old_current_selftest':'r10 24PASS/1 .8sec pending C timing failure; synthetic5sec discriminator passed; original unchanged',
 'selftest_science_samples':0,'freeze_sha256':sha(PUB/'execution-contract.json')})
print(json.dumps({'order':order,'contract_sha':sha(PUB/'execution-contract.json'),'analytic':5,'mutation':'detected'}))
