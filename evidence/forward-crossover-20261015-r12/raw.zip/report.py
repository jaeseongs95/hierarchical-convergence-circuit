"""실행이 끝난 뒤 기존 봉인/블록을 집계한다. 수치 궤적/인증 계산은 하지 않는다."""
from control import *
import statistics
end=read(OP/'run/execution-end.json')
assert end['supervision']['active_processes']==0
cfg=read(PUB/'execution-contract.json')
for ref in cfg['code_pins']:assert sha(REPO/ref['path'])==ref['sha256']
summary=read(OP/'run/study/summary.json') if (OP/'run/study/summary.json').exists() else None
cells=read(OP/'run/study/cells-sealed.json')['rows'] if (OP/'run/study/cells-sealed.json').exists() else [
 {'cell_id':cid,'variant':arm,'status':'NOT_RUN_OR_UNSEALED'} for cid,arm in zip(cfg['cell_ids'],cfg['sequential_order'])]
proof=read(OP/'run/study/verification/result.json') if (OP/'run/study/verification/result.json').exists() else None
proof_ok=bool(summary and summary['verification_supervision']['status']=='COMPLETE' and proof and proof['status']=='PASS')
records=[]
for row in cells:
    child=OP/'run/study'/row['cell_id'];r=dict(row)
    trace=read(child/'trace.json') if (child/'trace.json').exists() else None
    timings=read(child/'timings.json') if (child/'timings.json').exists() else None
    seal=read(child/'sealed-cell.json') if (child/'sealed-cell.json').exists() else None
    r['trace']=trace;r['timings']=timings
    r['committed_tick']=seal['last_complete']['snapshot']['tick'] if seal and seal['last_complete'] else None
    r['phases']=trace['phases'] if trace else None
    r['nested']=trace['nested'] if trace else None
    blocks=[read(p) for p in sorted(child.glob('block-*.json'))]
    # Host counters are aggregate and sampled at low frequency. No CPU availability inference.
    for b in blocks:
        a,z=b['host_start'],b['host_end']
        if a and z:
            idle=z['idle_100ns']-a['idle_100ns'];kernel=z['kernel_including_idle_100ns']-a['kernel_including_idle_100ns'];user=z['user_100ns']-a['user_100ns']
            b['host_aggregate_busy_fraction']=1-idle/(kernel+user) if kernel+user>0 else None
        else:b['host_aggregate_busy_fraction']=None
    r['blocks']=blocks
    if trace:
        phases=trace['phases'];adv=phases['advance'];numeric=trace['nested']['numeric_advance']
        gc_numeric=sum(v['wall_seconds'] for k,v in trace['gc_nested'].items() if k.startswith('numeric_advance/'))
        r['advance_partition']={'parent_wall_seconds':adv['wall_seconds'],
         'numeric_nested_wall_seconds':numeric['wall_seconds'],
         'rest_parent_minus_numeric_wall_seconds':adv['wall_seconds']-numeric['wall_seconds'],
         'GC_numeric_nested_wall_seconds':gc_numeric,
         'numeric_minus_observed_GC_wall_seconds':numeric['wall_seconds']-gc_numeric,
         'causal_adjustment':False,'parent_child_gc_do_not_sum':True}
        r['legacy_minus_QPC_seconds']={k:v['legacy_wall_seconds']-v['wall_seconds'] for k,v in phases.items()}
        r['legacy_minus_QPC_numeric_seconds']=numeric['legacy_wall_seconds']-numeric['wall_seconds']
        r['clock_bracket_overhead_seconds']={k:v['clock_bracket_seconds'] for k,v in phases.items()}
        wall=row['policy_supervision']['highres_wall_seconds']
        r['unattributed_wall_seconds']=wall-sum(v['wall_seconds'] for v in phases.values())
    records.append(r)
common_end=min((max((b['tick_end_inclusive'] for b in r['blocks']),default=0) for r in records),default=0)
prefix=[]
if common_end:
    for r in records:
        b=next(b for b in r['blocks'] if b['tick_end_inclusive']==common_end)
        p=b['cumulative']['phases'];n=b['cumulative']['nested']['numeric_advance']
        g=b['cumulative']['gc_nested'];adv=p['advance']
        prefix.append({'cell_id':r['cell_id'],'variant':r['variant'],'common_tick':common_end,
         'advance_QPC':adv['wall_seconds'],'numeric_QPC':n['wall_seconds'],
         'advance_rest':adv['wall_seconds']-n['wall_seconds'],
         'numeric_GC_wall':sum(v['wall_seconds'] for k,v in g.items() if k.startswith('numeric_advance/')),
         'advance_legacy_minus_QPC':adv['legacy_wall_seconds']-adv['wall_seconds'],
         'certificate_QPC':p['certificate']['wall_seconds'],
         'block_CPU_single_differences_sum':sum(x['single_difference_process_cpu_seconds'] for x in r['blocks'] if x['tick_end_inclusive']<=common_end),
         'partial_work_diagnostic_not_whole_policy':True})
def phase(r,name):return r['phases'][name]['wall_seconds'] if r['phases'] else None
def pairs_for(values):
    diffs=[]
    for pair in (records[:2],records[2:]):
        if len(pair)!=2 or any(r['status']!='COMPLETE' for r in pair):diffs.append(None);continue
        by={r['variant']:r for r in pair};a,b=values(by['C1']),values(by['C0'])
        diffs.append(a-b if a is not None and b is not None else None)
    return {'C1_minus_C0_pair_seconds':diffs,'mean_seconds':sum(diffs)/2 if all(d is not None for d in diffs) else None}
effects={'whole_policy':pairs_for(lambda r:r['policy_supervision']['highres_wall_seconds']),
 'Job_tree_CPU':pairs_for(lambda r:r['policy_supervision']['tree_cpu_seconds']),
 'advance':pairs_for(lambda r:phase(r,'advance')),'certificate':pairs_for(lambda r:phase(r,'certificate')),
 'state_persistence':pairs_for(lambda r:phase(r,'state_persistence')),
 'numeric_advance':pairs_for(lambda r:r['nested']['numeric_advance']['wall_seconds'] if r['nested'] else None),
 'advance_rest':pairs_for(lambda r:r.get('advance_partition',{}).get('rest_parent_minus_numeric_wall_seconds')),
 'numeric_GC':pairs_for(lambda r:r.get('advance_partition',{}).get('GC_numeric_nested_wall_seconds')),
 'unattributed':pairs_for(lambda r:r.get('unattributed_wall_seconds')),
 'arithmetic_init':pairs_for(lambda r:phase(r,'arithmetic_init'))}
eligible=proof_ok and all(r['status']=='COMPLETE' for r in records) and proof['quality_all_four']
mean=effects['whole_policy']['mean_seconds']
win=bool(eligible and mean is not None and mean<0)
both_signs=effects['whole_policy']['C1_minus_C0_pair_seconds']
comparison={'schema':'HCCForwardCrossoverComparison.v1','contract_sha256':sha(PUB/'execution-contract.json'),
 'records':records,'common_prefix_diagnostic':prefix,'planned_denominator':4,'verification':proof,'verification_supervision':summary['verification_supervision'] if summary else None,
 'effects':effects,'full_cost_eligible':eligible,'wholecost_win':win,
 'verdict':'OBSERVED_PAIRED_MEAN_REDUCTION' if win else 'NO_WHOLECOST_WIN' if eligible else 'ABSTAIN_INCOMPLETE_EVIDENCE',
 'both_pairs_C1_faster':all(v is not None and v<0 for v in both_signs),
 'execution':end,'historical178_386_cause':'NOT_IDENTIFIED','retrospective_QPC_correction':False,
 'clock_observation':'legacy-QPC includes clock bracket/read skew and phase quantization; not all error attributable to quantization',
 'GC_interpretation':'observed nested wall, no GC CPU; possible policy mediator; no nuisance subtraction/counterfactual speed claim',
 'host_interpretation':'raw aggregate correlation only; percore/frequency/temperature/background culprit unknown',
 'same_information_and_total_cap':True,'independent_discovery_samples':0,'statistical_or_general_superiority':False}
put(PUB/'comparison.json',comparison)
put(PUB/'post-execution-verification.json',{'schema':'HCCForwardPostcheck.v1','status':'PASS' if proof_ok else 'INCOMPLETE',
 'contract_sha256':sha(PUB/'execution-contract.json'),'current_all14_code_pins_exact':True,
 'verification_result_sha256':sha(OP/'run/study/verification/result.json') if proof else None,
 'verification_process_complete':bool(summary and summary['verification_supervision']['status']=='COMPLETE'),
 'all4quality':eligible,'wholecost_win':win,'scientific_retries':0,'utc':now()})
def fmt(x):return '미측정' if x is None else f'{x:.3f}'
table='| 순서/정책 | 상태 | 봉인 tick | 정책 전체 QPC(s) | Job CPU(s) | 평가 |\n|---|---|---:|---:|---:|---|\n'
for r in records:
    e=r.get('evaluation') or {};s=r.get('policy_supervision') or {}
    table+=f"| {r['cell_id']} | {r['status']} | {r['committed_tick']} | {fmt(s.get('highres_wall_seconds'))} | {fmt(s.get('tree_cpu_seconds'))} | {e.get('candidate_correct')} / {(e.get('distance') or {}).get('status')} |\n"
phases='| 셀 | 전진 부모 | 수치 하위 | 전진 나머지 | 수치 내 GC 하위 | 인증 | 저장 | 미귀속 | 전진 legacy−QPC |\n|---|---:|---:|---:|---:|---:|---:|---:|---:|\n'
for r in records:
    p=r.get('advance_partition',{})
    phases+=f"| {r['cell_id']} | {fmt(p.get('parent_wall_seconds'))} | {fmt(p.get('numeric_nested_wall_seconds'))} | {fmt(p.get('rest_parent_minus_numeric_wall_seconds'))} | {fmt(p.get('GC_numeric_nested_wall_seconds'))} | {fmt(phase(r,'certificate'))} | {fmt(phase(r,'state_persistence'))} | {fmt(r.get('unattributed_wall_seconds'))} | {fmt(r.get('legacy_minus_QPC_seconds',{}).get('advance'))} |\n"
effects_table='| 지표 | pair1 C1−C0(s) | pair2 C1−C0(s) | 평균(s) |\n|---|---:|---:|---:|\n'
for k,v in effects.items():effects_table+=f"| {k} | {fmt(v['C1_minus_C0_pair_seconds'][0])} | {fmt(v['C1_minus_C0_pair_seconds'][1])} | {fmt(v['mean_seconds'])} |\n"
prefix_table='| 셀 | 공통 tick | 전진 QPC | 수치 QPC | 전진 나머지 | 수치 내 GC | 전진 legacy−QPC |\n|---|---:|---:|---:|---:|---:|---:|\n'
for r in prefix:
    prefix_table+=f"| {r['cell_id']} | {r['common_tick']} | {fmt(r['advance_QPC'])} | {fmt(r['numeric_QPC'])} | {fmt(r['advance_rest'])} | {r['numeric_GC_wall']:.7f} | {fmt(r['advance_legacy_minus_QPC'])} |\n"
complete_pairs=[]
for i in (0,2):
    pair=records[i:i+2]
    if all(r['status']=='COMPLETE' and r.get('advance_partition') for r in pair):
        by={r['variant']:r for r in pair};a,b=by['C1'],by['C0']
        complete_pairs.append({'pair':i//2+1,
         'advance_delta':phase(a,'advance')-phase(b,'advance'),
         'numeric_delta':a['advance_partition']['numeric_nested_wall_seconds']-b['advance_partition']['numeric_nested_wall_seconds'],
         'rest_delta':a['advance_partition']['rest_parent_minus_numeric_wall_seconds']-b['advance_partition']['rest_parent_minus_numeric_wall_seconds'],
         'GC_numeric_delta':a['advance_partition']['GC_numeric_nested_wall_seconds']-b['advance_partition']['GC_numeric_nested_wall_seconds'],
         'legacy_QPC_delta':a['legacy_minus_QPC_seconds']['advance']-b['legacy_minus_QPC_seconds']['advance']})
cause_lines='\n'.join(f"완료 pair {p['pair']}의 C1−C0 전진 차이 {p['advance_delta']:+.3f}초는 수치 함수 {p['numeric_delta']:+.3f}초와 나머지 {p['rest_delta']:+.3f}초로 나뉜다. 관측 수치 GC 차이는 {p['GC_numeric_delta']:+.7f}초, 전진 legacy−QPC 차이의 차이는 {p['legacy_QPC_delta']:+.3f}초다." for p in complete_pairs)
text=f'''# 동일 전진 시간과 C 전체 비용의 교차 대조 — r12

## Executive Verdict

판정은 **{comparison['verdict']}**다. C1−C0 정책 전체 비용의 두 인접 pair는 {both_signs}초, 평균은 {fmt(mean)}초다. 음수는 C1이 빠르다는 뜻이다. 전체 비용 판정 자격={eligible}, 두 pair 모두 C1이 빠름={comparison['both_pairs_C1_faster']}. 기존 +178.386초의 원인은 여전히 NOT_IDENTIFIED다. 새 실행의 수치·나머지·GC·시계 차이를 나누지만 과거 실행을 복원하지 않는다.

## Consensus Proposal

같은 graph, x0, 정보, C0/C1 코드와 수치 helper를 유지하고 C0→C1→C1→C0로 실행했다. 순서는 실행 전 ABBA/BAAB 중 seed로 고정했다. 네 셀은 각각 새 프로세스·고유 디렉터리이며 정책 cap1575, evaluator10, 공유 cleanup10초다. setup30, 검산450, 예약합6860, 전체6900, 여유40초를 추가 실험에 재배정하지 않았다. F는 이번에 실행하지 않았다.

## Strong Consensus

동일 코드·상태·호출 횟수는 동일 runtime 비용을 보장하지 않는다. 이전 단일 F→C0→C1 순서는 정책과 시간 순서가 섞였다. 이번 정책은 같은 현재 model/whole7 box/radius/epsilon만 사용하며 과거 궤적·정답·anchor·시계·호스트 수치는 숫자 helper에 입력하지 않았다. C1의 음성 잔차 필터와 성공 인증은 r11과 같다. 기본 GC 설정을 바꾸거나 수치 probe·캐시·반복 재시도를 추가하지 않았다.

## Material Disagreements

이전178.386초를 특정 원인에 소급 배분할 근거는 없다. 실제 Python의 monotonic 구현은 GetTickCount64, 공시 해상도15.625ms였고, QPC는 QueryPerformanceCounter였다. 20만회 clock-only 사전 관측의 최소 양의 변화는 고정 계약에 있다. 이 관측은 엄밀한 오차 상한이 아니다. 이전 callback별 CPU 합계의 +111.9375초 역시 실제 수치 CPU 증가의 독립 증거로 쓰지 않는다. 서로 반대인 pair 부호가 나오면 평균과 함께 공개하며 단일 승리로 숨기지 않는다.

## Decision by Axis

{table}
{phases}
전진 부모 = 수치 하위 + 부모와 하위의 차이다. GC는 수치/인증/저장 등에 이미 포함된 하위 wall이므로 부모와 합산하지 않는다. 전진 나머지는 box 파싱·모델 변환·outward 검증·관측 및 계측 overhead가 섞인 값이며 순수 I/O나 순수 산술로 부르지 않는다. 미귀속에는 startup·gate ledger·observer block 쓰기·최종 trace·프로세스 종료·감독 등이 포함된다. trace 최종 직렬화는 phase 합계 밖이지만 전체 정책 시간 안에 있다.

{effects_table}
위 차이는 관측된 회계 분해다. 수치−관측 GC도 GC를 제거한 반사실 실행 시간이 아니다. GC는 정책의 allocation 차이가 비용으로 이어지는 경로일 수 있으므로 단순한 호스트 교란으로 빼지 않는다. GC CPU는 측정하지 않았다.

{cause_lines}

{prefix_table}
공통 prefix는 네 셀 모두가 보존한 마지막 공통 불변 블록 경계 {common_end} tick에서 선택했다. 특정 arm의 빠른 구간을 골라낸 값이 아니며, 완료 정책 전체 비용으로 승격하지 않는다. GC·시계 차이가 작더라도 수치 함수가 왜 느려졌는지까지 식별한 것은 아니다. 이번 실행의 QPC 차이로 이전178.386초를 보정하지 않는다.

## Evidence

검산 감독 상태={(summary or {}).get('verification_supervision',{}).get('status')}, 결과={(proof or {}).get('status')}. 전체 기준 상태와 각 셀 공통 full7 비교 수={(proof or {}).get('common_reference_full7_equalities')}, 새 원본 predicate 고유 입력={(proof or {}).get('fresh_unique_original_predicates')}, C1 발생 건수={len((proof or {}).get('original_C1_predicate_occurrences',[]))}. 중복 제거는 봉인 후 전체 payload(model/current box/radius/epsilon/helper pins)의 canonical bytes가 정확히 같은 경우만 허용했다. SHA는 인덱스이며 bytes도 대조했다. 과거 r11 판정값을 재사용하지 않았다. 독립 비선형 전체 prefix 재생 검사는 아니며 공유 고정 수치 helper와 accepted old anchor를 신뢰한다.

원본 경계 테스트5개와 새 계측/교차/중도절단 테스트7개가 통과했다. 격리 사본에서 primary QPC 시간을 legacy로 치환하자 같은 테스트가 실패하고 복구 후 통과했다. 최종 canonical proof는 CONSISTENT다. 이전 r10 전체 suite의 24 PASS/시간민감1실패를 다시 실행하거나25 PASS로 바꾸지 않았다.

새 phase 주 시계는 perf_counter_ns다. legacy는 같은 callback을 포함하지만 CPU 시계 읽기 등 더 넓은 경계를 갖는다. legacy−QPC 전부를 양자화 오차라고 단정하지 않고 clock_bracket_seconds를 함께 보존한다. [Python3.12 time 문서](https://docs.python.org/3.12/library/time.html)는 시계 구현·해상도와 process CPU/elapsed의 의미를 설명한다.

128tick마다 누적·차분 phase/GC·Taylor/카운터·상태 hash·block CPU 단일 차와 GetSystemTimes 원값을 보존했다. kernel에는 idle이 포함된다. 집계 busy 비율은 호스트 전체의 상관 관측이며 해당 단일 코어의 가용성이나 주파수·열·특정 background 원인을 뜻하지 않는다. [Microsoft GetSystemTimes 문서](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getsystemtimes)와 같은 정의로 집계했다. callback CPU 합계는 해상도/갱신/경계 alias 한계가 있어 Job CPU 및 block 단일 차와 구분했다. outer Job CPU는 inner와 겹치므로 합산하지 않는다.

## Required Actions

이번 bounded 연구 결과와 미측정을 보존한다. 전체 물리 QPC 시간은 {end['physical_highres_wall_seconds']:.3f}초, 상한6900, 초과={end['exceeded']}, outer active={end['supervision']['active_processes']}다. 각 불완전·실패·NOT_RUN은 계획 분모4에 남긴다. 전체 검산/네 셀 품질이 빠지면 전체 비용 우위를 판정하지 않는다. 최종 scope·GPG 작업단위 commit·push·원격 바이트 대조는 별도 로컬 영수증에 보존한다.

## Optional Optimizations

이 연구에서는 추가 최적화 코드를 도입하지 않았다. 같은 관측기를 두 arm에 적용한 결과이며 계측 전 비용을 직접 복원하지 않는다. 이 네 번에서의 기술적 평균 효과 외 보편적·통계적 성능 우월성이나 F보다 빠르다는 새 주장은 하지 않는다.

## Unresolved

이전178.386초의 단일 원인, 주파수·온도·코어별 부하·background culprit·cache 상태·RSS·에너지는 미확인이다. ABBA는 선형 period 추세의 평균 위치를 맞추지만 U자형/비선형 drift·carryover를 제거하지 않는다. arm당2회이며 독립 graph/world 표본0이다. 정확도·커버리지는 알려진 단일 authored synthetic world의 진단 후보이며 adoption/full Engine 정확도는 미측정이다. 1575초는 이전 C1보다18.328초만 길어 완료 보장 예산이 아니었다.

## Method / Run Summary

토론스킬은 두 fresh blind 관점과 각1회 조건부 교차검토 뒤 Coordinator가 통합했다. MEDIUM/degraded_ok, assurance partially_independent이며 Judge/reserve/specialist는 없었다. inherited 실제 모델·추론 수준은 UNKNOWN이다. 구현 뒤 같은 reviewer를 재사용한 source follow-up은 새 독립 감사가 아니다. 중도절단 성공 callback의 final 강제와 평가 누락 PASS 표시 두 문제를 실행 전에 고쳤다. dot 연구 답변은 제한된 최근 조회 범위에서 확인되지 않았으며 기존 질의가 없거나 미전달됐다는 뜻이 아니다. 새 답을 받으면 날짜를 붙여 반영한다.

원자료 zip/inventory는 실행·봉인·clock·phase·GC·host·평가·검산·테스트·최초 후보 영수증을 보존한다. archive 작성 뒤 delivery/acceptance 영수증은 로컬 OP에 있고 이미 봉인한 archive 안에 있다고 주장하지 않는다. .gitattributes는 기존 CRLF를 유지하며 원격 대조에서 이 한 파일만 LF canonicalization을 적용하고, 새 launcher와 다른 파일은 raw bytes를 비교한다.
'''
with (PUB/'report.ko.md').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
readme=REPO/'README.md';before=readme.read_bytes();line=f'\n- [동일 graph 전진 시간·C 전체 비용 교차 대조(r12)]({REL}/report.ko.md)\n'.encode()
if b'\r\n' in before:line=line.replace(b'\n',b'\r\n')
assert REL.encode() not in before;readme.write_bytes(before+line)
print(json.dumps({'verdict':comparison['verdict'],'effects':effects,'proof_status':(proof or {}).get('status')}))
