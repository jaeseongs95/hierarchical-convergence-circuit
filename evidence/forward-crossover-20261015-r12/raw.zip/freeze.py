from control import *
import os, random, secrets, time
sys.path.insert(0,str(REPO/'tools/analysis'))
import termination_forward_crossover as cross
import termination_compare_core as core

clock=cross.clock_inventory();qm=mm=None;minq=minm=None;changedq=changedm=0
qprev,mprev=time.perf_counter_ns(),time.monotonic_ns()
for _ in range(200000):
    q,m=time.perf_counter_ns(),time.monotonic_ns();dq,dm=q-qprev,m-mprev
    if dq>0:changedq+=1;minq=dq if minq is None else min(minq,dq)
    if dm>0:changedm+=1;minm=dm if minm is None else min(minm,dm)
    qprev,mprev=q,m
clock_receipt={'schema':'HCCClockOnlyPrecheck.v1','python':sys.version,'cpu_count':os.cpu_count(),
 'clocks':clock,'paired_reads':200000,'positive_changes':{'perf_counter':changedq,'monotonic':changedm},
 'minimum_observed_positive_ns':{'perf_counter':minq,'monotonic':minm},'host_snapshot':cross.host_times(),
 'not_a_strict_error_bound':True,'model_arithmetic_calls':0,'utc':now()}
put(OP/'clock-only-precheck.json',clock_receipt)
run([PY,'-B','-X','utf8','tools/analysis/test_certificate_cost.py'],'old-five-boundaries')
run([PY,'-B','-X','utf8','tools/analysis/test_forward_crossover.py'],'new-seven-boundaries')
old=read(REPO/'evidence/certificate-cost-20261015-r11/execution-contract.json')
pins=read(OP/'source-pins.json')
for ref in pins:assert sha(REPO/ref['path'])==ref['sha256']
for path in ['tools/analysis/termination_forward_crossover.py','tools/analysis/test_forward_crossover.py','Run-HCR-Forward-Crossover.cmd']:
    pins.append({'path':path,'bytes':(REPO/path).stat().st_size,'sha256':sha(REPO/path)})
assert b'\r' not in (REPO/'Run-HCR-Forward-Crossover.cmd').read_bytes()
seed=secrets.token_hex(16)
order=random.Random(seed).choice([['C0','C1','C1','C0'],['C1','C0','C0','C1']])
contract={'schema':'HCCForwardCrossoverContract.v1','revision':1,'source_commit':BASE,
 'plan_sha256':old['plan_sha256'],'implementation_sha256':old['implementation_sha256'],'code_pins':pins,
 'order_seed':seed,'order_selection':'Python random.Random(seed).choice of ABBA/BAAB before any study arithmetic',
 'sequential_order':order,'cell_ids':[f'{i+1:02d}-{v}' for i,v in enumerate(order)],
 'per_cell_policy_seconds':1575,'per_cell_evaluation_seconds':10,'per_cell_shared_cleanup_seconds':10,
 'setup_worker_seconds':20,'setup_cleanup_seconds':10,'verification_seconds':450,
 'outer_global_seconds':6900,'reservations_seconds':6860,'unallocated_seconds':40,
 'unused_budget_reallocation':False,'cold_x0_process_per_cell':True,'scientific_retries':0,
 'planned_denominator':4,'repeat_count_per_variant':2,'F_rerun':False,
 'numerical_input_fields':['model','current_x_box','radius_x_exact','epsilon_p_exact'],
 'model_grid_cadence_epsilon_radius_tickcap':'unchanged r09 input recipe; 6144 /16 /grid30 /1e-6 /1e-5',
 'policy':'original r11 C0/C1 arithmetic and strict residual negative filter, default GC unchanged; cache0',
 'information_barrier':'policy does not read old trajectory/result/anchor/world, clock or host values never enter numerical helper namespace',
 'observer':'same passive Observer both arms; nested numeric wrapper, GC callbacks; stride128 boundary after preceding cadence; no extra arithmetic probe',
 'primary_wholecost':'QPC around full owned policy phase including launch, process work, final trace, cleanup/check/report; highres-supervision file after bracket is shared overhead',
 'primary_phase_wall':'perf_counter_ns callback body; numerical nested, GC nested, no double sum',
 'legacy_phase_wall':'monotonic_ns same callback but wider clock-read bracket; legacy-QPC includes read skew, not pure quantization',
 'cpu':'Job CPU and block single processCPU differences; callback CPU sums diagnostic with update/alias limits; no GC CPU measured',
 'host':'low-frequency GetSystemTimes aggregate raw idle/kernel/user; no frequency/thermal/percore/background culprit inference',
 'causal_estimand':'instrumented C1-C0 mean of two adjacent opposite-order pairs, plus both signs and all four cells; selected known graph only',
 'win_rule':'all4 COMPLETE + full7/current original predicate/success bytes and firsttick + all4 correct INSIDE evaluator + supervised verification PASS, then paired mean C1-C0<0',
 'failure_rule':'timeout/NOT_RUN/evalfailure/verificationfailure retained in denominator4; no wholecost win or complete predicate coverage if missing',
 'postseal_verifier':'fresh original C0 predicate for each unique full payload; exact canonical bytes plus helper pins, SHA index only; no r11 answer cache',
 'historical_forward_delta_seconds':178.386,'historical_cause':'NOT_IDENTIFIED; no retrospective QPC reconstruction',
 'initial_clock_observation':clock_receipt,'read_overhead_and_all_observer_costs_charged':True,
 'limits':['n2/arm descriptive, nonlinear drift/carryover uncontrolled','GC can mediate policy cost, do not subtract as host nuisance',
 'coarse clock nominal resolution not strict accumulated error bound','no nonlinear prefix replay; shared pinned numeric helpers/accepted old anchor trusted',
 'synthetic authored same world, independent discovery0; RSS/energy/frequency/temperature unknown','1575 cap only18.328s above historical C1, no completion guarantee'],
 'external_sources':['https://docs.python.org/3.12/library/time.html','https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getsystemtimes'],
 'freeze_utc':now()}
put(PUB/'execution-contract.json',contract)
panel={'schema':'HCCDeliberationSummary.v1','skill':'independent-deliberation-panel','risk':'MEDIUM','degraded_ok':True,
 'participants':[{'role':'measurement/causality','agent':'/root/forward_causality_r12'},
 {'role':'budget/crossover','agent':'/root/crossover_budget_r12'}],
 'method':'two fresh read-only blind reviews before implementation, one conditional cross each; coordinator synthesis; later same-agent source follow-up is NOT fresh independent audit',
 'actual_model_and_effort':'UNKNOWN inherited; no explicit Astra override','judge':None,'reserve':None,'specialist':None,
 'assurance':'partially_independent; coordinator implemented/integrated; prior blind then non-independent source reuse',
 'initial_consensus':['same state/code/calls do not guarantee same runtime','old F-C0-C1 single order confounds policy and period',
 'ABBA/BAAB four fresh cells, no F rerun','QPC primary plus legacy, nested arithmetic/GC, block CPU and host aggregate',
 '4*1800 incompatible with6900;1575equal and6860reserved, no completion guarantee or unused cap recycling'],
 'cross_conditions':['GC may mediate policy; leave default settings','do not infer arithmetic CPU from callback CPU sums',
 'historical178.386 cause remainsunknown','exact postseal payload dedup permitted; no policy cache',
 'allfour completion/quality required; keep failures denominator4, signs/mean reported'],
 'source_followup_findings':[{'finding':'success callback then hardkill caused verifier assertfinal','resolution':'COMPLETE only success-byte check; added success-then-timeout regression'},
 {'finding':'4policycomplete but evalmissing could label PASS','resolution':'PASS only when allfour quality; otherwise PASS_INTEGRITY_ONLY'}],
 'source_followup_limits':['GC CPU notmeasured; wall overlap only','clock brackets differ; report bracket read overhead','observer allocations/writes may alter runtime, same instrumented estimand only'],
 'remaining_disagreements':['runtime cause cannot be identified before observations; no retrospective single-cause assignment'],
 'dot':{'research_advice':'NOT_OBSERVED in latest1-turn read with hasMoretrue','original_question_id':'5f9cb043-ea81-42f1-87de-72faeebf5973','delivery_unknown_not_resent':True,'peer_operational_notices_not_research_advice':True},
 'utc':now()}
put(PUB/'deliberation-summary.json',panel)
_,digest=cross.contract()
put(PUB/'pre-execution-verification.json',{'schema':'HCCForwardPrecheck.v1','status':'PASS','contract_sha256':digest,
 'code_pins_verified':len(pins),'old_analytic_tests':5,'current_tests':7,'test_mutation':'CONSISTENT actual red then green, primary QPC->legacy substitution',
 'engineering_proof_sha256':sha(OP/'ENGINEERING-PROOF.final.actual.json'),'test_candidate_sources_match':True,
 'historical_initial_engineering_receipt':'retained for pre-review candidate, superseded by final proof; not claimed current',
 'source_followup_findings_addressed':2,'scientific_cells_started':0,'actual_order':order,'utc':now()})
print(json.dumps({'contract_sha256':digest,'order':order,'pins':len(pins),'clock_min_ns':clock_receipt['minimum_observed_positive_ns']}))
