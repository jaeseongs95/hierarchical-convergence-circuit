from control import *
import shutil
work=OP/'engineering-proof-final';work.mkdir(exist_ok=False)
names=['termination_forward_crossover.py','test_forward_crossover.py','termination_certificate_cost.py',
       'termination_compare_core.py','termination_compare_runner.py','check_termination_comparison.py',
       'check_on_basins.py','check_on_fixed_points.py','check_on_convergence_gate.py','check_on_online_convergence_gate.py']
for name in names:shutil.copyfile(REPO/'tools/analysis'/name,work/name)
put(work/'files.json',names)
cli=SK/'test-engineering/scripts/run.mjs'
def command(args,name,expected=0):
    argv=['node',str(cli)]+list(map(str,args));r=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
    put(work/(name+'.command.json'),{'argv':argv,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'utc':now()})
    assert r.returncode==expected,(name,r.stderr)
    result=json.loads(r.stdout)
    with (work/(name+'.json')).open('x',encoding='utf-8',newline='\n') as f:f.write(r.stdout)
    return result
argv=[str(PY),'-B','-X','utf8','test_forward_crossover.py']
plan={'schemaVersion':'1.0.0','kind':'engineering-test-plan','taskId':'r12-dual-clock-boundaries',
 'contractDigest':'sha256:'+sha(OP/'TASK.json'),'requirements':['TIMING-BOUNDARY'],
 'scopeFiles':names,'runner':'stdlib unittest',
 'environment':'Windows bundled Python; deterministic fake clocks plus exact zero-model delegation',
 'cases':[{'id':'timing-boundaries','requirementIds':['TIMING-BOUNDARY'],
 'scenario':'QPC vs quantized legacy, nested phases, GC passive binding, crossed pairs/censoring, delegation/restore',
 'entryPoint':'Observer/policy/paired_effects','level':'unit',
 'expectedBehavior':'all seven pass; replacing primary duration by legacy must fail',
 'oracle':'independent fake clocks, exact zero G/b model, hand paired effects',
 'testFiles':['test_forward_crossover.py'],'required':True,'sensitivity':'mutation',
 'sensitivityReason':'legacy clock constant while high-resolution clock advances', 'argv':argv}],
 'exclusions':['scientific trajectory probe','old full suite timing result','hardware attestation','nonlinear prefix replay']}
put(work/'plan.json',plan)
planned=command(['check-plan','--root',work,'--plan','plan.json'],'plan-check')
p=work/'termination_forward_crossover.py';original=p.read_bytes();text=original.decode('utf-8')
target="row['wall_seconds'] += (qend-qbody)/1e9"
assert text.count(target)==1
p.write_text(text.replace(target,"row['wall_seconds'] += (m1-m0)/1e9"),encoding='utf-8',newline='\n')
command(['snapshot','--root',work,'--files','files.json'],'red-snapshot')
red=command(['run','--root',work,'--snapshot','red-snapshot.json','--timeout-ms','30000','--']+argv,'red',1)
assert red['status']=='FAIL' and 'test_highres_body_not_legacy_quantized_clock' in red['stderr']
p.write_bytes(original)
snapshot=command(['snapshot','--root',work,'--files','files.json'],'green-snapshot')
green=command(['run','--root',work,'--snapshot','green-snapshot.json','--timeout-ms','30000','--']+argv,'green')
assert green['status']=='PASS'
proof={'schemaVersion':'1.0.0','kind':'engineering-test-proof','planDigest':planned['planDigest'],
 'candidate':snapshot,'proofs':[{'caseId':'timing-boundaries','status':'DEMONSTRATED',
 'red':{'path':'red.json','digest':'sha256:'+sha(work/'red.json')},
 'green':{'path':'green.json','digest':'sha256:'+sha(work/'green.json')},
 'mutationPaths':['termination_forward_crossover.py'],'assertionWitness':'test_highres_body_not_legacy_quantized_clock',
 'reason':'Actual isolated primary clock substitution; same tests/argv, red then green; no trajectory run'}]}
put(work/'proof.json',proof)
result=command(['check-proof','--root',work,'--plan','plan.json','--proof','proof.json'],'proof-check')
assert result['verdict']=='CONSISTENT'
for name in names:assert sha(work/name)==sha(REPO/'tools/analysis'/name)
put(OP/'ENGINEERING-PROOF.final.actual.json',{'plan':'engineering-proof-final/plan.json','proof':'engineering-proof-final/proof.json',
 'result':result,'source_candidates_equal_repo':True,'scientific_retries':0,'unsigned_local_consistency_only':True,'utc':now()})
print(json.dumps({'verdict':result['verdict'],'same_source':True,'science_rerun':False}))
