"""r10 전용 기록/동결/검사. 운영 Python이나 기존 연구를 실행하지 않는다."""
from pathlib import Path
import datetime, hashlib, json, subprocess, sys

OP=Path(__file__).resolve().parent
REPO=Path('D:/codex/리드/ai-research-resume-20261008-r01/repository')
SK=Path('C:/Users/Lenovo/.codex/plugins/cache/agent-governance/agent-governance-suite/2.9.0/skills')
REL='evidence/forward-crossover-20261015-r12'
PUB=REPO/REL
PY=Path('C:/Users/Lenovo/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
BASE='f12b01f62df30e1519040cf74f885e73b3ea58b8'
PLAN='experiments/exp-62-top-down/termination-policy-comparison-plan-20261015.json'
IMPL='experiments/exp-62-top-down/termination-comparison-implementation-20261015.json'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
def put(p,v):
    with Path(p).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(argv,name):
    r=subprocess.run(list(map(str,argv)),cwd=REPO,capture_output=True,text=True,encoding='utf-8')
    put(OP/(name+'.json'),{'argv':list(map(str,argv)),'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'observed_utc':now()})
    if r.returncode:raise RuntimeError((name,r.stderr))
    return r.stdout
def main():
    action=sys.argv[1]
    if action=='prepare':
        assert run(['git','rev-parse','HEAD'],'base-head').strip()==BASE
        assert not run(['git','status','--porcelain'],'base-clean').strip()
        task=read(Path('D:/codex/리드/ai-termination-implementation-20261015-r09/TASK.final.json'))
        task.update(taskId='ai-forward-crossover-20261015-r12',objective='고정 비교기로 같은 graph 실제6셀 단회 실행, 정확도·커버리지·별도 예산 비교와 작업별GPGcommit/push',
          scope={'included':[REL+'/**','README.md'],'excluded':['src/**','HCR-Evidence/**','archive/**','configs/**','.github/**','tools/**','experiments/**','.gitattributes','Run-HCR-Termination-Comparison.cmd']},
          acceptanceCriteria=['[AC-001] 독립토론2와교차검토·입력/코드/월드/예산 사전동결·dot상태구별','[AC-002] cold x0 실제6셀 단회시도/원실패보존/partial및고정6분모','[AC-003] 정책봉인후world/anchor 평가·정확도커버리지/총물리예산 독립재집계','[AC-004] phase/global메모리/트리중단관측·상한불완전/미측정정직보고','[AC-005] 원자료bundle/hash·불변sourcepins·범위검증·GPG작업단위commitpush/원격동일clean'],
          workUnits=[{'id':'freeze','objective':'실행계약/토론결론 사전동결','dependencies':[],'writeTargets':[REL+'/execution-contract.json',REL+'/deliberation-summary.json']},{'id':'results','objective':'원자료/검증/비교결과봉인','dependencies':['freeze'],'writeTargets':[REL+'/**','README.md']}],
          requiredCapabilities=['independent-deliberation','change-scope-baseline-capture','change-scope-assurance','mutation-risk-preflight','acceptance-evidence-validation'],
          constraints=['새실수궤적실제6셀만/단회/총6900초/코드·radius·cadence·precision변경0','R081닫힘유지/native/fullEngine/LLM/API/Cloud/설치/운영poller/globalconfig0','원자료·최초실패·timeout·미측정유지;독립발견표본0','정확도는새합성world진단후보;adoption및fullEngine성능미측정'],
          authorization={'allowedActions':['bounded6cell실행','범위내evidence작성','GPGcommit/mainFF/localbranchdelete/ordinaryoriginmainpush/readback'],'prohibitedActions':['R081resume','native/fullEngine','paidAPI','Cloud','globalconfig','forcepush','deploy'],'approvalRequired':[]})
        put(OP/'TASK.json',task)
        req={'schemaVersion':'1.0.0','mode':'capture','repositoryRoot':str(REPO),'comparisonTarget':'working-tree','taskEnvelope':task,'maxFiles':100000}
        put(OP/'capture.request.json',req)
        base=json.loads(run(['node',SK/'change-scope-guardian/scripts/capture-workspace-baseline.mjs',OP/'capture.request.json'],'capture.actual'))
        put(OP/'baseline.json',base)
        pins=[]
        implementation=read(REPO/IMPL)
        for ref in [implementation['design_pin']]+implementation['code_pins']:
            assert sha(REPO/ref['path'])==ref['sha256'],ref
            pins.append(ref)
        pins.append({'path':IMPL,'sha256':sha(REPO/IMPL),'bytes':(REPO/IMPL).stat().st_size})
        put(OP/'source-pins.json',pins)
        run(['git','switch','-c','research/termination-sixcell-freeze'],'freeze-branch')
        PUB.mkdir(parents=True,exist_ok=False)
        print(json.dumps({'baseline':base['manifestSha256'],'plan_sha':sha(REPO/PLAN),'implementation_sha':sha(REPO/IMPL)}))
    elif action=='scope':
        unit=sys.argv[2];base=read(OP/'baseline.json');task=read(OP/'TASK.json')
        req={'schemaVersion':'1.0.0','mode':'verify','repositoryRoot':str(REPO),'comparisonTarget':'working-tree','taskEnvelope':task,'baseline':base,'baselineArtifactDigest':base['manifestSha256'],'maxFiles':100000}
        put(OP/(unit+'.scope-request.json'),req)
        r=json.loads(run(['node',SK/'change-scope-guardian/scripts/compare-change-scope.mjs',OP/(unit+'.scope-request.json')],unit+'.scope.actual'))
        put(OP/(unit+'.scope.json'),r);assert r['verdict']=='PASS',r
        print(json.dumps({'verdict':r['verdict'],'summary':r['summary']}))
    elif action=='preflight':
        unit=sys.argv[2]
        prior=run(['git','ls-remote','origin','refs/heads/main'],unit+'.remote-before').split()[0]
        local=run(['git','rev-parse','HEAD'],unit+'.head').strip()
        assert not run(['git','status','--porcelain'],unit+'.clean').strip()
        run(['git','merge-base','--is-ancestor',prior,local],unit+'.fast-forward')
        run(['git','cat-file','-e',prior+'^{commit}'],unit+'.recovery-check')
        target='https://github.com/jaeseongs95/hierarchical-convergence-circuit.git#refs/heads/main'
        operation='r12-'+unit+'-push';until=(datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(minutes=10)).isoformat(timespec='milliseconds').replace('+00:00','Z')
        put(OP/(unit+'.authorization.json'),{'operation':operation,'source':'human current direct request','instruction':'동일 전진 계산 시간이 178.4초 늘어난 원인을 분리하고, 실행 순서를 교차한 반복 대조로 개선 C의 전체 비용을 검증해줘. 같은 정보·총예산을 유지하고 토론스킬 먼저 적용해. 토론스킬 먼저 적용하고 dot 답변은 오면 반영해. 작업단위별 GPG 서명 commit·push까지 해줘.','target':target,'allowedActions':['publish'],'expiresAt':until})
        fingerprint='sha256:'+hashlib.sha256(prior.encode()).hexdigest()
        put(OP/(unit+'.remote-state.json'),{'target':target,'head':prior,'fingerprint':fingerprint})
        put(OP/(unit+'.recovery.json'),{'backup_commit':prior,'procedure':'new signed revert of this unit on current main, ordinary push; never rewrite remote history','restore_executed':False})
        intent=read(Path('D:/codex/리드/ai-online-gate-20261014-r07/PUSH-INTENT.json'))
        intent['operationId']=operation;intent['targets'][0]['expectedFingerprint']=fingerprint
        intent['scopeRef'].update(locator=str(OP/'TASK.json'),digest='sha256:'+sha(OP/'TASK.json'))
        intent['authorizationRef'].update(locator=str(OP/(unit+'.authorization.json')),digest='sha256:'+sha(OP/(unit+'.authorization.json')))
        intent['approvalEvidenceRefs'][0].update(locator=str(OP/(unit+'.authorization.json')),digest='sha256:'+sha(OP/(unit+'.authorization.json')),operationId=operation,expiresAt=until)
        intent['currentStateEvidenceRefs'][0].update(locator=str(OP/(unit+'.remote-state.json')),digest='sha256:'+sha(OP/(unit+'.remote-state.json')),fingerprint=fingerprint)
        intent['recoveryPlan'].update(backupRef='git:'+prior,restoreProcedureRef=str(OP/(unit+'.recovery.json')),restoreTestEvidenceRef=str(OP/(unit+'.recovery-check.json')))
        intent['expectedBlastRadius']['description']='r12 fixed-graph C0/C1 crossover four-cell artifacts and scoped dual-clock/GC observer/test/launcher; original numerical sources/raw/plan/implementation/CI preserved; one new-launcher LF attribute rule'
        put(OP/(unit+'.intent.json'),intent)
        report=json.loads(run(['node',SK/'mutation-risk-preflight/scripts/evaluate-preflight.mjs','--input',OP/(unit+'.intent.json')],unit+'.preflight.actual'))
        put(OP/(unit+'.preflight.json'),report);assert report['verdict']=='READY',report
        check=read(Path('D:/codex/리드/ai-online-gate-20261014-r07/PREFLIGHT-VERIFY.request.json'));check.update(intent=intent,report=report)
        put(OP/(unit+'.preflight-verify-request.json'),check)
        print(json.dumps({'preflight':report['verdict'],'head':local}))
    elif action=='push':
        unit=sys.argv[2]
        r=json.loads(run(['node',SK/'mutation-risk-preflight/scripts/verify-preflight-receipt.mjs','--input',OP/(unit+'.preflight-verify-request.json')],unit+'.preflight-immediate'))
        assert r['valid'] is True
        run(['git','-c','gpg.program=C:/Program Files/Git/usr/bin/gpg.exe','verify-commit','HEAD'],unit+'.gpg')
        run(['git','push','origin','main:main'],unit+'.push')
        head=run(['git','rev-parse','HEAD'],unit+'.delivered-head').strip()
        remote=run(['git','ls-remote','origin','refs/heads/main'],unit+'.remote-after').split()[0];assert head==remote
        run(['git','fetch','origin','main'],unit+'.fetch')
        files=run(['git','diff','--name-only',BASE,'HEAD'],unit+'.files').splitlines()
        for p in files:
            rr=subprocess.run(['git','show','origin/main:'+p],cwd=REPO,capture_output=True);assert rr.returncode==0
            expected=(REPO/p).read_bytes()
            if p=='.gitattributes':expected=expected.replace(b'\r\n',b'\n')
            assert rr.stdout==expected,p
        assert not run(['git','status','--porcelain'],unit+'.final-clean').strip()
        put(OP/(unit+'.delivery.json'),{'status':'PASS','head':head,'remote':remote,'files':files,'remote_bytes_exact_except_existing_attributes_EOL':True,'attributes_comparison':'only .gitattributes worktree CRLF is canonicalized to LF; new launcher raw bytes exact','clean':True,'utc':now()})
        print(json.dumps({'status':'PASS','head':head,'files':len(files)}))
    else:raise ValueError(action)
if __name__=='__main__':main()
