from control import *
rows=[]
for cid in ('01-C0','02-C1','03-C1','04-C0'):
    child=OP/'run/study'/cid
    if not (child/'row.json').exists():continue
    r=read(child/'row.json')
    if not (child/'trace.json').exists():continue
    t=read(child/'trace.json');p=t['phases'];n=t['nested']['numeric_advance']
    gc_numeric=sum(v['wall_seconds'] for k,v in t['gc_nested'].items() if k.startswith('numeric_advance/'))
    rows.append({'cell':cid,'whole_QPC':r['policy_supervision']['highres_wall_seconds'],
      'Job_CPU':r['policy_supervision']['tree_cpu_seconds'],'advance_QPC':p['advance']['wall_seconds'],
      'advance_legacy':p['advance']['legacy_wall_seconds'],'numeric_QPC':n['wall_seconds'],
      'advance_rest':p['advance']['wall_seconds']-n['wall_seconds'],'numeric_GC_wall':gc_numeric,
      'certificate_QPC':p['certificate']['wall_seconds'],'persist_QPC':p['state_persistence']['wall_seconds'],
      'legacy_minus_QPC_advance':p['advance']['legacy_wall_seconds']-p['advance']['wall_seconds'],
      'advance_clock_bracket':p['advance']['clock_bracket_seconds'],
      'GC_settings_same':t['gc_before']==t['gc_after']})
print(json.dumps(rows,ensure_ascii=False))
