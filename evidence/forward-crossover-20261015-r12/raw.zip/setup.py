from pathlib import Path
import json,subprocess,hashlib
OP=Path(__file__).resolve().parent
REPO=Path('D:/codex/리드/ai-research-resume-20261008-r01/repository')
SK=Path('C:/Users/Lenovo/.codex/plugins/cache/agent-governance/agent-governance-suite/2.9.0/skills')
REL='evidence/forward-crossover-20261015-r12'
BASE='f12b01f62df30e1519040cf74f885e73b3ea58b8'
def put(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
def run(a):
    p=subprocess.run(a,cwd=REPO,capture_output=True,text=True,encoding='utf-8');assert p.returncode==0,p.stderr;return p.stdout
assert run(['git','rev-parse','HEAD']).strip()==BASE and not run(['git','status','--porcelain']).strip()
task=json.loads(Path('D:/codex/리드/ai-certificate-cost-20261015-r11/TASK.json').read_text(encoding='utf-8'))
new=['tools/analysis/termination_forward_crossover.py','tools/analysis/test_forward_crossover.py','Run-HCR-Forward-Crossover.cmd']
task.update(taskId='ai-forward-crossover-20261015-r12',objective='전진phase 증가의 arithmetic/rest/GC/clock 귀속 분리와 동일정보·6900초 교차순서 4셀 C0/C1 반복',
 scope={'included':[REL+'/**',*new,'.gitattributes','README.md'],
  'excluded':['src/**','HCR-Evidence/**','archive/**','configs/**','.github/**','experiments/**','evidence/certificate-cost-20261015-r11/**',
              'tools/analysis/termination_compare_core.py','tools/analysis/termination_compare_runner.py','tools/analysis/check_termination_comparison.py',
              'tools/analysis/termination_certificate_cost.py','tools/analysis/test_certificate_cost.py','Run-HCR-Certificate-Cost.cmd']},
 workUnits=[{'id':'implementation','objective':'토론/dual clock·nested map·passiveGC/block계측/반복4셀·검산 동결','dependencies':[],'writeTargets':[REL+'/**',*new,'.gitattributes']},
            {'id':'results','objective':'4cold반복 실행·원인귀속/전체비용대조·원자료/보고','dependencies':['implementation'],'writeTargets':[REL+'/**','README.md']}],
 acceptanceCriteria=['[AC-001] 토론·교차검토·출처/정보/4셀순서·총6900 사전동결','[AC-002] 동일양arm 계측/원숫자출력보존/GC변경0/시계·중복귀속 테스트','[AC-003] 독립cold4셀교차·각1575동일cap·실패중단NOT_RUN분모4보존','[AC-004] 신규동일payload exact중복제거 원본predicate/공통whole7/성공cert 검산·교차차이·원인한계','[AC-005] raw/hash/scope/작업단위GPGcommitpush·원격clean'],
 constraints=['samemodel/grid30/cadence16/eps1e-6/radius1e-5/tick6144; no historical/future/truth/anchor numeric inputs',
  'ABBAorBAAB preseed fixed fourperiods; percellpolicy1575/eval10/sharedgrace10/setup30/verify450/global6900; reserved6860+unused40',
  'bothvariantsdefaultGC sameenabled/thresholds unchanged; callbackonly, no gc.collect or GCoff in science; no extra arithmetic probe',
  'perf_counter_ns phaseprimary and legacy monotonic dual; operationaldeadline unchanged; GC/numericnested no doublecount',
  '4complete+equalquality+verification required for speed comparison; else censored abstain; no rescale/retry/budgetreallocation',
  'R081closed/native/fullEngine/API/Cloud/install/globalconfig0; past178.386cause NOT_IDENTIFIED no retrospectivecorrection'],
 authorization={'allowedActions':['scopedresearchimplementation/4coldboundedexperiment/evidence','signedcommit/mainFF/localbranchdelete/ordinaryoriginmainpush/readback'],
  'prohibitedActions':['forcepush','deploy','globalconfig','native','R081resume','paidAPI','newDriveupload'],'approvalRequired':[]})
put(OP/'TASK.json',task)
req={'schemaVersion':'1.0.0','mode':'capture','repositoryRoot':str(REPO),'comparisonTarget':'working-tree','taskEnvelope':task,'maxFiles':100000}
put(OP/'capture.request.json',req)
baseline=json.loads(run(['node',str(SK/'change-scope-guardian/scripts/capture-workspace-baseline.mjs'),str(OP/'capture.request.json')]))
put(OP/'baseline.json',baseline)
run(['git','switch','-c','research/forward-crossover-implementation'])
(REPO/REL).mkdir(parents=True,exist_ok=False)
text=Path('D:/codex/리드/ai-certificate-cost-20261015-r11/control.py').read_text(encoding='utf-8')
text=text.replace('ai-certificate-cost-20261015-r11','ai-forward-crossover-20261015-r12').replace('certificate-cost-20261015-r11','forward-crossover-20261015-r12')
text=text.replace("BASE='34650ccb5444e2d4dd72a64e8b68989ddd972a27'",f"BASE='{BASE}'").replace("operation='r11-'","operation='r12-'")
text=text.replace('C가 더 적은 tick으로 끝나도 F보다 느린 원인을 분석하고, 인증 비용을 줄이는 방법을 같은 정보·총예산 조건에서 검증해줘.',
 '동일 전진 계산 시간이 178.4초 늘어난 원인을 분리하고, 실행 순서를 교차한 반복 대조로 개선 C의 전체 비용을 검증해줘. 같은 정보·총예산을 유지하고 토론스킬 먼저 적용해.')
text=text.replace('r11 fixed-graph C0/C1/F bounded comparison artifacts and scoped new comparator/test/launcher;', 'r12 fixed-graph C0/C1 crossover four-cell artifacts and scoped dual-clock/GC observer/test/launcher;')
with (OP/'control.py').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
old=json.loads((REPO/'evidence/certificate-cost-20261015-r11/execution-contract.json').read_text(encoding='utf-8'))
pins=old['code_pins']+[{'path':'evidence/certificate-cost-20261015-r11/execution-contract.json','bytes':(REPO/'evidence/certificate-cost-20261015-r11/execution-contract.json').stat().st_size,
                      'sha256':hashlib.sha256((REPO/'evidence/certificate-cost-20261015-r11/execution-contract.json').read_bytes()).hexdigest()}]
put(OP/'source-pins.json',pins)
attrs=REPO/'.gitattributes';data=attrs.read_bytes();newline=b'\r\n' if b'\r\n' in data else b'\n'
assert b'Run-HCR-Forward-Crossover.cmd' not in data;attrs.write_bytes(data+b'Run-HCR-Forward-Crossover.cmd text eol=lf'+newline)
put(OP/'TEST-PLAN.early.json',{'scope':'dual-clock/nesting and no-GC-settings-mutation/current pinned original output','oracle':'injected exact clocks plus original unmodified arithmetic',
 'sensitivity':'nested duration mutation isolated copy; exact same tests, red then green; no scientific sample',
 'excluded':['generic profiler','thermal/frequency identification','new arithmetic optimisation','model discovery']})
print(json.dumps({'baseline':baseline['manifestSha256'],'branch':'research/forward-crossover-implementation'}))
