"""실행 중 읽기: 파일명, 불변 block/row/end만 관찰. ACK/숫자상태 내용은 읽지 않는다."""
from control import *
root=OP/'run/study';observations=[]
for cid in ('01-C0','02-C1','03-C1','04-C0'):
    child=root/cid
    if not child.exists():continue
    states=sorted(child.glob('state-*.json'))
    blocks=sorted(child.glob('block-*.json'))
    item={'cell':cid,'largest_state_filename':states[-1].name if states else None,
          'filename_not_committed_tick':True,'immutable_blocks':len(blocks)}
    if blocks:
        b=read(blocks[-1]);item.update(last_block_tick=b['tick_end_inclusive'],
         last_block_seconds=round(b['wall_seconds'],3),
         cumulative_advance_QPC=round(b['cumulative']['phases'].get('advance',{}).get('wall_seconds',0),3),
         cumulative_certificate_QPC=round(b['cumulative']['phases'].get('certificate',{}).get('wall_seconds',0),3))
    if (child/'row.json').exists():
        row=read(child/'row.json');item.update(sealed_status=row['status'],
         policy_QPC=round(row['policy_supervision']['highres_wall_seconds'],3),
         eval_status=row.get('evaluation_supervision',{}).get('status'))
    observations.append(item)
proof=root/'verification/result.json'
print(json.dumps({'observations':observations,'end_exists':(OP/'run/execution-end.json').exists(),
 'verification_started':(root/'verification').exists(),
 'verification_result_status':read(proof)['status'] if proof.exists() else None,'utc':now()},ensure_ascii=False))
