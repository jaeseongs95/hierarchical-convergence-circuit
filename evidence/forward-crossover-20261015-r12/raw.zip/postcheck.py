from control import *
import statistics
summary=read(OP/'run/study/summary.json');proof=read(OP/'run/study/verification/result.json');end=read(OP/'run/execution-end.json')
assert summary['verification_supervision']['status']=='COMPLETE' and proof['status']=='PASS'
assert proof['completed']==4 and proof['quality_all_four'] and proof['successful_certificate_bytes_and_first_tick_equal']
assert len(proof['original_C1_predicate_occurrences'])==646 and proof['fresh_unique_original_predicates']==323
assert proof['common_reference_full7_equalities']==15507
assert not end['exceeded'] and end['physical_highres_wall_seconds']<6900
assert end['supervision']['active_processes']==0
assert all(r['policy_supervision']['active_processes']==0 and r['evaluation_supervision']['active_processes']==0 for r in summary['rows'])
assert all(r['policy_supervision']['highres_wall_seconds']<1575 and r['evaluation_supervision']['highres_wall_seconds']<10 and r['cleanup_before_evaluation_seconds']<10 for r in summary['rows'])
comparison=read(PUB/'comparison.json');assert comparison['verdict']=='NO_WHOLECOST_WIN' and not comparison['wholecost_win']
records=comparison['records'];by={v:[r for r in records if r['variant']==v] for v in ('C0','C1')}
means={v:statistics.mean(r['policy_supervision']['highres_wall_seconds'] for r in rs) for v,rs in by.items()}
host=[]
for r in records:
    blocks=r['blocks'];a=blocks[0]['host_start'];z=blocks[-1]['host_end']
    idle=z['idle_100ns']-a['idle_100ns'];kernel=z['kernel_including_idle_100ns']-a['kernel_including_idle_100ns'];user=z['user_100ns']-a['user_100ns']
    vals=[b['host_aggregate_busy_fraction'] for b in blocks if b['host_aggregate_busy_fraction'] is not None]
    host.append({'cell':r['cell_id'],'host_aggregate_busy_fraction_whole_blocks':1-idle/(kernel+user),
      'block_busy_min':min(vals),'block_busy_median':statistics.median(vals),'block_busy_max':max(vals),
      'block_process_CPU_single_difference_sum':sum(b['single_difference_process_cpu_seconds'] for b in blocks),
      'block_wall_sum':sum(b['wall_seconds'] for b in blocks),
      'GC_numeric_seconds':r['advance_partition']['GC_numeric_nested_wall_seconds'],
      'GC_total_nested_seconds':sum(g['wall_seconds'] for g in r['trace']['gc_nested'].values()),
      'counts':r['timings']['counts']})
post={'status':'PASS','verification':{k:proof[k] for k in ('planned_denominator','completed','common_reference_full7_equalities','fresh_unique_original_predicates','successful_certificate_bytes_and_first_tick_equal','quality_all_four','verification_highres_wall_seconds')},
 'original_predicate_occurrences':len(proof['original_C1_predicate_occurrences']),
 'means_policy_QPC':means,'C1_minus_C0_percent':100*(means['C1']-means['C0'])/means['C0'],
 'effects':comparison['effects'],'physical_highres_wall_seconds':end['physical_highres_wall_seconds'],
 'outer_supervision':end['supervision'],'verification_supervision':summary['verification_supervision'],
 'host_descriptive_only':host,'all_recorded_jobs_inactive':True,'source_pins_exact':True,'utc':now()}
put(OP/'POSTCHECK.actual.json',post)
print(json.dumps({k:post[k] for k in ('status','verification','original_predicate_occurrences','means_policy_QPC','C1_minus_C0_percent','physical_highres_wall_seconds','host_descriptive_only')},ensure_ascii=False))
