from control import *
post=read(OP/'POSTCHECK.actual.json');p=PUB/'report.ko.md';text=p.read_text(encoding='utf-8')
text=text.replace('판정은 **NO_WHOLECOST_WIN**다.',
 '**C1의 전체 비용 절감은 확인되지 않았다.** C0 평균 1,341.422초, C1 평균 1,352.384초로 C1이 0.817% 느렸다. 사전 판정 규칙의 결과는 NO_WHOLECOST_WIN이다.')
needle='## Evidence\n\n'
table='| 셀 | 호스트 집계 busy(%) | 블록 CPU 단일 차 합(s) | 블록 wall 합(s) | 관측 GC 전체(s) |\n|---|---:|---:|---:|---:|\n'
for r in post['host_descriptive_only']:
    table+=f"| {r['cell']} | {100*r['host_aggregate_busy_fraction_whole_blocks']:.2f} | {r['block_process_CPU_single_difference_sum']:.3f} | {r['block_wall_sum']:.3f} | {r['GC_total_nested_seconds']:.7f} |\n"
addition=f'''이번 실행에서 전진 시간 차이의 대부분은 수치 함수 호출을 감싼 elapsed 구간에서 관측됐다. 그 구간의 실행 시간이 달라진 원인은 식별하지 못했으며, 수치 연산 자체의 고유 비용 증가나 과거 +178.386초의 원인을 확정한 것은 아니다. 직접 관측한 GC collection 정지시간이 작다는 사실로 refcount·allocator·cache의 간접 효과 전체를 배제하지 않는다. 네 셀의 전진 legacy−QPC 차이는 약 0.170~0.420초이며, 모두0.4초 미만인 것은 아니다.

{table}
같은 C1의 두 실행은 호스트 집계 busy가 약37.39%와60.69%일 때 전체시간이 각각1,410.523초와1,294.246초였다. 집계 busy가 큰 쪽이 더 빨랐으므로 단순한 ‘호스트 전체 부하 증가가 느려짐을 설명한다’는 주장을 하지 않는다. 이 지표는 해당 코어의 가용성·주파수·전력·온도·스케줄링을 측정하지 않으며, 상관이나 인과 효과를 추정하기에도 표본이 작다.

C0의 region proof는 셀당323회, C1은1회였다. residual323회는 유지되고 C1은322회의 음성 필터를 기록했다. Taylor는 C0 83,653회, C1 76,891회였다. 같은 정보·상태·횟수의 전진과 인증 연산 절감을 구분했다. 평균 전체 Job CPU는 C1−C0 +5.609375초였으며 phase별 callback CPU 합계로 이를 재배분하지 않는다.

outer kill-only Job flags8192, memory limit0, committed virtual peak68,620,288 bytes였고 inner Job은512MiB 상한이었다. 검산 자체349.646초, 감독 포함350.099초로450초 이내다. 이 메모리는 RSS가 아니며 실제 에너지는 미측정이다. 모든 기록된 Job active0과 종료코드0을 확인했다. hard real-time 보장은 없다.

'''
assert text.count(needle)==1
text=text.replace(needle,needle+addition)
with p.open('w',encoding='utf-8',newline='\n') as f:f.write(text)
put(OP/'POST-REVIEW.actual.json',{'schema':'HCCResultReadReview.v1','kind':'same reviewer reuse, not fresh independent audit',
 'measurement_reviewer':'/root/forward_causality_r12','budget_reviewer':'/root/crossover_budget_r12',
 'coordinator_direct_evidence':'POSTCHECK.actual.json assertions against actual end/summary/verification and public comparison',
 'changes':['mean +0.817% plain Korean headline','r12 numeric elapsed locus not intrinsic arithmetic/oldcause attribution',
 'legacy-QPC max.420 not all<.4','GC collection not all allocator/refcount/cache effects','actual host aggregate and CPU values without causal claim'],
 'source_and_scientific_data_changes':0,'report_sha256':sha(p),'utc':now()})
print(json.dumps({'report_sha256':sha(p),'no_data_or_source_change':True}))
