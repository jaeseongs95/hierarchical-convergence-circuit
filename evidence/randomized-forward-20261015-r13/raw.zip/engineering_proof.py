from control import *
import shutil
work=OP/'engineering-proof';work.mkdir(exist_ok=False)
names=['termination_randomized_forward.py','test_randomized_forward.py','termination_forward_crossover.py','test_forward_crossover.py','termination_certificate_cost.py','termination_compare_core.py','termination_compare_runner.py','check_termination_comparison.py','check_on_basins.py','check_on_fixed_points.py','check_on_convergence_gate.py','check_on_online_convergence_gate.py']
for name in names:shutil.copyfile(REPO/'tools/analysis'/name,work/name)
put(work/'files.json',names)
cli=SK/'test-engineering/scripts/run.mjs'
def command(args,name,expected=0):
    argv=['node',str(cli)]+list(map(str,args));r=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
    put(work/(name+'.command.json'),dict(argv=argv,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr,utc=now()))
    assert r.returncode==expected,(name,r.stderr)
    result=json.loads(r.stdout);put(work/(name+'.json'),result);return result
argv=[str(PY),'-B','-X','utf8','test_randomized_forward.py']
plan={'schemaVersion':'1.0.0','kind':'engineering-test-plan','taskId':'r13-thread-windows',
 'contractDigest':'sha256:'+sha(OP/'TASK.json'),'requirements':['WINDOW-ACCOUNTING','RANDOM-ORDER'],
 'scopeFiles':names,'runner':'stdlib unittest','environment':'Windows bundledPython; fake native snapshots/hand CPU residual and all four bit orders',
 'cases':[{'id':'windows-and-order','requirementIds':['WINDOW-ACCOUNTING','RANDOM-ORDER'],
 'scenario':'four random orders; raw native CPU/cycles, negative residual, API unavailable, separate forward/cert windows and failure',
 'entryPoint':'assignment/span/Observer.call','level':'unit','expectedBehavior':'13 pass; clipping negative residual must fail',
 'oracle':'hand integer native snapshots, four listed orders, existing7 boundary tests',
 'testFiles':['test_randomized_forward.py','test_forward_crossover.py'],'required':True,'sensitivity':'mutation',
 'sensitivityReason':'signed residual is required; clipping would hide accounting alias', 'argv':argv}],
 'exclusions':['numeric fullprefix replay','hardwarecause/frequency/ETW','historical24PASS1timingfailure unchanged']}
put(work/'plan.json',plan);planned=command(['check-plan','--root',work,'--plan','plan.json'],'plan-check')
p=work/'termination_randomized_forward.py';original=p.read_bytes();text=original.decode('utf-8')
target="'wall_minus_cpu_seconds': wall-kernel-user"
assert text.count(target)==1
p.write_text(text.replace(target,"'wall_minus_cpu_seconds': max(0., wall-kernel-user)"),encoding='utf-8',newline='\n')
command(['snapshot','--root',work,'--files','files.json'],'red-snapshot')
red=command(['run','--root',work,'--snapshot','red-snapshot.json','--timeout-ms','30000','--']+argv,'red',1)
assert red['status']=='FAIL' and 'test_raw_cpu_difference_and_signed_residual' in red['stderr']
p.write_bytes(original);snapshot=command(['snapshot','--root',work,'--files','files.json'],'green-snapshot')
green=command(['run','--root',work,'--snapshot','green-snapshot.json','--timeout-ms','30000','--']+argv,'green')
assert green['status']=='PASS'
proof={'schemaVersion':'1.0.0','kind':'engineering-test-proof','planDigest':planned['planDigest'],'candidate':snapshot,
 'proofs':[{'caseId':'windows-and-order','status':'DEMONSTRATED','red':{'path':'red.json','digest':'sha256:'+sha(work/'red.json')},
 'green':{'path':'green.json','digest':'sha256:'+sha(work/'green.json')},'mutationPaths':['termination_randomized_forward.py'],
 'assertionWitness':'test_raw_cpu_difference_and_signed_residual','reason':'same isolated tests/argv; signed residual clipping red/green, no science'}]}
put(work/'proof.json',proof);result=command(['check-proof','--root',work,'--plan','plan.json','--proof','proof.json'],'proof-check')
assert result['verdict']=='CONSISTENT'
for name in names:assert sha(work/name)==sha(REPO/'tools/analysis'/name)
put(OP/'ENGINEERING-PROOF.actual.json',dict(result=result,source_candidates_equal_repo=True,scientific_samples=0,utc=now()))
print(json.dumps(dict(verdict=result['verdict'],tests=13)))
