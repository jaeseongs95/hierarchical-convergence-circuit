"""r10 전용 기록/동결/검사. 운영 Python이나 기존 연구를 실행하지 않는다."""
from pathlib import Path
import datetime, hashlib, json, subprocess, sys

OP=Path(__file__).resolve().parent
REPO=Path('D:/codex/리드/ai-research-resume-20261008-r01/repository')
SK=Path('C:/Users/Lenovo/.codex/plugins/cache/agent-governance/agent-governance-suite/2.9.0/skills')
REL='evidence/randomized-forward-20261015-r13'
PUB=REPO/REL
PY=Path('C:/Users/Lenovo/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
BASE='b5f1e89a374f4f521f9c78238952066fa75b0e92'
PLAN='experiments/exp-62-top-down/termination-policy-comparison-plan-20261015.json'
IMPL='experiments/exp-62-top-down/termination-comparison-implementation-20261015.json'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
def put(p,v):
    with Path(p).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(argv,name):
    r=subprocess.run(list(map(str,argv)),cwd=REPO,capture_output=True,text=True,encoding='utf-8')
    put(OP/(name+'.json'),{'argv':list(map(str,argv)),'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'observed_utc':now()})
    if r.returncode:raise RuntimeError((name,r.stderr))
    return r.stdout
def main():
    action=sys.argv[1]
    if action=='scope':
        unit=sys.argv[2];base=read(OP/'baseline.json');task=read(OP/'TASK.json')
        req={'schemaVersion':'1.0.0','mode':'verify','repositoryRoot':str(REPO),'comparisonTarget':'working-tree','taskEnvelope':task,'baseline':base,'baselineArtifactDigest':base['manifestSha256'],'maxFiles':100000}
        put(OP/(unit+'.scope-request.json'),req)
        r=json.loads(run(['node',SK/'change-scope-guardian/scripts/compare-change-scope.mjs',OP/(unit+'.scope-request.json')],unit+'.scope.actual'))
        put(OP/(unit+'.scope.json'),r);assert r['verdict']=='PASS',r
        print(json.dumps({'verdict':r['verdict'],'summary':r['summary']}))
    elif action=='preflight':
        unit=sys.argv[2]
        prior=run(['git','ls-remote','origin','refs/heads/main'],unit+'.remote-before').split()[0]
        local=run(['git','rev-parse','HEAD'],unit+'.head').strip()
        assert not run(['git','status','--porcelain'],unit+'.clean').strip()
        run(['git','merge-base','--is-ancestor',prior,local],unit+'.fast-forward')
        run(['git','cat-file','-e',prior+'^{commit}'],unit+'.recovery-check')
        target='https://github.com/jaeseongs95/hierarchical-convergence-circuit.git#refs/heads/main'
        operation='r13-'+unit+'-push';until=(datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(minutes=10)).isoformat(timespec='milliseconds').replace('+00:00','Z')
        put(OP/(unit+'.authorization.json'),{'operation':operation,'source':'human current direct request','instruction':'전진 계산 시간의 변동 원인을 더 좁히고, 실행 순서를 무작위화한 반복 대조로 개선 C의 전체 비용을 재검증해줘. 같은 정보·총예산을 유지하고 토론스킬 먼저 적용해. 토론스킬 먼저 적용하고 dot 답변은 오면 반영해. 작업단위별 GPG 서명 commit·push까지 해줘.','target':target,'allowedActions':['publish'],'expiresAt':until})
        fingerprint='sha256:'+hashlib.sha256(prior.encode()).hexdigest()
        put(OP/(unit+'.remote-state.json'),{'target':target,'head':prior,'fingerprint':fingerprint})
        put(OP/(unit+'.recovery.json'),{'backup_commit':prior,'procedure':'new signed revert of this unit on current main, ordinary push; never rewrite remote history','restore_executed':False})
        intent=read(Path('D:/codex/리드/ai-online-gate-20261014-r07/PUSH-INTENT.json'))
        intent['operationId']=operation;intent['targets'][0]['expectedFingerprint']=fingerprint
        intent['scopeRef'].update(locator=str(OP/'TASK.json'),digest='sha256:'+sha(OP/'TASK.json'))
        intent['authorizationRef'].update(locator=str(OP/(unit+'.authorization.json')),digest='sha256:'+sha(OP/(unit+'.authorization.json')))
        intent['approvalEvidenceRefs'][0].update(locator=str(OP/(unit+'.authorization.json')),digest='sha256:'+sha(OP/(unit+'.authorization.json')),operationId=operation,expiresAt=until)
        intent['currentStateEvidenceRefs'][0].update(locator=str(OP/(unit+'.remote-state.json')),digest='sha256:'+sha(OP/(unit+'.remote-state.json')),fingerprint=fingerprint)
        intent['recoveryPlan'].update(backupRef='git:'+prior,restoreProcedureRef=str(OP/(unit+'.recovery.json')),restoreTestEvidenceRef=str(OP/(unit+'.recovery-check.json')))
        intent['expectedBlastRadius']['description']='r13 fixed-graph C0/C1 randomized four-cell artifacts and passive thread accounting observer/test/launcher; original numerical sources/raw/plan/implementation/CI preserved; one new-launcher LF attribute rule'
        put(OP/(unit+'.intent.json'),intent)
        report=json.loads(run(['node',SK/'mutation-risk-preflight/scripts/evaluate-preflight.mjs','--input',OP/(unit+'.intent.json')],unit+'.preflight.actual'))
        put(OP/(unit+'.preflight.json'),report);assert report['verdict']=='READY',report
        check=read(Path('D:/codex/리드/ai-online-gate-20261014-r07/PREFLIGHT-VERIFY.request.json'));check.update(intent=intent,report=report)
        put(OP/(unit+'.preflight-verify-request.json'),check)
        print(json.dumps({'preflight':report['verdict'],'head':local}))
    elif action=='push':
        unit=sys.argv[2]
        r=json.loads(run(['node',SK/'mutation-risk-preflight/scripts/verify-preflight-receipt.mjs','--input',OP/(unit+'.preflight-verify-request.json')],unit+'.preflight-immediate'))
        assert r['valid'] is True
        run(['git','-c','gpg.program=C:/Program Files/Git/usr/bin/gpg.exe','verify-commit','HEAD'],unit+'.gpg')
        run(['git','push','origin','main:main'],unit+'.push')
        head=run(['git','rev-parse','HEAD'],unit+'.delivered-head').strip()
        remote=run(['git','ls-remote','origin','refs/heads/main'],unit+'.remote-after').split()[0];assert head==remote
        run(['git','fetch','origin','main'],unit+'.fetch')
        files=run(['git','diff','--name-only',BASE,'HEAD'],unit+'.files').splitlines()
        for p in files:
            rr=subprocess.run(['git','show','origin/main:'+p],cwd=REPO,capture_output=True);assert rr.returncode==0
            expected=(REPO/p).read_bytes()
            if p=='.gitattributes':expected=expected.replace(b'\r\n',b'\n')
            assert rr.stdout==expected,p
        assert not run(['git','status','--porcelain'],unit+'.final-clean').strip()
        put(OP/(unit+'.delivery.json'),{'status':'PASS','head':head,'remote':remote,'files':files,'remote_bytes_exact_except_existing_attributes_EOL':True,'attributes_comparison':'only .gitattributes worktree CRLF is canonicalized to LF; new launcher raw bytes exact','clean':True,'utc':now()})
        print(json.dumps({'status':'PASS','head':head,'files':len(files)}))
    else:raise ValueError(action)
if __name__=='__main__':main()
