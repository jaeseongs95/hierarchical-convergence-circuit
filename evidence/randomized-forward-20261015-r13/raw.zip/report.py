"""봉인 종료 뒤 산술 재실행 없이 원자료와 검산 결과만 집계한다."""
from control import *
import statistics,time
aggregation_start=time.perf_counter_ns()
end=read(OP/'run/execution-end.json');assert end['supervision']['active_processes']==0
cfg=read(PUB/'execution-contract.json')
for ref in cfg['code_pins']:assert sha(REPO/ref['path'])==ref['sha256']
summary=read(OP/'run/study/summary.json') if (OP/'run/study/summary.json').exists() else {}
proof=read(OP/'run/study/verification/result.json') if (OP/'run/study/verification/result.json').exists() else {}
rows=read(OP/'run/study/cells-sealed.json')['rows'] if (OP/'run/study/cells-sealed.json').exists() else [
 dict(cell_id=cid,variant=v,status='NOT_RUN_OR_UNSEALED') for cid,v in zip(cfg['cell_ids'],cfg['sequential_order'])]
proof_ok=summary.get('verification_supervision',{}).get('status')=='COMPLETE' and proof.get('status')=='PASS'
records=[];diagnostics={r['cell_id']:r for r in proof.get('mechanism_verification',[])}
closed_sets=[]
for row in rows:
    r=dict(row);p=OP/'run/study'/r['cell_id']
    for name in ('trace','timings'):
        r[name]=read(p/(name+'.json')) if (p/(name+'.json')).exists() else None
    seal=read(p/'sealed-cell.json') if (p/'sealed-cell.json').exists() else None
    r['tick']=seal['last_complete']['snapshot']['tick'] if seal and seal['last_complete'] else None
    r['certified']=bool(r['status']=='COMPLETE' and seal and seal.get('final') and seal['final'].get('stop_reason')=='CERTIFIED')
    r['mechanisms']=diagnostics.get(r['cell_id'])
    r['phases']=(r['trace'] or {}).get('phases')
    r['numeric']=(r['trace'] or {}).get('nested',{}).get('numeric_advance')
    r['native_totals']=(r['mechanisms'] or {}).get('totals',{})
    s=r.get('policy_supervision') or {}
    r['whole_wall']=s.get('highres_wall_seconds');r['job_cpu']=s.get('tree_cpu_seconds')
    totals=r['native_totals']
    r['whole_accounting_remainder']=(r['whole_wall']-sum(v['wall_seconds'] for v in totals.values())) if len(totals)==2 and r['whole_wall'] is not None else None
    windows=[]
    for w in sorted(p.glob('forward-window-*.json')):
        data=read(w)
        if data['complete']:windows.append(data)
    r['complete_forward_window_end_ticks']=[w['tick_end_inclusive'] for w in windows]
    closed_sets.append(set(r['complete_forward_window_end_ticks']))
    records.append(r)
common_ticks=set.intersection(*closed_sets) if len(closed_sets)==4 else set()
common_end=max(common_ticks,default=None)
common_prefix=[]
if common_end is not None:
    for r in records:
        windows=[read(p) for p in sorted((OP/'run/study'/r['cell_id']).glob('forward-window-*.json'))]
        windows=[w for w in windows if w['complete'] and w['tick_end_inclusive']<=common_end]
        # A common endpoint alone does not excuse a missing earlier immutable window.
        assert [w['tick_end_inclusive'] for w in windows]==list(range(16,common_end+1,16))
        available=all(w['metrics']['thread']['status']=='AVAILABLE' and w['metrics']['process']['status']=='AVAILABLE' and w['metrics']['cycles']['status']=='AVAILABLE' for w in windows)
        wall=0.;cpu=0.;process_cpu=0.;user=0.;kernel=0.;cycles=0;last_end=None;identity=None
        for w in windows:
            a,b,m=w['start'],w['end'],w['metrics']
            assert a['pid']==b['pid'] and a['tid']==b['tid']
            current_identity=(a['pid'],a['tid'])
            if identity is None:identity=current_identity
            assert identity==current_identity
            assert a['qpc_before_ns']<=a['qpc_after_ns']<=b['qpc_before_ns']<=b['qpc_after_ns']
            if last_end is not None:assert a['qpc_before_ns']>=last_end
            last_end=b['qpc_after_ns']
            expected=(b['qpc_before_ns']-a['qpc_after_ns'])/1e9
            assert m['wall_seconds']==expected;wall+=expected
            state=read(OP/'run/study'/r['cell_id']/f"state-{w['tick_end_inclusive']:06d}.json")
            canonical_box=json.dumps(state['current_x_box'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
            assert w['state_digest_at_end']==hashlib.sha256(canonical_box).hexdigest()
            if available:
                u=(b['thread']['user_100ns']-a['thread']['user_100ns'])/1e7
                k=(b['thread']['kernel_100ns']-a['thread']['kernel_100ns'])/1e7
                assert min(u,k)>=0 and m['thread']['cpu_seconds']==u+k
                assert abs(m['thread']['wall_minus_cpu_seconds']-(expected-u-k))<1e-12
                pc=sum(b['process'][mode+'_100ns']-a['process'][mode+'_100ns'] for mode in ('kernel','user'))/1e7
                assert abs(pc-m['process']['cpu_seconds'])<1e-12
                cy=b['cycles']['raw']-a['cycles']['raw'];assert cy==m['cycles']['raw_difference'] and cy>=0
                user+=u;kernel+=k;cpu+=u+k;process_cpu+=pc;cycles+=cy
        common_prefix.append(dict(cell_id=r['cell_id'],variant=r['variant'],tick=common_end,windows=len(windows),wall_seconds=wall,
            mainthread_cpu_seconds=cpu if available else None,
            process_cpu_seconds=process_cpu if available else None,user_seconds=user if available else None,
            kernel_seconds=kernel if available else None,raw_cycles=cycles if available else None,
            signed_wall_minus_mainthread_cpu_seconds=wall-cpu if available else None,
            immutable_closed_window_prefix_only=True,whole_policy_equivalent=False,
            postseal_raw_reaggregation_and_state_digest_checks=True,
            frozen_verifier_native_window_scope='COMPLETE cells only; partial window raw accounting checked in this report aggregation, not additional numeric proof'))
prefix_effects={}
prefix_same_variant=[]
if len(common_prefix)==4:
    for key in ('wall_seconds','mainthread_cpu_seconds','signed_wall_minus_mainthread_cpu_seconds','process_cpu_seconds','user_seconds','kernel_seconds','raw_cycles'):
        values=[]
        for pair in (common_prefix[:2],common_prefix[2:]):
            by={p['variant']:p for p in pair};a,b=by['C1'][key],by['C0'][key]
            values.append(a-b if a is not None and b is not None else None)
        prefix_effects[key]=dict(pair_C1_minus_C0=values,mean=sum(values)/2 if all(v is not None for v in values) else None)
    for variant in ('C0','C1'):
        a,b=[p for p in common_prefix if p['variant']==variant]
        values={key:b[key]-a[key] if a[key] is not None and b[key] is not None else None
            for key in ('wall_seconds','mainthread_cpu_seconds','signed_wall_minus_mainthread_cpu_seconds','process_cpu_seconds','raw_cycles')}
        prefix_same_variant.append(dict(variant=variant,earlier=a['cell_id'],later=b['cell_id'],tick=common_end,
            later_minus_earlier=values,not_a_randomized_within_variant_treatment=True))
def metric(r,kind,key):
    t=r['native_totals'].get(kind,{})
    if key!='wall_seconds' and t.get('status')!='AVAILABLE':return None
    return t.get(key)
def phase(r,name):return (r['phases'] or {}).get(name,{}).get('wall_seconds')
def paired(fn):
    values=[]
    for pair in (records[:2],records[2:]):
        if len(pair)!=2 or any(r['status']!='COMPLETE' for r in pair):values.append(None);continue
        by={r['variant']:r for r in pair};a,b=fn(by['C1']),fn(by['C0'])
        values.append(a-b if a is not None and b is not None else None)
    return dict(pair_C1_minus_C0=values,mean=sum(values)/2 if all(v is not None for v in values) else None)
effects={'whole_policy':paired(lambda r:r['whole_wall']),'Job_CPU':paired(lambda r:r['job_cpu']),
 'advance_parent':paired(lambda r:phase(r,'advance')),
 'numeric_nested':paired(lambda r:(r['numeric'] or {}).get('wall_seconds')),
 'state_persistence':paired(lambda r:phase(r,'state_persistence')),
 'certificate_parent':paired(lambda r:phase(r,'certificate')),
 'whole_accounting_remainder':paired(lambda r:r['whole_accounting_remainder'])}
for kind in ('forward','certificate'):
    for key in ('wall_seconds','thread_cpu_seconds','wall_minus_thread_cpu_seconds','process_cpu_seconds','kernel_seconds','user_seconds','raw_cycles','read_bracket_seconds'):
        effects[kind+'_'+key]=paired(lambda r,k=kind,x=key:metric(r,k,x))
eligible=bool(proof_ok and len(records)==4 and all(r['status']=='COMPLETE' for r in records) and proof.get('quality_all_four'))
means={v:statistics.mean(r['whole_wall'] for r in records if r['variant']==v) for v in ('C0','C1')} if eligible else None
delta=effects['whole_policy']['mean'] if eligible else None
win=bool(eligible and delta is not None and delta<0)
coverage={}
for variant in ('C0','C1'):
    rs=[r for r in records if r['variant']==variant]
    evaluations=[r.get('evaluation') for r in rs if r.get('evaluation') is not None]
    coverage[variant]=dict(planned=2,attempted=sum(r['status'] not in ('NOT_RUN','NOT_RUN_OR_UNSEALED') for r in rs),
        complete=sum(r['status']=='COMPLETE' for r in rs),certified=sum(r['certified'] for r in rs),
        evaluated=len(evaluations),candidate_correct=sum(e.get('candidate_correct') is True for e in evaluations),
        inside=sum((e.get('distance') or {}).get('status')=='INSIDE' for e in evaluations),
        nominal_policy_cap_seconds=1575,
        observed_spend_seconds=[r['whole_wall'] for r in rs],
        completed_cost_mean_seconds=(statistics.mean(r['whole_wall'] for r in rs) if len(rs)==2 and all(r['status']=='COMPLETE' for r in rs) else None))
same_variant=[]
for v in ('C0','C1'):
    rr=[r for r in records if r['variant']==v]
    if len(rr)!=2 or any(r['status']!='COMPLETE' for r in rr):continue
    a,b=rr
    values={k:(metric(b,'forward',k)-metric(a,'forward',k)) if metric(a,'forward',k) is not None and metric(b,'forward',k) is not None else None
        for k in ('wall_seconds','thread_cpu_seconds','wall_minus_thread_cpu_seconds','raw_cycles')}
    same_variant.append(dict(variant=v,earlier=a['cell_id'],later=b['cell_id'],later_minus_earlier_forward=values,
        not_a_randomized_within_variant_treatment=True))
comparison=dict(schema='HCCRandomizedForwardComparison.v1',contract_sha256=sha(PUB/'execution-contract.json'),
 records=records,planned_denominator=4,per_arm_planned=2,order=cfg['sequential_order'],
 effects=effects,same_variant_repetition=same_variant,means_policy_QPC=means,
 C1_minus_C0_percent=100*delta/means['C0'] if eligible else None,
 common_closed_forward_prefix=common_prefix,common_prefix_effects=prefix_effects,same_variant_common_prefix=prefix_same_variant,
 coverage_by_variant=coverage,verification=proof,verification_supervision=summary.get('verification_supervision'),
 full_cost_eligible=eligible,wholecost_win=win,
 verdict='OBSERVED_PAIRED_MEAN_REDUCTION' if win else 'NO_WHOLECOST_WIN' if eligible else 'ABSTAIN_INCOMPLETE_EVIDENCE',
 execution=end,same_information_and_total_budget=True,statistical_or_general_superiority=False,
 historical178_386_cause='NOT_IDENTIFIED',historical_r12_numeric_cause='NOT_IDENTIFIED',
 hardware_frequency_cache_thermal_cause='NOT_IDENTIFIED',host_adjustment=False,
 forward_scope='mixed pipeline: numeric/state persistence/history/wrappers; excludes certificate and gate bookkeeping',
 residual='signed wall-mainthread CPU includes waiting/preemption/read skew/accounting error, not pure host interference',
 cycle_units='raw only, not frequency/elapsed/retiredinstructions',independent_discovery_samples=0,
 postseal_nonnumerical_aggregation_seconds=(time.perf_counter_ns()-aggregation_start)/1e9,
 postseal_aggregation_not_policy_or_new_numerical_probe=True)
put(PUB/'comparison.json',comparison)
jobs=[read(p) for p in (OP/'run').rglob('supervision.json')]
post=dict(schema='HCCRandomizedForwardPostcheck.v1',status=proof.get('status','INCOMPLETE'),
 source_pins_exact=len(cfg['code_pins']),verification_status=proof.get('status'),
 all4quality=eligible,wholecost_win=win,code_unchanged_after_draw=True,
 original_predicate_occurrences=len(proof.get('original_C1_predicate_occurrences',[])),
 unique_original_predicates=proof.get('fresh_unique_original_predicates'),common_full7_equalities=proof.get('common_reference_full7_equalities'),
 verification_body_seconds=proof.get('verification_highres_wall_seconds'),
 verification_supervision_seconds=summary.get('verification_supervision',{}).get('highres_wall_seconds'),
 charged_highres_wall_seconds=end['charged_highres_wall_seconds'],cap_seconds=6900,exceeded=end['exceeded'],
 all_recorded_jobs_inactive=all(j['active_processes']==0 for j in jobs),jobs=len(jobs),
    scientific_retries=0,coverage_by_variant=coverage,utc=now())
put(PUB/'post-execution-verification.json',post);put(OP/'POSTCHECK.actual.json',dict(post,means=means,effects=effects,same_variant=same_variant))
def f(x):return '미측정' if x is None else f'{x:.3f}'
table='| 순서·정책 | 상태 | tick | 전체 QPC(s) | Job CPU(s) | 후보 정오/거리 |\n|---|---|---:|---:|---:|---|\n'
native='| 셀 | 전진 창 wall | 주 스레드 CPU | wall−CPU | 인증 창 wall | 인증 CPU | 전체 회계 잔여 |\n|---|---:|---:|---:|---:|---:|---:|\n'
for r in records:
    e=r.get('evaluation') or {}
    table+=f"| {r['cell_id']} | {r['status']} | {r['tick']} | {f(r['whole_wall'])} | {f(r['job_cpu'])} | {e.get('candidate_correct')}/{(e.get('distance') or {}).get('status')} |\n"
    native+=f"| {r['cell_id']} | {f(metric(r,'forward','wall_seconds'))} | {f(metric(r,'forward','thread_cpu_seconds'))} | {f(metric(r,'forward','wall_minus_thread_cpu_seconds'))} | {f(metric(r,'certificate','wall_seconds'))} | {f(metric(r,'certificate','thread_cpu_seconds'))} | {f(r['whole_accounting_remainder'])} |\n"
et='| 지표 | pair1 C1−C0 | pair2 C1−C0 | 평균 |\n|---|---:|---:|---:|\n'
for key in ('whole_policy','Job_CPU','advance_parent','numeric_nested','forward_wall_seconds','forward_thread_cpu_seconds','forward_wall_minus_thread_cpu_seconds','certificate_wall_seconds','certificate_thread_cpu_seconds','whole_accounting_remainder'):
    e=effects[key];et+=f"| {key} | {f(e['pair_C1_minus_C0'][0])} | {f(e['pair_C1_minus_C0'][1])} | {f(e['mean'])} |\n"
repeat='\n'.join(f"- {r['variant']} {r['earlier']}→{r['later']}의 전진 창 차이(later−earlier): {r['later_minus_earlier_forward']}" for r in same_variant)
prefix_repeat='\n'.join(f"- {r['variant']} {r['earlier']}→{r['later']}의 공통 {r['tick']}tick 전진 창 차이(later−earlier): {r['later_minus_earlier']}" for r in prefix_same_variant)
prefix_table='| 셀 | 공통 tick | 닫힌 창 수 | 전진 창 wall | 주 스레드CPU | signed wall−CPU |\n|---|---:|---:|---:|---:|---:|\n'
for p in common_prefix:prefix_table+=f"| {p['cell_id']} | {p['tick']} | {p['windows']} | {f(p['wall_seconds'])} | {f(p['mainthread_cpu_seconds'])} | {f(p['signed_wall_minus_mainthread_cpu_seconds'])} |\n"
prefix_delta='| 공통 전진 prefix 지표 | pair1 C1−C0 | pair2 C1−C0 | 평균 |\n|---|---:|---:|---:|\n'
for key in ('wall_seconds','mainthread_cpu_seconds','signed_wall_minus_mainthread_cpu_seconds'):
    p=prefix_effects.get(key,dict(pair_C1_minus_C0=[None,None],mean=None))
    prefix_delta+=f"| {key} | {f(p['pair_C1_minus_C0'][0])} | {f(p['pair_C1_minus_C0'][1])} | {f(p['mean'])} |\n"
text=f'''# 무작위 반복 대조와 전진 파이프라인 CPU 회계 — r13

## Executive Verdict

판정은 **{comparison['verdict']}**다. 두 pair의 C1−C0 전체 비용은 {effects['whole_policy']['pair_C1_minus_C0']}초, 판정 가능한 전체 평균 {f(delta)}초다. 음수는 C1이 빠르다는 뜻이며 None은 누락·미완료로 판정 불가다. C0/C1 완료 비용 평균={means}, 증감률={comparison['C1_minus_C0_percent']}%. 불완전 셀이 있으면 완료 셀만의 평균·timeout 소비량으로 완료 비용을 대신하지 않는다. 관측된 기술적 결과이며 통계적·보편적 우위나 F 대비 개선을 뜻하지 않는다.

## Consensus Proposal

실행 상태는 **consensus**다. 최종 실행·검산 코드18핀과 배정·판정 규칙을 먼저 불변 파일로 고정한 뒤 OS entropy32byte를 한 번 생성했다. 첫 바이트의 독립 bit 두 개로 인접 block별 순서를 정했으며, 결과는 {cfg['sequential_order']}였다. 두 block을 반대로 강제하지 않았다. 가능한 배정은4개다. 재추첨·거부·호스트 부하를 보고 시작 시점을 고르는 조작은 하지 않았다. 이 절차의 로컬 기록은 보존하지만 과거에 폐기된 난수가 전혀 없었다는 외부 증명은 아니다.

## Strong Consensus

같은 graph/model/x0/grid30/cadence16/tickcap6144/epsilon1e-6/radius1e-5와 원 C0/C1 수치 코드를 유지했다. 첫 필터는 t16이다. 정책 입력은 현재 모델과 whole7 box·고정 반경·epsilon뿐이며 과거 궤적·정답·anchor·host 관측·시계 값을 숫자 helper에 넣지 않았다. 네 셀 모두 독립 cold process다. 정책1575·평가10·공유cleanup10초씩, setup30·검산450, 예약합6860·전체6900초와 여유40초를 유지했다. 추첨→draw 기록 파일 close까지 {cfg['draw_debit_seconds']:.7f}초를 원시 QPC로 기록하고 실제 outer watchdog/deadline에서 차감했다. 추첨 timing attestation·계약 준비·개발 테스트는 추첨 구간 밖 준비 작업이다. 미사용 예산 재배정·재시도·F 추가·수치 probe·GC/affinity/priority/power 설정 변경은 없다.

## Material Disagreements

전체 wall 변동을 순수 탈스케줄링이나 CPU 주파수 하나로 설명할 수 없다. 과거 r12의 같은 C1 두 실행에서 전체 wall은116.277초 줄고 Job CPU는158.859초 줄었지만, 이는 정책 전체 회계이므로 숫자 함수 CPU로 배분하지 않는다. 이번 새 창은 그 경계를 전진 파이프라인과 인증으로 좁힌다. 원인 자체를 결정하는 개입 실험은 아니다. 과거 +178.386초와 r12 수치 elapsed 변동의 단일 원인은 여전히 **NOT_IDENTIFIED**다.

## Decision by Axis

{table}
{native}
전진 창은 초기 상태 저장 뒤 첫 advance 직전(128tick 블록 쓰기보다 전)부터 현재16tick 상태 저장 뒤 certificate 호출 직전까지다. 수치 계산·상태 저장·history·wrapper·일부 관측을 포함하며 인증과 이후 gate bookkeeping은 제외한다. 인증 창은 별도로 동일 API를 읽는다. 새 창 쓰기와 snapshot 사이 틈은 전체 정책에 과금된다. 전체 회계 잔여=전체−전진 창합−인증 창합이며 초기화·감독·직렬화·gate 기록·관측 등을 포함한다. **전진 창 wall−주 스레드CPU**와 이 회계 잔여는 다른 값이다. 어느 것도 순수 호스트 간섭 시간은 아니다.

{et}
원래 전진 부모와 수치 하위, GC, 시계 차이는 원 trace에 그대로 보존했다. 전진 부모·수치 하위·GC는 겹치므로 합산하지 않는다. Job CPU·process CPU·thread CPU 역시 관측 경계가 다르며 outer/inner CPU는 중복 합산하지 않는다.

{repeat}

같은 정책 내 반복 차이도 시간 순서와 환경 변화가 섞인 기술적 진단이다. 창은 독립 표본이 아니며 무작위 배정 단위는 네 셀이다. 모든 대상 셀에서 닫힌 불변 창이 연속으로 존재하는 마지막 공통 경계={common_end}tick이다. 열린 창·단순 상태 파일·일부 arm만의 창을 공통 완료 작업량으로 세지 않는다.

{prefix_table}
{prefix_delta}
{prefix_repeat}

이 공통 prefix는 완료 비용이 아닌 동일 전진 구간의 진단이다. 고정 검산기의 native창 검사는 COMPLETE셀에 한정된다. 불완전 셀의 닫힌 창은 이 보고 집계에서 원시 counter 차분·동일PID/TID·연속경계·상태digest를 다시 대조했으며 추가 수치 궤적·predicate 계산은 하지 않았다. 집계 시간은 comparison의 postseal_nonnumerical_aggregation_seconds에 별도로 남기며 정책 비용이나 고정 과학 실행 시간으로 합치지 않는다. 계측 CPU는 서비스시간 회계 관측이며 산술 고유 비용으로 해석하지 않는다.

예산 내 완료·인증·후보 정오·거리 집계는 비교 원장의 coverage_by_variant에 분모2씩 남겼다: {coverage}. 미완료 소비 시간은 성공 완료 비용이 아니다. 평가기가 후보 오답/OUTSIDE를 내더라도 미인증 정책을 성공 종료로 승격하지 않는다.

## Evidence

검산={proof.get('status')}, 완료={proof.get('completed')}/4, 품질={proof.get('quality_all_four')}. 공통 기준 full7 상태 비교={proof.get('common_reference_full7_equalities')}, fresh 원본 predicate 고유 입력={proof.get('fresh_unique_original_predicates')}, C1 발생={len(proof.get('original_C1_predicate_occurrences',[]))}. 봉인 후 동일 전체 payload·helper핀의 canonical bytes까지 대조한 중복 제거이며 과거 답변 캐시는 아니다. 성공 certificate bytes·최초 tick 동일 판정={proof.get('successful_certificate_bytes_and_first_tick_equal')}. 공유 pinned helper와 accepted old anchor를 신뢰하며 독립 비선형 fullprefix 재생은 하지 않았다.

각 전진·인증 창은 tick·상태 digest·동일 PID/TID·원시 QPC 순서·native user/kernel 차분·cycle 차분을 봉인 후 대조했다. API 실패는 UNAVAILABLE이며0으로 바꾸지 않는다. 100ns는 CPU 자료형 단위이며 실제 갱신 해상도 보장이 아니다. 특히 짧은 C1 reject의 CPU0은 무비용을 뜻하지 않는다. 부호 있는 residual을0으로 자르지 않았고 읽기 전후 bracket을 보존했다. 관측 원값이 순차로 읽혀 완전히 동시인 경계는 아니다. [Microsoft GetThreadTimes](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getthreadtimes)는 user/kernel 실행시간을 제공한다. [QueryThreadCycleTime 공식 문서](https://learn.microsoft.com/en-us/windows/win32/api/realtimeapiset/nf-realtimeapiset-querythreadcycletime)는 CPU마다 timer 거동이 달라 cycle을 elapsed로 변환하지 말라고 명시한다. 원시 cycle은 주파수·retired instruction으로 해석하지 않았다.

최종14개 경계 테스트(기존7+새7)와 원 필터 테스트5개가 통과했다. 격리 사본에서 같은 테스트·명령을 사용해 residual 음수를 clipping하는 mutation의 실제 실패와 원본 복구 후 성공을 확인했고 canonical proof=CONSISTENT다. 최초13개 proof는 결속 보완 전 이력으로 남겼으며 현재 증거가 아니다. r10의24PASS/시간민감1실패를 재실행하거나25PASS로 바꾸지 않았다.

## Required Actions

새 전체비용 판정은 네 COMPLETE·네 correct/INSIDE·전체 검산 PASS가 모두 있어야 허용한다. 불완전·실패·NOT_RUN은 고정 분모4에 남고 대체 실행은 없다. 전체 검산 본체={f(proof.get('verification_highres_wall_seconds'))}초(상속 검산={f(proof.get('inherited_verification_body_highres_wall_seconds'))}초), 감독 포함={f(summary.get('verification_supervision',{}).get('highres_wall_seconds'))}초다. root 실제 QPC={f(end['physical_highres_wall_seconds'])}, 추첨 차감 포함 총과금={f(end['charged_highres_wall_seconds'])}초<6900 여부={not end['exceeded']}. 기록된 Job {len(jobs)}개 잔존0 여부={post['all_recorded_jobs_inactive']}. hard realtime 보장으로 표현하지 않는다.

## Optional Optimizations

새 최적화나 host 정규화·회귀 보정은 도입하지 않았다. 이번 관측기 비용을 포함한 C0/C1 비교이며 계측 전 속도를 복원하지 않는다. 정책 평균·두 pair 부호·네 원값을 모두 공개했다.

## Unresolved

CPU 서비스시간과 signed 미계상 wall의 관측은 원인 후보를 구별하는 단서를 주지만 순수 산술 고유 비용·cache·allocator/refcount·실주파수·열·특정 background 원인은 미식별이다. ETW·dispatch profiling·코어 residency는 측정하지 않았다. 기본 GC 수동 callback은 collection wall만 관측하며 간접 allocation 효과를 배제하지 않는다. 무작위화는 선택 편향을 줄이지만 실제 period 평균 균형·비선형 drift·carryover·셀 간 간섭 제거를 보장하지 않는다. n2/arm, 배정 공간4로 통상5% 유의성을 주장하지 않는다. 같은 authored synthetic world에서의 진단 후보이고 독립 발견표본0, native/fullEngine/adoption 효율 미측정이다.

## Method / Run Summary

토론스킬 먼저 두 fresh fork_turns:none readonly 관점(performance/measurement, randomization/budget), 각1회 조건부 교차검토, Coordinator 통합으로 실행했다. MEDIUM/degraded_ok, partially_independent; Judge/reserve/specialist 없음, 실제 inherited 모델/추론 수준 UNKNOWN. 후속 소스 검토는 같은 reviewer 재사용이며 새 독립 감사가 아니다. draw debit과 predraw 코드 핀 결속 두 공백, 부분 파일 수 표기와 supplement 검산 시간 표기를 추첨 전에 보완했다. dot의 source-bound 연구 조언은 제한된 최근1turn(hasMore=true) 조회에서 확인되지 않았으며 부재·미전달 확정이 아니다. 새 유효 답변은 날짜와 출처를 붙여 반영한다.

raw.zip/inventory는 생성 시점 OP의 실행·원시창·trace·상태·봉인·평가·검산·테스트·준비·서명 자료와 source snapshot을 보존한다. 그 뒤 만든 acceptance/delivery는 로컬 OP의 별도 근거이며 이미 봉인한 zip 안에 있다고 주장하지 않는다. GPG 서명·scope·main fast-forward·일반 push와 원격 bytes 대조의 실제 영수증을 별도로 확인한다.
'''
with (PUB/'report.ko.md').open('x',encoding='utf-8',newline='\n') as file:file.write(text)
readme=REPO/'README.md';before=readme.read_bytes();line=f'\n- [무작위 반복·전진 CPU 회계와 C 전체 비용(r13)]({REL}/report.ko.md)\n'.encode()
if b'\r\n' in before:line=line.replace(b'\n',b'\r\n')
assert REL.encode() not in before;readme.write_bytes(before+line)
print(json.dumps(dict(verdict=comparison['verdict'],means=means,effects=effects,same_variant=same_variant,post=post),ensure_ascii=False))
