from pathlib import Path
import hashlib,json,subprocess
OP=Path(__file__).resolve().parent
REPO=Path('D:/codex/리드/ai-research-resume-20261008-r01/repository')
SK=Path('C:/Users/Lenovo/.codex/plugins/cache/agent-governance/agent-governance-suite/2.9.0/skills')
REL='evidence/randomized-forward-20261015-r13'
BASE='b5f1e89a374f4f521f9c78238952066fa75b0e92'
def put(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
def run(a):
    p=subprocess.run(a,cwd=REPO,capture_output=True,text=True,encoding='utf-8');assert p.returncode==0,p.stderr;return p.stdout
assert run(['git','rev-parse','HEAD']).strip()==BASE and not run(['git','status','--porcelain']).strip()
task=json.loads(Path('D:/codex/리드/ai-forward-crossover-20261015-r12/TASK.json').read_text(encoding='utf-8'))
new=['tools/analysis/termination_randomized_forward.py','tools/analysis/test_randomized_forward.py','Run-HCR-Randomized-Forward.cmd']
task.update(taskId='ai-randomized-forward-20261015-r13',objective='전진 변동의 CPU 사용/잔여경과 분해와 같은정보·6900초 무작위 반복 C0/C1 전체비용 재검증',
 scope={'included':[REL+'/**',*new,'.gitattributes','README.md'],
 'excluded':['src/**','HCR-Evidence/**','archive/**','configs/**','.github/**','experiments/**','evidence/forward-crossover-20261015-r12/**','evidence/certificate-cost-20261015-r11/**',
 'tools/analysis/termination_compare_core.py','tools/analysis/termination_compare_runner.py','tools/analysis/check_termination_comparison.py','tools/analysis/termination_certificate_cost.py','tools/analysis/test_certificate_cost.py','tools/analysis/termination_forward_crossover.py','tools/analysis/test_forward_crossover.py','Run-HCR-Forward-Crossover.cmd']},
 workUnits=[{'id':'implementation','objective':'독립 토론/무작위 순서 및 수동 계측/검산 사전동결','dependencies':[],'writeTargets':[REL+'/**',*new,'.gitattributes']},
 {'id':'results','objective':'4cold무작위 반복/원인 분해·전체비용/검증·원자료 보고','dependencies':['implementation'],'writeTargets':[REL+'/**','README.md']}],
 acceptanceCriteria=['[AC-001] 독립토론2·필요 교차검토/순서 추첨 전 규칙·한번 추첨/동일정보·6900 사전동결',
 '[AC-002] 공통 수동 CPU/경과 계측·원숫자출력·GC 보존/독립 기대값 테스트',
 '[AC-003] 독립cold 무작위4셀·각1575 cap/실패·미실행 고정분모4',
 '[AC-004] 원본predicate·공통whole7·성공certificate 검산/원인 한계·전체비용 재집계',
 '[AC-005] raw/hash/sourcepins/scope/GPG 작업단위commitpush·원격clean'],
 constraints=['same graph/model/x0/grid30/cadence16/eps1e-6/radius1e-5/tick6144; future/truth/anchor/cache not policy inputs',
 '4*(1575policy+10eval+10sharedcleanup)+30setup+450verify=6860/global6900; unallocated40 not recycled',
 'no extra numerical probes, GC/affinity/priority/power settings unchanged, passive observer charged both arms',
 'single random draw before science, no sequence rejection/redraw, no retries',
 '4complete+quality+fullverification required for wholecost win; else censored abstain, raw denominator4',
 'historical178.386cause remains unknown; no hardware attribution from proxy or posthoc adjusted speedup',
 'R081closed/native/fullEngine/API/Cloud/install/globalconfig0'],
 authorization={'allowedActions':['scoped research implementation and 4 bounded cold cells','signedcommit/mainFF/localbranchdelete/ordinary originmainpush/readback'],
 'prohibitedActions':['forcepush','deploy','globalconfig','native','R081resume','paidAPI','newDriveupload'],'approvalRequired':[]})
put(OP/'TASK.json',task)
put(OP/'capture.request.json',{'schemaVersion':'1.0.0','mode':'capture','repositoryRoot':str(REPO),'comparisonTarget':'working-tree','taskEnvelope':task,'maxFiles':100000})
baseline=json.loads(run(['node',str(SK/'change-scope-guardian/scripts/capture-workspace-baseline.mjs'),str(OP/'capture.request.json')]))
put(OP/'baseline.json',baseline)
run(['git','switch','-c','research/randomized-forward-implementation'])
(REPO/REL).mkdir(exist_ok=False)
old=Path('D:/codex/리드/ai-forward-crossover-20261015-r12')
control=(old/'control.py').read_text(encoding='utf-8').replace('ai-forward-crossover-20261015-r12','ai-randomized-forward-20261015-r13').replace('forward-crossover-20261015-r12','randomized-forward-20261015-r13')
control=control.replace("BASE='f12b01f62df30e1519040cf74f885e73b3ea58b8'",f"BASE='{BASE}'").replace("operation='r12-'","operation='r13-'")
control=control.replace('동일 전진 계산 시간이 178.4초 늘어난 원인을 분리하고, 실행 순서를 교차한 반복 대조로 개선 C의 전체 비용을 검증해줘. 같은 정보·총예산을 유지하고 토론스킬 먼저 적용해.', '전진 계산 시간의 변동 원인을 더 좁히고, 실행 순서를 무작위화한 반복 대조로 개선 C의 전체 비용을 재검증해줘. 같은 정보·총예산을 유지하고 토론스킬 먼저 적용해.')
control=control.replace('r12 fixed-graph C0/C1 crossover four-cell artifacts and scoped dual-clock/GC observer/test/launcher;', 'r13 fixed-graph C0/C1 randomized four-cell artifacts and passive thread accounting observer/test/launcher;')
# Unsafe historical prepare action is unavailable, not carried forward as runnable code.
start=control.index("    if action=='prepare':")
end=control.index("    elif action=='scope':",start)
control=control[:start]+control[end:].replace("    elif action=='scope':","    if action=='scope':",1)
with (OP/'control.py').open('x',encoding='utf-8',newline='\n') as f:f.write(control)
sign=(old/'sign.py').read_text(encoding='utf-8').replace('forward-crossover','randomized-forward').replace('termination_forward_crossover','termination_randomized_forward').replace('test_forward_crossover','test_randomized_forward').replace('Run-HCR-Forward-Crossover','Run-HCR-Randomized-Forward').replace('freeze dual-clock forward crossover study','freeze randomized forward accounting study').replace('report balanced certificate total-cost crossover','report randomized certificate total cost')
with (OP/'sign.py').open('x',encoding='utf-8',newline='\n') as f:f.write(sign)
pins=json.loads((REPO/'evidence/forward-crossover-20261015-r12/execution-contract.json').read_text(encoding='utf-8'))['code_pins']
pins.append({'path':'evidence/forward-crossover-20261015-r12/execution-contract.json','bytes':(REPO/'evidence/forward-crossover-20261015-r12/execution-contract.json').stat().st_size,'sha256':hashlib.sha256((REPO/'evidence/forward-crossover-20261015-r12/execution-contract.json').read_bytes()).hexdigest()})
put(OP/'source-pins.json',pins)
attrs=REPO/'.gitattributes';raw=attrs.read_bytes();nl=b'\r\n' if b'\r\n' in raw else b'\n'
attrs.write_bytes(raw+b'Run-HCR-Randomized-Forward.cmd text eol=lf'+nl)
print(json.dumps({'baseline':baseline['manifestSha256'],'source_pins':len(pins)}))
