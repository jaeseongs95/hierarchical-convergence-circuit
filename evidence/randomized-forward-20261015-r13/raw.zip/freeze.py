from control import *
import os,time
sys.path.insert(0,str(REPO/'tools/analysis'))
import termination_randomized_forward as study
old=read(REPO/'evidence/forward-crossover-20261015-r12/execution-contract.json')
pins=read(OP/'source-pins.json')
for ref in pins:assert sha(REPO/ref['path'])==ref['sha256']
for name in ['tools/analysis/termination_randomized_forward.py','tools/analysis/test_randomized_forward.py','Run-HCR-Randomized-Forward.cmd']:
    p=REPO/name;pins.append(dict(path=name,bytes=p.stat().st_size,sha256=sha(p)))
assert b'\r' not in (REPO/'Run-HCR-Randomized-Forward.cmd').read_bytes()
def pin(p):return dict(path=p.relative_to(REPO).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
run([PY,'-B','-X','utf8','tools/analysis/test_certificate_cost.py'],'old-five-precheck')
run([PY,'-B','-X','utf8','tools/analysis/test_randomized_forward.py'],'final-fourteen-precheck')
put(OP/'api-only-precheck.json',dict(start=study.thread_snapshot(),end=study.thread_snapshot(),
    clocks=study.base.clock_inventory(),python=sys.version,math_calls=0,utc=now()))
protocol=dict(schema='HCCBlockedRandomizationProtocol.v1',code_pins=pins,freeze_utc=now(),
 allocation_space=[['C0','C1','C0','C1'],['C1','C0','C0','C1'],['C0','C1','C1','C0'],['C1','C0','C1','C0']],
 entropy='one os.urandom(32); first byte bit0=block1, bit1=block2; 0=C0,C1; 1=C1,C0',
 acceptance='single draw, no rejection/no redraw regardless of result; no host-load-based launch selection',
 wholecost='fourcomplete+allquality+fullverification; then mean of two adjacent C1-C0<0, descriptive only',
 reservations_seconds=6860,outer_cap_seconds=6900,draw_debit_from_unallocated40=True,
 CPU_windows='start before first advance/stride128 boundary; end before cert; include persistence/history/wrappers. certificate separate excludes subsequent gate bookkeeping',
 common_prefix='allfour have immutable complete window at same tick; NOT_RUN means no allfour prefix; open windows partial',
 diagnostics='signed forward-window wall minus mainthreadCPU; whole residual is accounting remainder; no statistical window samples',
 forbidden=['redraw','extra numeric probe','GC/power/priority/affinity changes','posthoc host adjustment','historical runtime correction'])
put(PUB/'randomization-protocol.json',protocol)
# Final runner/verifier bytes and aggregation rules above are fixed before this single entropy call.
q0=time.perf_counter_ns();seed=os.urandom(32).hex();order=study.assignment(seed)
draw=dict(schema='HCCBlockedDraw.v1',protocol_sha256=sha(PUB/'randomization-protocol.json'),
    seed_hex=seed,order=order,source='os.urandom(32)',generated_utc=now(),
    coordinator_statement='exactly one entropy draw in this work; external proof of no discarded prior draws unavailable')
put(PUB/'randomization-draw.json',draw)
q1=time.perf_counter_ns();debit=(q1-q0)/1e9
put(PUB/'randomization-timing.json',dict(schema='HCCDrawDebit.v1',draw_sha256=sha(PUB/'randomization-draw.json'),
    before_entropy_qpc_ns=q0,after_draw_receipt_qpc_ns=q1,debit_seconds=debit,
    boundary='before entropy through closing immutable draw receipt; timing attestation and contract preparation outside draw interval',
    actual_watchdog_debit=True))
assert 0<=debit<40
cfg=dict(old)
cfg.update(schema='HCCRandomizedForwardContract.v1',source_commit=BASE,code_pins=pins,
 order_selection=protocol['entropy'],sequential_order=order,cell_ids=[f'{i+1:02d}-{v}' for i,v in enumerate(order)],
 randomization_protocol_pin=pin(PUB/'randomization-protocol.json'),draw_pin=pin(PUB/'randomization-draw.json'),
 draw_timing_pin=pin(PUB/'randomization-timing.json'),draw_debit_seconds=debit,
 causal_estimand='instrumented mean of two independently order-randomized adjacent C1-C0 pairs; same selected graph only',
 observer='r12 original plus same passive 16tick forward/certificate native CPU+rawcycle windows, observer charged to both arms',
 cpu='native thread/process user/kernel snapshots; signed wall-CPU not pure offCPU; cycles raw never GHz/elapsed conversion; no percallback new CPU sums',
 win_rule=protocol['wholecost'],
 common_prefix_rule=protocol['common_prefix'],
 historical_cause='NOT_IDENTIFIED; r11/r12 not retrospectively reconstructed',
 initial_clock_observation=read(OP/'api-only-precheck.json'),
 limits=['n2/arm and4allocationsequences descriptive; windows not independent samples',
 'randomization does not ensure period balance, no interference/carryover exclusion',
 'mixed forwardwindow not pure numericCPU; CPU unit100ns not precision/update guarantee; signed residual unclipped',
 'CPU API failure unavailable notzero, wholecost independent of auxiliary diagnostics availability',
 'cycles not retiredinstructions/frequency, hardware/cache/thermal/background culprit unmeasured',
 'same pinned helpers/acceptedanchor trusted; no independent nonlinear fullprefix replay',
 '1575sec cap no completion guarantee; no unused cap reallocation or retries'],
 external_sources=['https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getthreadtimes',
 'https://learn.microsoft.com/en-us/windows/win32/api/realtimeapiset/nf-realtimeapiset-querythreadcycletime',
 'https://docs.python.org/3.12/library/time.html'],freeze_utc=now())
cfg.pop('order_seed',None)
put(PUB/'execution-contract.json',cfg)
panel=dict(schema='HCCDeliberationSummary.v1',risk='MEDIUM',execution_assurance='degraded_ok',
 participants=[dict(agent='/root/forward_mechanisms_r13',role='performance/measurement'),
 dict(agent='/root/randomization_validity_r13',role='randomization/budget')],
 blind='two fresh fork_turns:none, readonly, no redelegation; each one conditional cross; coordinator integration',
 assurance='partially_independent; later source followups reused same reviewers, not independent audit',
 actual_model_effort='UNKNOWN inherited; no explicit model override',judge=None,reserve=None,specialist=None,
 consensus=['two independent blocked bit orders; no forced opposite ordering','same four1575/total6900/noF/noextra math',
 'native rawCPU/cycles windows separate forwardpipeline andcertificate, unavailable explicit, residual unclipped',
 'no hardware/frequency/descheduling-only claim; no host normalization, no historical correction',
 'all4 quality/fullverification required wholecost descriptive outcome'],
 cross_triggers=['mixedforwardwindowscope/CPUalias andcost','drawfinalsource/debitcustody/no-redraw'],
 cross_resolution=['exact window and commonprefix boundaries; windows not samples; null auxiliary does notinvalidate QPC',
 'immutable protocolfinalcodepins then1draw; receiptthroughclose debit; actualwatchdog reduced6900-debit'],
 source_findings=[dict(issue='draw debit raw timing not bound',resolution='pinned timing rawQPC exact calculation checked'),
 dict(issue='predraw protocol code pins not bound',resolution='protocol codepins equals runtimecontract codepins'),
 dict(issue='partial file count could mean completed windows',resolution='renamed saved files notvalidated complete'),
 dict(issue='inherited verification timer excludes supplement',resolution='fullbody timer now includes supplement, old timer separatelynamed')],
 remaining_unknowns=['runtime variation underlyingcause','no independent proof of no discarded entropy outside observedrun'],
 dot=dict(original_question_id='5f9cb043-ea81-42f1-87de-72faeebf5973',latest_one_turn_read='no source-bound graph research advice observed; hasMore true',unknown_delivery_not_resent=True),utc=now())
put(PUB/'deliberation-summary.json',panel)
_,digest=study.contract()
put(PUB/'pre-execution-verification.json',dict(schema='HCCRandomizedForwardPrecheck.v1',status='PASS',
 contract_sha256=digest,code_pins=len(pins),old_tests=5,new_tests=14,science_cells_started=0,
 engineering_proof='CONSISTENT final isolated signed-residual clip mutation red/green',
 engineering_proof_sha256=sha(OP/'ENGINEERING-PROOF.final.actual.json'),
 initial13testproof='retained superseded after receiptbinding fixes; not current proof',
 actual_order=order,draw_debit_seconds=debit,utc=now()))
print(json.dumps(dict(contract_sha256=digest,order=order,pins=len(pins),draw_debit_seconds=debit)))
