from control import *
import shutil,zipfile
assert read(OP/'run/execution-end.json')['supervision']['active_processes']==0
snap=OP/'source-snapshot';snap.mkdir(exist_ok=False)
for ref in read(PUB/'execution-contract.json')['code_pins']:
    source=REPO/ref['path'];target=snap/ref['path'];target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target);assert sha(target)==ref['sha256']
shutil.copyfile(REPO/'.gitattributes',snap/'.gitattributes')
for name in ('execution-contract.json','deliberation-summary.json','pre-execution-verification.json','post-execution-verification.json','randomization-protocol.json','randomization-draw.json','randomization-timing.json'):
    target=snap/REL/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(PUB/name,target)
files=sorted(p for p in OP.rglob('*') if p.is_file() and p.name!='RAW-INVENTORY.json')
inventory=[{'path':p.relative_to(OP).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]
put(OP/'RAW-INVENTORY.json',{'schema':'HCCRawInventory.v1','files':inventory,
 'coverage':'OP files present at archive creation; later Git delivery/acceptance excluded; initial and final testproof distinguished'})
archive=PUB/'raw.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files+[OP/'RAW-INVENTORY.json']:z.write(p,p.relative_to(OP).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert set(z.namelist())=={f['path'] for f in inventory}|{'RAW-INVENTORY.json'}
    for ref in inventory:
        b=z.read(ref['path']);assert len(b)==ref['bytes'] and hashlib.sha256(b).hexdigest()==ref['sha256']
put(PUB/'raw-manifest.json',{'schema':'HCCForwardRawBundle.v1','path':REL+'/raw.zip','bytes':archive.stat().st_size,
 'sha256':sha(archive),'files':len(files)+1,'inventory_sha256':sha(OP/'RAW-INVENTORY.json'),
 'all_members_crc_hash_size_checked':True,'later_delivery_acceptance_not_in_archive':True,'utc':now()})
print(json.dumps({'bytes':archive.stat().st_size,'files':len(files)+1,'sha256':sha(archive)}))
