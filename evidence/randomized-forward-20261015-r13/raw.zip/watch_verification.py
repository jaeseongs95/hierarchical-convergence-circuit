from pathlib import Path
import json,time
OP=Path(__file__).resolve().parent
p=OP/'run/study/verification'
def read(path):
    try:return json.loads(path.read_bytes())
    except (OSError,json.JSONDecodeError):return None
result=read(p/'result.json');supervision=read(p/'supervision.json');end=read(OP/'run/execution-end.json')
stdout=p/'stdout.txt';err=p/'stderr.txt'
print(json.dumps(dict(approx_wall_since_stdout_creation_seconds=time.time()-stdout.stat().st_ctime if stdout.exists() else None,
    approximation_not_budget_evidence=True,result_status=(result or {}).get('status'),
    supervision_status=(supervision or {}).get('status'),ended=end is not None,
    stderr_tail=err.read_text(encoding='utf-8',errors='replace')[-1600:] if err.exists() and err.stat().st_size else None),ensure_ascii=False))
