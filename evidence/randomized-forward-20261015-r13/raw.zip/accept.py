from control import *
def canonical(o):return json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
task=read(OP/'TASK.json');files=run(['git','diff','--name-only',BASE,'HEAD'],'final.changed-files').splitlines()
allowed={'.gitattributes','Run-HCR-Randomized-Forward.cmd','tools/analysis/termination_randomized_forward.py','tools/analysis/test_randomized_forward.py','README.md'}
assert files and all(p in allowed or p.startswith(REL+'/') for p in files)
for ref in read(PUB/'execution-contract.json')['code_pins']:assert sha(REPO/ref['path'])==ref['sha256']
manifest=[dict(path=p,sha256=sha(REPO/p),bytes=(REPO/p).stat().st_size) for p in files]
put(OP/'FINAL.manifest.json',manifest);target='sha256:'+hashlib.sha256(canonical(manifest)).hexdigest()
head=run(['git','rev-parse','HEAD'],'final.head').strip();assert head==read(OP/'results.delivery.json')['head']
assert not run(['git','status','--porcelain'],'final.clean').strip()
proof=read(OP/'run/study/verification/result.json');end=read(OP/'run/execution-end.json')
assert proof['status'] in ('PASS','PASS_INTEGRITY_ONLY')
comparison=read(PUB/'comparison.json')
if proof['status']=='PASS_INTEGRITY_ONLY':
    assert not proof['quality_all_four'] and not comparison['full_cost_eligible']
    assert comparison['verdict']=='ABSTAIN_INCOMPLETE_EVIDENCE' and not comparison['wholecost_win']
assert len(comparison['records'])==4
assert all(r['status'] in ('COMPLETE','BUDGET_INCOMPLETE') for r in comparison['records'])
assert read(OP/'results.scope.json')['verdict']=='PASS'
assert end['supervision']['active_processes']==0 and not end['exceeded']
facts=[(PUB/'execution-contract.json',['AC-001','AC-003'],'동일 정보/18pins/4cold 각1575·global6900 사전동결'),
 (PUB/'randomization-protocol.json',['AC-001'],'추첨 전 최종 runner/verifier codepins와 blocked4 allocation·판정 동결'),
 (PUB/'randomization-draw.json',['AC-001'],'singleOSentropy32byte/두 독립 bit/순서 결속; 외부 no-discarded-draw 증명 한계'),
 (PUB/'randomization-timing.json',['AC-001','AC-003'],'원시QPC 전후·drawreceipt close debit을 실제watchdog6900에서 차감'),
 (PUB/'deliberation-summary.json',['AC-001'],'freshblind2와 각 조건부cross/후속 source재사용 한계 및 결속공백 해소'),
 (PUB/'pre-execution-verification.json',['AC-002'],'원필터5·최종14unit PASS, 초기13 proofsuperseded'),
 (OP/'ENGINEERING-PROOF.final.actual.json',['AC-002'],'격리동일 테스트/argv signedresidualclip actualredgreen canonicalCONSISTENT'),
 (OP/'run/execution-start.json',['AC-001','AC-003'],'시작 전 계약SHA/draw/debit 및 실제 outerdeadline 결속'),
 (OP/'run/execution-end.json',['AC-003'],'전체chargedQPC<6900/active0·retries0'),
 (OP/'run/study/verification/result.json',['AC-002','AC-004'],f"고정 감독 검산 {proof['status']}: full7/predicate 및 완료셀 nativewindow; 전체4품질 조건 불충족을 보존"),
 (PUB/'post-execution-verification.json',['AC-002','AC-004'],'18pins불변·감독검산 범위/예산/잔존0·부분결과 구별'),
 (PUB/'comparison.json',['AC-003','AC-004'],'고정분모4/두pair와mean/raw4/forwardservice·signedresidual 및 원인한계'),
 (OP/'POSTCHECK.actual.json',['AC-003','AC-004'],'원자료 집계와 전체비용평균 보류/서비스회계 보존'),
 (PUB/'raw-manifest.json',['AC-005'],'zip모든 member CRC/bytes/SHA·source snapshot 대조'),
 (PUB/'report.ko.md',['AC-004'],'순수숫자CPU/하드웨어cause/통계우위와 bounded관측을 구별'),
 (OP/'implementation.scope.json',['AC-005'],'최초 clean TASK baseline 구현10파일 scopePASS'),
 (OP/'results.scope.json',['AC-005'],'같은 최초baseline 전체 허용변경 범위PASS'),
 (OP/'implementation.verify-signature.json',['AC-005'],'구현OpenPGP Goodsignature실제검증'),
 (OP/'results.verify-signature.json',['AC-005'],'결과OpenPGP Goodsignature실제검증'),
 (OP/'results.delivery.json',['AC-005'],'일반origin/mainpush·실제원격SHA/rawbytes/mainclean확인')]
evidence=[]
for p,ids,msg in facts:
    assert p.is_file()
    if p.name.endswith('verify-signature.json'):
        r=read(p);assert r['exit_code']==0 and 'Good signature' in r['stderr']
    evidence.append(dict(id='E'+str(len(evidence)+1),kind='document',locator=str(p),digest='sha256:'+sha(p),
        targetDigest=target,verified=True,criterionIds=ids,direction='supports',observedResult=msg))
request=dict(schemaVersion='1.0.0',taskEnvelope=task,target=dict(kind='commit',identifier=head,digest=target),
 evidence=evidence,verificationCommands=[],criterionOverrides=[],knownLimitations=[
 'boundedresearch AC충족과 개선가설 성공은 별개; C0두셀예산미완료로 완료전체비용평균 보류/partial분모보존',
 'PASS_INTEGRITY_ONLY는 품질4/4 또는 네완료판정 아님; frozennativewindow검산은 COMPLETE셀에한정',
 '부분셀 commonclosedprefix nativecounter·state digest는 별도 보고 집계의 비수치 재계산; 추가 숫자궤적/predicate probe0',
 'n2/arm·4possibleallocations·windows 독립표본아님, drift/carryover/host간섭 제거보장0',
 'mixedforwardpipeline CPU, signedresidual은순수offCPU아님; cyclesGHz/elapsed변환금지',
 'CPU자료형100ns가갱신정확도보장X; APIunavailable0대체금지/원값bracket보존',
 '과거178.386/r12변동 특정cause미식별, host회귀보정/반사실speedup0',
 '동일 알려진 합성world/graph 독립발견0; fullEngine/adoption/native/에너지미측정',
 '공유 pinnedhelpers/acceptedoldanchor신뢰, 독립nonlinear fullprefixreplay0',
 '최초13proofsuperseded/최종14+원필터5만실행, old24PASS1timingfailure유지',
 'dot최근제한범위NOT_OBSERVED hasMoretrue, 원질의unknown 중복전송0',
 'actualmodel/effortUNKNOWN, Judge0; source/result재사용reviewer 새독립audit아님',
 'archive생성이후accept/delivery는 봉인zip밖 별도로컬자료'])
put(OP/'ACCEPTANCE.request.json',request);cli=SK/'acceptance-evidence-validator/scripts'
report=json.loads(run(['node',cli/'cli.mjs','--input',OP/'ACCEPTANCE.request.json'],'ACCEPTANCE-RUN'))
put(OP/'ACCEPTANCE.actual.json',report);assert report['verdict']=='PASS',report
pin=dict(artifactId='randomized-forward-acceptance-'+head[:8],
 schemaId='https://agent-governance-skills.local/acceptance-evidence-validator/contracts/acceptance-evidence-input.v1.schema.json',
 locator=str(OP/'ACCEPTANCE.request.json'),digest='sha256:'+hashlib.sha256(canonical(request)).hexdigest())
put(OP/'ACCEPTANCE.request-pin.json',pin)
check=json.loads(run(['node',cli/'validate-report.mjs','--request',OP/'ACCEPTANCE.request.json','--request-artifact',OP/'ACCEPTANCE.request-pin.json','--report',OP/'ACCEPTANCE.actual.json'],'ACCEPTANCE-VALIDATE-RUN'))
put(OP/'ACCEPTANCE-VALIDATE.actual.json',check);assert check['valid']
print(json.dumps(dict(verdict='PASS',valid=True,criteria=5,head=head)))
