from pathlib import Path
import json,time
OP=Path(__file__).resolve().parent
out=OP/'run';rows=[]
def read(p):
    try:return json.loads(p.read_bytes())
    except (OSError,json.JSONDecodeError):return None
for cid in ['01-C1','02-C0','03-C0','04-C1']:
    p=out/'study'/cid;r=read(p/'row.json');states=list(p.glob('state-*.json'))
    item=dict(cell=cid,status=r['status'] if r else 'RUNNING' if p.exists() else 'NOT_STARTED',
        latest_state_filename_tick=max((int(x.stem.split('-')[-1]) for x in states),default=None),
        latest_state_filename_not_commit_proof=True,
        saved_forward_window_files=len(list(p.glob('forward-window-*.json'))))
    if r:item.update(wall=r['policy_supervision']['highres_wall_seconds'],evaluation=(r.get('evaluation') or {}).get('candidate_correct'))
    err=p/'stderr.txt'
    if err.exists() and err.stat().st_size:item['stderr_tail']=err.read_text(encoding='utf-8',errors='replace')[-1000:]
    rows.append(item)
result=dict(observed_qpc_ns=time.perf_counter_ns(),rows=rows,
    ended=(out/'execution-end.json').exists(),verification=(read(out/'study/verification/result.json') or {}).get('status'),
    supervision=read(out/'study/verification/supervision.json'))
with (OP/'observations.jsonl').open('a',encoding='utf-8',newline='\n') as f:f.write(json.dumps(result,ensure_ascii=False)+'\n')
print(json.dumps(result,ensure_ascii=False))
