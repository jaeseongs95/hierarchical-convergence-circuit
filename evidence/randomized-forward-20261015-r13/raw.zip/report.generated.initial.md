# 무작위 반복 대조와 전진 파이프라인 CPU 회계 — r13

## Executive Verdict

판정은 **ABSTAIN_INCOMPLETE_EVIDENCE**다. 두 pair의 C1−C0 전체 비용은 [None, None]초, 판정 가능한 전체 평균 미측정초다. 음수는 C1이 빠르다는 뜻이며 None은 누락·미완료로 판정 불가다. C0/C1 완료 비용 평균=None, 증감률=None%. 불완전 셀이 있으면 완료 셀만의 평균·timeout 소비량으로 완료 비용을 대신하지 않는다. 관측된 기술적 결과이며 통계적·보편적 우위나 F 대비 개선을 뜻하지 않는다.

## Consensus Proposal

실행 상태는 **consensus**다. 최종 실행·검산 코드18핀과 배정·판정 규칙을 먼저 불변 파일로 고정한 뒤 OS entropy32byte를 한 번 생성했다. 첫 바이트의 독립 bit 두 개로 인접 block별 순서를 정했으며, 결과는 ['C1', 'C0', 'C0', 'C1']였다. 두 block을 반대로 강제하지 않았다. 가능한 배정은4개다. 재추첨·거부·호스트 부하를 보고 시작 시점을 고르는 조작은 하지 않았다. 이 절차의 로컬 기록은 보존하지만 과거에 폐기된 난수가 전혀 없었다는 외부 증명은 아니다.

## Strong Consensus

같은 graph/model/x0/grid30/cadence16/tickcap6144/epsilon1e-6/radius1e-5와 원 C0/C1 수치 코드를 유지했다. 첫 필터는 t16이다. 정책 입력은 현재 모델과 whole7 box·고정 반경·epsilon뿐이며 과거 궤적·정답·anchor·host 관측·시계 값을 숫자 helper에 넣지 않았다. 네 셀 모두 독립 cold process다. 정책1575·평가10·공유cleanup10초씩, setup30·검산450, 예약합6860·전체6900초와 여유40초를 유지했다. 추첨→draw 기록 파일 close까지 0.0128616초를 원시 QPC로 기록하고 실제 outer watchdog/deadline에서 차감했다. 추첨 timing attestation·계약 준비·개발 테스트는 추첨 구간 밖 준비 작업이다. 미사용 예산 재배정·재시도·F 추가·수치 probe·GC/affinity/priority/power 설정 변경은 없다.

## Material Disagreements

전체 wall 변동을 순수 탈스케줄링이나 CPU 주파수 하나로 설명할 수 없다. 과거 r12의 같은 C1 두 실행에서 전체 wall은116.277초 줄고 Job CPU는158.859초 줄었지만, 이는 정책 전체 회계이므로 숫자 함수 CPU로 배분하지 않는다. 이번 새 창은 그 경계를 전진 파이프라인과 인증으로 좁힌다. 원인 자체를 결정하는 개입 실험은 아니다. 과거 +178.386초와 r12 수치 elapsed 변동의 단일 원인은 여전히 **NOT_IDENTIFIED**다.

## Decision by Axis

| 순서·정책 | 상태 | tick | 전체 QPC(s) | Job CPU(s) | 후보 정오/거리 |
|---|---|---:|---:|---:|---|
| 01-C1 | COMPLETE | 5168 | 1276.783 | 1174.594 | True/INSIDE |
| 02-C0 | BUDGET_INCOMPLETE | 4900 | 1575.012 | 1429.406 | False/OUTSIDE |
| 03-C0 | BUDGET_INCOMPLETE | 4185 | 1575.004 | 1441.828 | False/OUTSIDE |
| 04-C1 | BUDGET_INCOMPLETE | 4759 | 1575.003 | 1395.062 | False/OUTSIDE |

| 셀 | 전진 창 wall | 주 스레드 CPU | wall−CPU | 인증 창 wall | 인증 CPU | 전체 회계 잔여 |
|---|---:|---:|---:|---:|---:|---:|
| 01-C1 | 1202.985 | 1103.469 | 99.516 | 72.084 | 69.875 | 1.714 |
| 02-C0 | 미측정 | 미측정 | 미측정 | 미측정 | 미측정 | 미측정 |
| 03-C0 | 미측정 | 미측정 | 미측정 | 미측정 | 미측정 | 미측정 |
| 04-C1 | 미측정 | 미측정 | 미측정 | 미측정 | 미측정 | 미측정 |

전진 창은 초기 상태 저장 뒤 첫 advance 직전(128tick 블록 쓰기보다 전)부터 현재16tick 상태 저장 뒤 certificate 호출 직전까지다. 수치 계산·상태 저장·history·wrapper·일부 관측을 포함하며 인증과 이후 gate bookkeeping은 제외한다. 인증 창은 별도로 동일 API를 읽는다. 새 창 쓰기와 snapshot 사이 틈은 전체 정책에 과금된다. 전체 회계 잔여=전체−전진 창합−인증 창합이며 초기화·감독·직렬화·gate 기록·관측 등을 포함한다. **전진 창 wall−주 스레드CPU**와 이 회계 잔여는 다른 값이다. 어느 것도 순수 호스트 간섭 시간은 아니다.

| 지표 | pair1 C1−C0 | pair2 C1−C0 | 평균 |
|---|---:|---:|---:|
| whole_policy | 미측정 | 미측정 | 미측정 |
| Job_CPU | 미측정 | 미측정 | 미측정 |
| advance_parent | 미측정 | 미측정 | 미측정 |
| numeric_nested | 미측정 | 미측정 | 미측정 |
| forward_wall_seconds | 미측정 | 미측정 | 미측정 |
| forward_thread_cpu_seconds | 미측정 | 미측정 | 미측정 |
| forward_wall_minus_thread_cpu_seconds | 미측정 | 미측정 | 미측정 |
| certificate_wall_seconds | 미측정 | 미측정 | 미측정 |
| certificate_thread_cpu_seconds | 미측정 | 미측정 | 미측정 |
| whole_accounting_remainder | 미측정 | 미측정 | 미측정 |

원래 전진 부모와 수치 하위, GC, 시계 차이는 원 trace에 그대로 보존했다. 전진 부모·수치 하위·GC는 겹치므로 합산하지 않는다. Job CPU·process CPU·thread CPU 역시 관측 경계가 다르며 outer/inner CPU는 중복 합산하지 않는다.



같은 정책 내 반복 차이도 시간 순서와 환경 변화가 섞인 기술적 진단이다. 창은 독립 표본이 아니며 무작위 배정 단위는 네 셀이다. 모든 대상 셀에서 닫힌 불변 창이 연속으로 존재하는 마지막 공통 경계=4176tick이다. 열린 창·단순 상태 파일·일부 arm만의 창을 공통 완료 작업량으로 세지 않는다.

| 셀 | 공통 tick | 닫힌 창 수 | 전진 창 wall | 주 스레드CPU | signed wall−CPU |
|---|---:|---:|---:|---:|---:|
| 01-C1 | 4176 | 261 | 968.304 | 889.219 | 79.085 |
| 02-C0 | 4176 | 261 | 1186.581 | 1069.141 | 117.440 |
| 03-C0 | 4176 | 261 | 1365.318 | 1244.141 | 121.177 |
| 04-C1 | 4176 | 261 | 1327.418 | 1167.359 | 160.059 |

| 공통 전진 prefix 지표 | pair1 C1−C0 | pair2 C1−C0 | 평균 |
|---|---:|---:|---:|
| wall_seconds | -218.277 | -37.899 | -128.088 |
| mainthread_cpu_seconds | -179.922 | -76.781 | -128.352 |
| signed_wall_minus_mainthread_cpu_seconds | -38.355 | 38.882 | 0.263 |

- C0 02-C0→03-C0의 공통 4176tick 전진 창 차이(later−earlier): {'wall_seconds': 178.73662049999825, 'mainthread_cpu_seconds': 175.0, 'signed_wall_minus_mainthread_cpu_seconds': 3.736620499998253, 'process_cpu_seconds': 175.0, 'raw_cycles': 574978032462}
- C1 01-C1→04-C1의 공통 4176tick 전진 창 차이(later−earlier): {'wall_seconds': 359.1141633000001, 'mainthread_cpu_seconds': 278.140625, 'signed_wall_minus_mainthread_cpu_seconds': 80.97353830000009, 'process_cpu_seconds': 278.140625, 'raw_cycles': 912522472388}

이 공통 prefix는 완료 비용이 아닌 동일 전진 구간의 진단이다. 고정 검산기의 native창 검사는 COMPLETE셀에 한정된다. 불완전 셀의 닫힌 창은 이 보고 집계에서 원시 counter 차분·동일PID/TID·연속경계·상태digest를 다시 대조했으며 추가 수치 궤적·predicate 계산은 하지 않았다. 집계 시간은 comparison의 postseal_nonnumerical_aggregation_seconds에 별도로 남기며 정책 비용이나 고정 과학 실행 시간으로 합치지 않는다. 계측 CPU는 서비스시간 회계 관측이며 산술 고유 비용으로 해석하지 않는다.

예산 내 완료·인증·후보 정오·거리 집계는 비교 원장의 coverage_by_variant에 분모2씩 남겼다: {'C0': {'planned': 2, 'attempted': 2, 'complete': 0, 'certified': 0, 'evaluated': 2, 'candidate_correct': 0, 'inside': 0, 'nominal_policy_cap_seconds': 1575, 'observed_spend_seconds': [1575.0119214, 1575.0037498], 'completed_cost_mean_seconds': None}, 'C1': {'planned': 2, 'attempted': 2, 'complete': 1, 'certified': 1, 'evaluated': 2, 'candidate_correct': 1, 'inside': 1, 'nominal_policy_cap_seconds': 1575, 'observed_spend_seconds': [1276.7825306, 1575.0027715], 'completed_cost_mean_seconds': None}}. 미완료 소비 시간은 성공 완료 비용이 아니다. 평가기가 후보 오답/OUTSIDE를 내더라도 미인증 정책을 성공 종료로 승격하지 않는다.

## Evidence

검산=PASS_INTEGRITY_ONLY, 완료=1/4, 품질=False. 공통 기준 full7 상태 비교=13847, fresh 원본 predicate 고유 입력=323, C1 발생=323. 봉인 후 동일 전체 payload·helper핀의 canonical bytes까지 대조한 중복 제거이며 과거 답변 캐시는 아니다. 성공 certificate bytes·최초 tick 동일 판정=False. 공유 pinned helper와 accepted old anchor를 신뢰하며 독립 비선형 fullprefix 재생은 하지 않았다.

각 전진·인증 창은 tick·상태 digest·동일 PID/TID·원시 QPC 순서·native user/kernel 차분·cycle 차분을 봉인 후 대조했다. API 실패는 UNAVAILABLE이며0으로 바꾸지 않는다. 100ns는 CPU 자료형 단위이며 실제 갱신 해상도 보장이 아니다. 특히 짧은 C1 reject의 CPU0은 무비용을 뜻하지 않는다. 부호 있는 residual을0으로 자르지 않았고 읽기 전후 bracket을 보존했다. 관측 원값이 순차로 읽혀 완전히 동시인 경계는 아니다. [Microsoft GetThreadTimes](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getthreadtimes)는 user/kernel 실행시간을 제공한다. [QueryThreadCycleTime 공식 문서](https://learn.microsoft.com/en-us/windows/win32/api/realtimeapiset/nf-realtimeapiset-querythreadcycletime)는 CPU마다 timer 거동이 달라 cycle을 elapsed로 변환하지 말라고 명시한다. 원시 cycle은 주파수·retired instruction으로 해석하지 않았다.

최종14개 경계 테스트(기존7+새7)와 원 필터 테스트5개가 통과했다. 격리 사본에서 같은 테스트·명령을 사용해 residual 음수를 clipping하는 mutation의 실제 실패와 원본 복구 후 성공을 확인했고 canonical proof=CONSISTENT다. 최초13개 proof는 결속 보완 전 이력으로 남겼으며 현재 증거가 아니다. r10의24PASS/시간민감1실패를 재실행하거나25PASS로 바꾸지 않았다.

## Required Actions

새 전체비용 판정은 네 COMPLETE·네 correct/INSIDE·전체 검산 PASS가 모두 있어야 허용한다. 불완전·실패·NOT_RUN은 고정 분모4에 남고 대체 실행은 없다. 전체 검산 본체=410.961초(상속 검산=399.985초), 감독 포함=411.587초다. root 실제 QPC=6417.994, 추첨 차감 포함 총과금=6418.007초<6900 여부=True. 기록된 Job 11개 잔존0 여부=True. hard realtime 보장으로 표현하지 않는다.

## Optional Optimizations

새 최적화나 host 정규화·회귀 보정은 도입하지 않았다. 이번 관측기 비용을 포함한 C0/C1 비교이며 계측 전 속도를 복원하지 않는다. 정책 평균·두 pair 부호·네 원값을 모두 공개했다.

## Unresolved

CPU 서비스시간과 signed 미계상 wall의 관측은 원인 후보를 구별하는 단서를 주지만 순수 산술 고유 비용·cache·allocator/refcount·실주파수·열·특정 background 원인은 미식별이다. ETW·dispatch profiling·코어 residency는 측정하지 않았다. 기본 GC 수동 callback은 collection wall만 관측하며 간접 allocation 효과를 배제하지 않는다. 무작위화는 선택 편향을 줄이지만 실제 period 평균 균형·비선형 drift·carryover·셀 간 간섭 제거를 보장하지 않는다. n2/arm, 배정 공간4로 통상5% 유의성을 주장하지 않는다. 같은 authored synthetic world에서의 진단 후보이고 독립 발견표본0, native/fullEngine/adoption 효율 미측정이다.

## Method / Run Summary

토론스킬 먼저 두 fresh fork_turns:none readonly 관점(performance/measurement, randomization/budget), 각1회 조건부 교차검토, Coordinator 통합으로 실행했다. MEDIUM/degraded_ok, partially_independent; Judge/reserve/specialist 없음, 실제 inherited 모델/추론 수준 UNKNOWN. 후속 소스 검토는 같은 reviewer 재사용이며 새 독립 감사가 아니다. draw debit과 predraw 코드 핀 결속 두 공백, 부분 파일 수 표기와 supplement 검산 시간 표기를 추첨 전에 보완했다. dot의 source-bound 연구 조언은 제한된 최근1turn(hasMore=true) 조회에서 확인되지 않았으며 부재·미전달 확정이 아니다. 새 유효 답변은 날짜와 출처를 붙여 반영한다.

raw.zip/inventory는 생성 시점 OP의 실행·원시창·trace·상태·봉인·평가·검산·테스트·준비·서명 자료와 source snapshot을 보존한다. 그 뒤 만든 acceptance/delivery는 로컬 OP의 별도 근거이며 이미 봉인한 zip 안에 있다고 주장하지 않는다. GPG 서명·scope·main fast-forward·일반 push와 원격 bytes 대조의 실제 영수증을 별도로 확인한다.
