"""Windows read-open vs delete-sharing rename 판별. 연구파일을 열지 않는다."""
from control import *
import ctypes as C, os
from ctypes import wintypes as W
d=OP/'sharing-discriminator-r02';d.mkdir(exist_ok=False)
destination=d/'ack.json';pending=d/'ack.pending'
destination.write_bytes(b'old');pending.write_bytes(b'new')
with destination.open('rb'):
    try:os.replace(pending,destination);default={'replace':'SUCCEEDED'}
    except PermissionError as e:default={'replace':'DENIED','winerror':e.winerror}
assert default=={'replace':'DENIED','winerror':5},default
api=C.WinDLL('kernel32',use_last_error=True)
api.CreateFileW.argtypes=[W.LPCWSTR,W.DWORD,W.DWORD,C.c_void_p,W.DWORD,W.DWORD,W.HANDLE];api.CreateFileW.restype=W.HANDLE
api.CloseHandle.argtypes=[W.HANDLE];api.CloseHandle.restype=W.BOOL
h=api.CreateFileW(str(destination),0x80000000,7,None,3,0,None)
assert h!=C.c_void_p(-1).value
try:
    try:os.replace(pending,destination);shared={'replace':'SUCCEEDED','share_flags':7}
    except PermissionError as e:shared={'replace':'DENIED','share_flags':7,'winerror':e.winerror}
finally:api.CloseHandle(h)
if pending.exists():os.replace(pending,destination)
assert destination.read_bytes()==b'new'
put(OP/'SHARING-DISCRIMINATOR-r02.actual.json',{'status':'PASS','default_read_while_replace':default,
 'share_read_write_delete_while_replace':shared,'source':'owned isolated ack pair only, no research states',
 'observed_failure_cell':'180/L','last_ack_tick':386,
 'causal_scope':'Windows open-target rename conflict confirmed; monitor read preceded failure and can cause it; exact offending reader not instrumented, AV/other reader not excluded',
 'first_failure_preserved':True,'retry_scientific_cells':0,'monitor_after_change':'no mutable ack/progress reads; immutable sealed outputs or filenames only; no policy changes',
 'initial_probe_failure':'share7 alone also denied actual os.replace; initial expectation failure preserved; closed handle allows replace',
 'utc':now()})
print('PASS: held destination denies rename; share7 result recorded; handle close permits rename; no scientific mutation')
