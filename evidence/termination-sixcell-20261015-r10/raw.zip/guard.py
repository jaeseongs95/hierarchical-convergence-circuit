"""추가 메모리 제한 없이 기존 비교기 전체를 owned Job으로 감독한다."""
from pathlib import Path
import ctypes as C
import json, subprocess, sys, time
OP=Path(__file__).resolve().parent
REPO=Path('D:/codex/리드/ai-research-resume-20261008-r01/repository')
sys.path.insert(0,str(REPO/'tools/analysis'))
import termination_compare_runner as runner

class KillOnlyJob(runner.Job):
    def __init__(self):
        super().__init__()
        try:
            limits=runner.ExtendedLimits()
            limits.BasicLimitInformation.LimitFlags=0x2000
            self.call('SetInformationJobObject',self.handle,9,C.byref(limits),C.sizeof(limits))
            actual=self.stats()
            if actual['job_limit_flags']!=0x2000 or actual['job_memory_limit_bytes']!=0:
                raise RuntimeError('outer Job must have kill-on-close only')
        except BaseException:
            self.close();raise

def main():
    if sys.argv[1]=='--probe-child':
        release=json.loads(sys.stdin.readline())
        command=[sys.executable,'-B','-X','utf8','-c','import time; time.sleep(30)']
        result=runner.owned_phase(command,Path(release['out'])/'inner',.4,
                                 release['deadline'],release['deadline'])
        runner.write_new(Path(release['out'])/'probe.json',result)
        return
    if sys.argv[1]=='--self-test':
        result=runner.owned_phase([sys.executable,'-B','-X','utf8',str(Path(__file__).resolve()),'--probe-child'],
            OP/'guard-probe',3,job_factory=KillOnlyJob)
        inner=json.loads((OP/'guard-probe/probe.json').read_text(encoding='utf-8'))
        assert result['status']=='COMPLETE' and result['active_processes']==0
        assert result['job_limit_flags']==0x2000 and result['job_memory_limit_bytes']==0
        assert inner['status']=='BUDGET_INCOMPLETE' and inner['active_processes']==0
        assert inner['job_limit_flags']==0x2200 and inner['job_memory_limit_bytes']==536870912
        runner.write_new(OP/'GUARD-SELF-TEST.actual.json',{'outer':result,'inner':inner,'status':'PASS'})
        print('PASS: nested owned Jobs; outer kill-only; inner 512MiB; timeout tree inactive',flush=True)
        return
    if sys.argv[1]!='--execute':raise ValueError('explicit --execute required')
    contract=json.loads((REPO/'evidence/termination-sixcell-20261015-r10/execution-contract.json').read_text(encoding='utf-8'))
    assert not (OP/'study').exists() and not (OP/'watchdog').exists()
    command=[str(sys.executable),'-B','-X','utf8',str(REPO/'tools/analysis/termination_compare_runner.py'),
             '--execute','--output',str(OP/'study'),'--plan-sha',contract['plan_sha256'],
             '--implementation-sha',contract['implementation_sha256']]
    started=time.monotonic();deadline=started+6900
    runner.write_new(OP/'EXECUTION-START.actual.json',{'argv':command,'start_monotonic':started,
        'deadline_monotonic':deadline,'contract_sha256':runner.hashlib.sha256((REPO/'evidence/termination-sixcell-20261015-r10/execution-contract.json').read_bytes()).hexdigest(),
        'automatic_retry':False})
    result=runner.owned_phase(command,OP/'watchdog',max(.001,deadline-time.monotonic()),
        global_deadline=deadline,cleanup_deadline=deadline+10,job_factory=KillOnlyJob)
    runner.write_new(OP/'EXECUTION-END.actual.json',{'supervision':result,
        'physical_wall_through_supervision_report_seconds':time.monotonic()-started,
        'physical_6900_exceeded':time.monotonic()>deadline,
        'outer_stdin_release_written_not_consumed':True,
        'scientific_retry_count':0,'outer_accounting_overlaps_inner_do_not_sum':True})
    print(json.dumps({'status':result['status'],'active_processes':result['active_processes'],
        'wall_seconds':result['wall_seconds_after_report'],'study_summary_exists':(OP/'study/summary.json').exists()}),flush=True)
if __name__=='__main__':main()
