from control import *
import copy
old=read(PUB/'comparison.json');oldsha=sha(PUB/'comparison.json')
assert [r['certificate'] for r in old['rows'][:3]]==['NOT_CERTIFIED']*3
for source,target in [(PUB/'comparison.json',OP/'comparison.pre-review.json'),(OP/'OFFLINE-VERIFICATION.actual.json',OP/'OFFLINE-VERIFICATION.pre-review.json')]:
    assert not target.exists() and source.is_file()
    source.rename(target)
run([PY,'-B','-X','utf8',OP/'analyze.py'],'POST-REVIEW-VERIFICATION.actual')
new=read(PUB/'comparison.json');expected=copy.deepcopy(old)
for row in expected['rows'][:3]:row['certificate']='NO_FINAL_CERTIFICATE' if row['policy']=='C' else 'NOT_REQUESTED'
assert new==expected,'Only the three absence/status labels may differ'
put(OP/'CERTIFICATE-LABEL-CORRECTION.actual.json',{'status':'PASS','old_comparison_sha256':oldsha,
 'new_comparison_sha256':sha(PUB/'comparison.json'),'changes':[
   {'cell':'180/L','old':'NOT_CERTIFIED','new':'NOT_REQUESTED','evidence':'snapshot/evaluator gateNOT_REQUESTED, region_proofs0'},
   {'cell':'180/F','old':'NOT_CERTIFIED','new':'NOT_REQUESTED','evidence':'snapshot/evaluator gateNOT_REQUESTED, region_proofs0'},
   {'cell':'180/C','old':'NOT_CERTIFIED','new':'NO_FINAL_CERTIFICATE','evidence':'42 recorded prior calls, no final sealed certification; lastsnapshot676 not current gate'}],
 'all_other_payload_exact_equal':True,'independent_verification_repeated_for_changed_output_code':True,
 'no_new_scientific_steps':True,'report_numbers_and_conclusions_unchanged':True,'reviewers_both_reported_same_scoped_issue':True,'utc':now()})
print('PASS label repair only; current source verification PASS; original derivation preserved')
