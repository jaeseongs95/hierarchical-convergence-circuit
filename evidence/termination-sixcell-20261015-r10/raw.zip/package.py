"""완료 원자료를 원본 바이트 그대로 묶고 archive를 직접 검산한다."""
from control import *
import zipfile
assert read(OP/'EXECUTION-END.actual.json')['supervision']['active_processes']==0
assert (PUB/'comparison.json').exists()
paths=[]
for name in ('study','watchdog','guard-probe','timing-discriminator','timing-discriminator-r02','sharing-discriminator','sharing-discriminator-r02'):
    paths.extend(p for p in (OP/name).rglob('*') if p.is_file())
paths.extend(p for p in OP.iterdir() if p.is_file() and p.suffix in ('.json','.py'))
paths=sorted(set(paths),key=lambda p:p.relative_to(OP).as_posix())
manifest=[]
for p in paths:
    assert p.resolve().is_relative_to(OP) and not p.is_symlink()
    manifest.append({'path':p.relative_to(OP).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
put(OP/'RAW-INVENTORY.json',{'schema':'HCCRawInventory.v1','files':manifest,'original_bytes_preserved':True})
archive=PUB/'raw.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in paths:z.write(p,p.relative_to(OP).as_posix())
    z.write(OP/'RAW-INVENTORY.json','RAW-INVENTORY.json')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for ref in manifest:
        raw=z.read(ref['path']);assert len(raw)==ref['bytes'] and hashlib.sha256(raw).hexdigest()==ref['sha256']
put(PUB/'raw-manifest.json',{'schema':'HCCRawBundle.v1','archive':'raw.zip','sha256':sha(archive),
 'archive_bytes':archive.stat().st_size,'file_count':len(paths)+1,'uncompressed_bytes':sum(f['bytes'] for f in manifest),
 'inventory':'RAW-INVENTORY.json inside archive','inventory_sha256':sha(OP/'RAW-INVENTORY.json'),
 'validated':'archive CRC and all inventory byte/hash checks PASS','raw_root_original':str(OP),
 'absolute_paths':'original invocation/seal locators preserved; archive members relative, no in-place relocation or evidence rewriting',
 'first_failures_preserved':['original selftest timingfailure','initial isolated timingfixture missingnumericdependency','180/L atomicrename WinError5 and unacknowledged state387','initial share7 probe assumptionfailure'],
 'science':'single6cell attempted, no scientific retries or closedR081 resume',
 'not_in_archive':'later post-run human report/delivery receipts remain separate; archive created after independent offline verification'})
print(json.dumps({'archive_bytes':archive.stat().st_size,'files':len(paths)+1,'sha256':sha(archive)}))
