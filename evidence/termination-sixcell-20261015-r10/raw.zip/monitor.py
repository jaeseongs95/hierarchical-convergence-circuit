from control import *
import time
out=OP/'study'
start=read(OP/'EXECUTION-START.actual.json')['start_monotonic']
# Do not open any mutable progress/ack file while the study runs.
finished={}
for label in ['180/L','180/F','180/C','1800/C','1800/F','1800/L']:
    d=out/label.replace('/','-');sealed=d/'sealed-cell.json';result=d/'evaluation/result.json'
    if sealed.exists() and result.exists():
        try:
            s=read(sealed);e=read(result)
            finished[label]={'status':s['supervision']['status'],'evaluation':e,'policy_supervision':s['supervision']}
        except json.JSONDecodeError:pass
rows=[]
for label in ['180/L','180/F','180/C','1800/C','1800/F','1800/L']:
    d=out/label.replace('/','-');row={'cell':label}
    if label in finished:
        r=finished[label];e=r.get('evaluation') or {};p=r.get('policy_supervision') or {}
        row.update(status=r['status'],tick=e.get('tick'),candidate=e.get('candidate'),correct=e.get('candidate_correct'),distance=e.get('distance',{}).get('status'),policy_wall=p.get('wall_seconds_after_report'))
    elif d.exists():
        row['status']='ACTIVE'
        names=[p.name for p in d.glob('state-*.json')]
        row['highest_state_filename_tick_not_ack']=max((int(n[6:12]) for n in names),default=None)
    else:row['status']='NOT_STARTED'
    rows.append(row)
print(json.dumps({'elapsed_seconds':round(time.monotonic()-start,2),'rows':rows,'summary_exists':(out/'summary.json').exists(),'end_receipt':(OP/'EXECUTION-END.actual.json').exists()}))
