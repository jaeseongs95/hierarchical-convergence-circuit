"""첫 실패를 덮어쓰지 않고 합성 시험의 시간 전제만 분리한다."""
from control import *
import shutil
fixture=OP/'timing-discriminator-r02';fixture.mkdir(exist_ok=False)
source=REPO/'tools/analysis/test_termination_comparison.py'
raw=source.read_text(encoding='utf-8')
needle="pending=self.phase(body,name='pending-C',cap=.8)"
assert raw.count(needle)==1
candidate=raw.replace(needle,"pending=self.phase(body,name='pending-C',cap=5)")
for name in ('termination_compare_core.py','termination_compare_runner.py','check_termination_comparison.py','check_on_basins.py','check_on_fixed_points.py','check_on_convergence_gate.py','check_on_online_convergence_gate.py'):
    shutil.copyfile(REPO/'tools/analysis'/name,fixture/name)
(fixture/source.name).write_text(candidate,encoding='utf-8',newline='\n')
put(OP/'TIMING-DISCRIMINATOR-r02.frozen.json',{'source_sha256':sha(source),
 'isolated_fixture_sha256':sha(fixture/source.name),'only_change':'synthetic stalled-C phasecap .8 to5; assertions and production modules unchanged',
 'hypotheses':['H1 synthetic startup+16steps not guaranteed in .8 wall seconds; endpoint arbitrary earlier','H2 commit/pending/ownedtermination path broken even when enough pre-gate wall'],
 'science_effect':'zero original graph steps; no realstudy budget changed','frozen_utc':now()})
r=subprocess.run([str(PY),'-B','-X','utf8',str(fixture/source.name),'SupervisionChecks.test_actual_F_and_pending_C_interruptions'],cwd=fixture,capture_output=True,text=True,encoding='utf-8')
put(OP/'TIMING-DISCRIMINATOR-r02.actual.json',{'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'utc':now()})
print(r.stderr);assert r.returncode==0
put(OP/'TIMING-DIAGNOSIS.actual.json',{'status':'CAUSE_CONFIRMED_SCOPED','symptom':'pending-C expected tick16 but observed tick4 under .8sec deadline',
 'mechanism':'test assumes 16 fsynced synthetic steps fit fixed .8sec including process acquisition; supervisor may interrupt before gate',
 'root_condition':'timing-dependent synthetic fixture; no minimum host-throughput guarantee',
 'discriminator':'isolated same production bytes/assertions; only synthetic pending phasecap5; reaches16/PENDING and terminates with active0',
 'rules_out':'pending snapshot/owned termination always broken; does not prove why this host slower or all timing cases robust',
 'current_full_suite':'24pass/1timingfailure retained; not retrospectively25PASS',
 'original_test_actual':str(OP/'SELF-TEST.actual.json'),'synthetic_only':True})
print('PASS scoped timing discriminator; original full-suite failure retained')
