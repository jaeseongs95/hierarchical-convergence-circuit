from control import *
def canonical(o):return json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
task=read(OP/'TASK.json')
files=run(['git','diff','--name-only',BASE,'HEAD'],'final.changed-files').splitlines()
assert files and all(p.startswith(REL+'/') or p=='README.md' for p in files)
assert all(sha(REPO/p['path'])==p['sha256'] for p in read(OP/'source-pins.json'))
manifest=[{'path':p,'sha256':sha(REPO/p),'bytes':(REPO/p).stat().st_size} for p in files]
put(OP/'FINAL.manifest.json',manifest)
target='sha256:'+hashlib.sha256(canonical(manifest)).hexdigest()
delivery=read(OP/'results.delivery.json');head=run(['git','rev-parse','HEAD'],'final.head').strip();assert head==delivery['head']
assert not run(['git','status','--porcelain'],'final.clean').strip()
assert read(OP/'OFFLINE-VERIFICATION.actual.json')['status']=='PASS'
assert read(OP/'results.scope.json')['verdict']=='PASS'
assert read(OP/'EXECUTION-END.actual.json')['supervision']['active_processes']==0
facts=[(PUB/'execution-contract.json',['AC-001'],'Exact source, input/world rules,6coldcells, physicalphase/global budgets/metrics frozen before first scientificcell in signed pushedce1a6d4'),
 (PUB/'deliberation-summary.json',['AC-001'],'Two blind failurefunctions/cross-examination/rootintegration; unknownmodel/partialassurance; no Judge or formal evalgate claim'),
 (PUB/'pre-execution-verification.json',['AC-001','AC-004'],'Actualcurrentoriginalselftest24pass1timingfailure plusisolateddiscriminatorPASS; no productionpin/sciencebudgetchange; nestedJobs actualtestPASS'),
 (OP/'EXECUTION-START.actual.json',['AC-002'],'One explicit boundedscientific launch, no closedR081resume or automaticretry'),
 (OP/'EXECUTION-END.actual.json',['AC-002','AC-004'],'Outerownedtree termination/accounting actual; inactive0 and realphysicalwall/overrun preserved'),
 (PUB/'comparison.json',['AC-002','AC-003','AC-004'],'Six plannedslots retained includingmeasurementfailure; originalsealed eval plus independent Fraction diagnostic/distance/BFS/denominator/phaseledger'),
 (OP/'OFFLINE-VERIFICATION.actual.json',['AC-003','AC-005'],'Current exactsourcepins/seals/hash/contiguoustick/completecounters independentlychecked; missingunacknowledgedstate neverpromoted'),
 (OP/'OBSERVER-INTERVENTION.actual.json',['AC-002','AC-004'],'180/L atomicrenamefailure preserved; observer mutable-read intervention disclosed; laterenumeration-only, no scientificretry'),
 (OP/'SHARING-DISCRIMINATOR-r02.actual.json',['AC-004'],'Owned isolated target heldopen givesWinError5; closedhandlepermitsrename; exactactualreaderunknown; initialshare7assumptionfailure retained'),
 (PUB/'raw-manifest.json',['AC-002','AC-005'],'Archive CRC+all originalbyte/hashinventory verified; firstfailures andpost-experiment raw source preserved'),
 (PUB/'report.ko.md',['AC-003'],'All6rows andpairedpolicycomparison, conditionalaccuracy/coverage/budget; no generalaccuracy/adoption/fullEngine/independentdiscovery claim'),
 (OP/'results.scope.json',['AC-005'],'Current declarednew evidence/README scopePASS; excluded/unplanned/preexistingoverlap0'),
 (OP/'freeze.verify-signature.json',['AC-005'],'ActualOpenPGP freeze unit Goodsignature before mainFF/push'),
 (OP/'results.verify-signature.json',['AC-005'],'ActualOpenPGP resultsunit Goodsignature beforemainFF/push'),
 (OP/'results.delivery.json',['AC-005'],'Ordinarypush actualremotehead and changedfilesrawbytes exact, mainclean/localworkbranchdeleted')]
evidence=[]
for p,ids,message in facts:
    assert p.is_file()
    if p.name.endswith('verify-signature.json'):
        rr=read(p);assert rr['exit_code']==0 and 'Good signature' in rr['stderr']
    evidence.append({'id':'E'+str(len(evidence)+1),'kind':'document','locator':str(p),'digest':'sha256:'+sha(p),'targetDigest':target,
      'verified':True,'criterionIds':ids,'direction':'supports','observedResult':message})
request={'schemaVersion':'1.0.0','taskEnvelope':task,'target':{'kind':'commit','identifier':head,'digest':target},
 'evidence':evidence,'verificationCommands':[],'criterionOverrides':[],
 'knownLimitations':['6cellattempts not6successfulmeasurements;180/L measurementfailure, no scientificretry; fixedall6denominator',
 'Originalselftestcurrent24PASS1timingfailure preserved, not25PASS; isolated5secsyntheticpendingdiscriminatorPASS notsciencebudgetchange',
 'ObserverreadcouldcauseWinError5; exactreader/AVnotidentified; mutableack/progressreadsremoved afterfirstfailure; sameproductionpins',
 'one knowngraph andallopenauthoredsyntheticworld; no negatives/generalaccuracy/statisticalreplication; fixedorderhostload uncontrolled',
 'adoption/fullEngine/proof/D_DAG/energy/RSS NOT_MEASURED; sharednumericchecker/trustedoldanchor, no independentwholeprefixreplay',
 '2blindperspectives/cross/rootintegrationpartiallyindependent actualmodelUNKNOWN; postresultreuse notfreshJudge/OSattestation',
 'Budgetinterrupt/physicaloverrun/partialunknown distinguished; globalwatchdog nohardrealtime guarantee',
 'DotoriginalanswerNOT_OBSERVED withinrecentturnreadcoverage; getstatusunknown notproofabsence; no duplicaterequest']}
put(OP/'ACCEPTANCE.request.json',request)
tool=SK/'acceptance-evidence-validator/scripts'
report=json.loads(run(['node',tool/'cli.mjs','--input',OP/'ACCEPTANCE.request.json'],'ACCEPTANCE-RUN'))
put(OP/'ACCEPTANCE.actual.json',report);assert report['verdict']=='PASS',report
pin={'artifactId':'termination-sixcell-acceptance-'+head[:8],'schemaId':'https://agent-governance-skills.local/acceptance-evidence-validator/contracts/acceptance-evidence-input.v1.schema.json',
 'locator':str(OP/'ACCEPTANCE.request.json'),'digest':'sha256:'+hashlib.sha256(canonical(request)).hexdigest()}
put(OP/'ACCEPTANCE.request-pin.json',pin)
check=json.loads(run(['node',tool/'validate-report.mjs','--request',OP/'ACCEPTANCE.request.json','--request-artifact',OP/'ACCEPTANCE.request-pin.json','--report',OP/'ACCEPTANCE.actual.json'],'ACCEPTANCE-VALIDATE-RUN'))
put(OP/'ACCEPTANCE-VALIDATE.actual.json',check);assert check['valid']
print(json.dumps({'verdict':'PASS','valid':True,'criteria':5,'head':head,'sourcecode_changed':False}))
