"""종료 뒤 원봉인/정수·유리수로 독립 재집계. 궤적·인증 재실행 없음."""
from control import *
from fractions import Fraction as Q
import re, zipfile

LABELS=['180/L','180/F','180/C','1800/C','1800/F','1800/L']
EXCLUDED={'MEASUREMENT_FAILURE','CLEANUP_NOT_CONFIRMED','NOT_RUN','INCONCLUSIVE'}
def canonical(o):return json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def hd(o):return hashlib.sha256(canonical(o)).hexdigest()
def linked(ref):
    p=Path(ref['path']);assert sha(p)==ref['sha256'];return read(p)
def box(encoded):
    assert len(encoded)==7 and all(len(x)==2 for x in encoded)
    b=[tuple(Q(v) for v in pair) for pair in encoded]
    assert all(-1<=lo<=hi<=1 for lo,hi in b)
    return b
def diagnostic(encoded):
    lo,hi=box(encoded)[6]
    lower=max(Q(0),lo,-hi);upper=max(abs(lo),abs(hi))
    v=(True if lo>=0 else False if hi<0 else None) if lower>=Q.from_float(.30) else None
    return {'candidate':v,'margin_x_interval':[str(lower),str(upper)],'coverage_required':v is False,'adopted_value':'NOT_MEASURED'}
def distance(current,anchor):
    b,a=box(current),[tuple(Q(v) for v in p) for p in anchor]
    lower=max(max(Q(0),lo-ah,al-hi) for (lo,hi),(al,ah) in zip(b,a))/2
    upper=max(max(abs(lo-ah),abs(hi-al)) for (lo,hi),(al,ah) in zip(b,a))/2
    return {'lower_p_exact':str(lower),'upper_p_exact':str(upper),'status':'INSIDE' if upper<=Q(1,1000000) else 'OUTSIDE' if lower>Q(1,1000000) else 'AMBIGUOUS'}
def delta(b,a):
    return (max(max(Q(0),lo-ah,al-hi) for (lo,hi),(al,ah) in zip(b,a))/2,
            max(max(abs(lo-ah),abs(hi-al)) for (lo,hi),(al,ah) in zip(b,a))/2)
def legacy_check(tick,current,history,stable):
    low,high=delta(current,history[-1]);tol=Q.from_float(1e-6)
    if high<=tol:stable+=1
    elif low>tol:stable=0
    else:raise AssertionError('ambiguous L residual cannot have committed ordinary legacy detail')
    status=None
    if tick%16==0:
        if stable>=4:
            gl,gh=current[6];marginlow=max(Q(0),gl,-gh);marginhigh=max(abs(gl),abs(gh))
            assert marginlow>=Q.from_float(.30) or marginhigh<Q.from_float(.30)
            status='stable_decision' if marginlow>=Q.from_float(.30) else 'stable_ambiguous'
        elif len(history)>=2:
            two=delta(current,history[-2])
            if low>10*tol and two[1]<tol:status='oscillating'
            else:assert high<=10*tol or two[0]>=tol
    return stable,{'stable_steps':stable,'residual_p_interval':[str(low),str(high)],'checked':tick%16==0,'status':status}
def reachable(obs,truth,allowed=None):
    ids={e['id'] for e in obs['edges']};assert set(truth)==ids and all(type(v)is bool for v in truth.values())
    reached={obs['start']}
    while True:
        nxt=reached|{e['target'] for e in obs['edges'] if e['source'] in reached and truth[e['id']] and (allowed is None or e['id'] in allowed)}
        if nxt==reached:return obs['goal'] in reached
        reached=nxt
def model_of(public):
    order=['e:0','e:1','e:2','e:3','p:0:0','p:0:1','goal']
    program=public['program'];kernel=public['kernel'];lift=lambda v:Q.from_float(float(v))
    assert [g['id'] for g in program['groups']]==order and lift(kernel['temperature'])==1
    bias=[lift(g['bias'])+Q(public['drives'].get(g['id'],'0')) for g in program['groups']]
    matrix=[[Q(0) for _ in order] for _ in order]
    for link in program['links']:
        assert link['kind'] in ('support','top_down')
        matrix[order.index(link['target'])][order.index(link['source'])]+=lift(link['weight'])
    for i in range(7):matrix[i][i]+=(lift(kernel['self_excitation'])+lift(kernel['inhibition']))/2
    return {'b':list(map(str,bias)),'G':[list(map(str,row)) for row in matrix],'d':str(lift(kernel['damping']))}
def totals(rows,denom):
    assessed=[r for r in rows if r['eligible']]
    answered=[r for r in assessed if r['candidate'] is not None]
    correct=sum(r['candidate_correct'] is True for r in answered)
    return {'planned':denom,'attempted':sum(r['released'] for r in rows),'evaluable':len(assessed),'answered':len(answered),'correct':correct,
      'conditional_accuracy':correct/len(answered) if answered else None,
      'candidate_coverage':len(answered)/denom,'correct_over_planned':correct/denom,
      'raw_candidates':sum(r['candidate'] is not None for r in rows)}
def main():
    end=read(OP/'EXECUTION-END.actual.json');assert end['supervision'].get('active_processes')==0,'freeze no live tree before analysis'
    for ref in read(OP/'source-pins.json'):assert sha(REPO/ref['path'])==ref['sha256'],ref
    out=OP/'study';summary=read(out/'summary.json') if (out/'summary.json').exists() else None
    progress=read(out/'progress.json') if (out/'progress.json').exists() else {'rows':[]}
    source_rows=(summary or progress)['rows'];assert len({r['cell'] for r in source_rows})==len(source_rows)
    assert all(r['cell'] in LABELS for r in source_rows)
    bylabel={r['cell']:r for r in source_rows}
    setup=read(out/'setup/supervision.json');public=read(out/'setup/public-input.json');world=read(out/'setup/world.json')
    inputsha=sha(out/'setup/public-input.json')
    assert setup['status']=='COMPLETE' and setup['active_processes']==0
    assert hd(model_of(public['public']))==public['model_digest']
    obs=public['public']['observation'];processed=public['public']['processed']
    assert hd(obs)==public['observation_digest'] and hd(processed)==public['processed_digest']
    assert world['observation_digest']==public['observation_digest']
    truth=reachable(obs,world['truth']);p_truth=reachable(obs,world['truth'],{e for p in processed['paths'] for e in p})
    rows=[];checks=[];common_states={};common_state_comparisons=0
    for label in LABELS:
        folder=out/label.replace('/','-');r=bylabel.get(label,{'cell':label,'status':'NOT_RUN'})
        p=r.get('policy_supervision');sealed=read(folder/'sealed-cell.json') if (folder/'sealed-cell.json').exists() else None
        if p is None and (folder/'supervision.json').exists():p=read(folder/'supervision.json')
        row={'cell':label,'policy':label.split('/')[1],'budget_seconds':int(label.split('/')[0]),'status':r['status'],
          'released':bool(p and p.get('released')),'eligible':False,'tick':None,'stop_reason':'NOT_RUN',
          'candidate':None,'candidate_correct':None,'distance_status':'NOT_EVALUATED',
          'certificate':'NO_FINAL_CERTIFICATE' if label.endswith('/C') else 'NOT_REQUESTED',
          'coverage_required':None,'adopted_value':'NOT_MEASURED','policy_wall_seconds':p.get('wall_seconds_after_report',p.get('wall_seconds')) if p else None,
          'policy_tree_cpu_seconds':p.get('tree_cpu_seconds') if p else None,
          'policy_peak_committed_bytes':p.get('peak_job_committed_bytes') if p else None,
          'policy_active_processes':p.get('active_processes') if p else None,
          'policy_termination_overrun_seconds':p.get('termination_overrun_seconds') if p else None,
          'cell_wall_seconds':r.get('cell_wall_seconds'),'cell_envelope_exceeded':r.get('cell_envelope_exceeded'),
          'counts':None,'counts_scope':'unknown if no committed snapshot; interrupted work not zero',
          'evaluation_wall_seconds':None,'evaluation_cpu_seconds':None,'evaluation_status':None}
        if p:
            assert p['job_memory_limit_bytes']==536870912 and p['job_limit_flags']==0x2200
            assert p['start_monotonic']>=setup['finished_monotonic']
        if sealed:
            assert sealed['input_sha256']==inputsha
            assert sealed['model_digest']==public['model_digest'] and sealed['processed_digest']==public['processed_digest']
            state=sealed['last_complete'];final=sealed['final']
            if state:
                ack,snapshot=state['ack'],state['snapshot'];assert sha(folder/ack['path'])==ack['sha256']
                assert read(folder/ack['path'])==snapshot and ack['tick']==snapshot['tick']
                assert ack['completed_monotonic']<=p['deadline_monotonic']
                assert snapshot['tick']==snapshot['counters']['real_map_steps']
                assert snapshot['counters']['real_coordinate_updates']==7*snapshot['tick']
                assert snapshot['counters']['interval_matrix_terms']==49*snapshot['tick']
                dg=diagnostic(snapshot['current_x_box']);assert dg==snapshot['diagnostic']
                row.update(tick=snapshot['tick'],candidate=dg['candidate'],coverage_required=dg['coverage_required'],
                    counts=final['counters'] if final and 'counters' in final else snapshot['counters'],
                    counts_scope='final completed counters' if final else 'last committed lower bound; interrupted uncommitted work unknown')
                # Immutable sequential ticks are checked without rerunning the nonlinear map.
                states=sorted(folder.glob('state-*.json'));ticks=[];legacy_history=[];stable=0;last_legacy=None
                for path in states:
                    # A killed writer may leave a truncated unacknowledged state; preserve it,
                    # but never parse/promote it as a fully committed state.
                    if int(path.name[6:12])>ack['tick']:continue
                    item=read(path);box(item['current_x_box']);assert path.name==f"state-{item['tick']:06d}.json"
                    if item['tick'] in common_states:
                        assert item['current_x_box']==common_states[item['tick']]
                        common_state_comparisons+=1
                    else:common_states[item['tick']]=item['current_x_box']
                    assert diagnostic(item['current_x_box'])==item['diagnostic']
                    if item['tick']==0:assert all(lo==hi==0 for lo,hi in box(item['current_x_box']))
                    if row['policy']=='L':
                        current=box(item['current_x_box'])
                        if item['tick']:
                            stable,last_legacy=legacy_check(item['tick'],current,legacy_history,stable)
                            assert last_legacy==item['legacy']
                        legacy_history=(legacy_history+[current])[-2:]
                    if item['tick']<=ack['tick']:ticks.append(item['tick'])
                assert ticks==list(range(ack['tick']+1))
                if final and row['policy']=='L' and final['stop_reason']!='TICK_CAP':assert final['stop_reason']==last_legacy['status']
                checks.append({'cell':label,'committed_ticks_checked':len(ticks),'later_files_not_promoted':len(states)-len(ticks)})
            if final:
                assert p['status']=='COMPLETE' and final['last_complete']==state['ack']
                row['stop_reason']=final['stop_reason'];row['certificate']='CERTIFIED' if final['stop_reason']=='CERTIFIED' else final.get('last_gate_status','NOT_REQUESTED')
            else:row['stop_reason']=p['status']
            ei=read(folder/'evaluation-input.json') if (folder/'evaluation-input.json').exists() else None
            es=r.get('evaluation_supervision');e=r.get('evaluation')
            if es:
                row.update(evaluation_wall_seconds=es.get('wall_seconds_after_report',es['wall_seconds']),
                    evaluation_cpu_seconds=es.get('tree_cpu_seconds'),evaluation_status=es['status'])
            if e is not None:
                assert es and es['status']=='COMPLETE' and es['active_processes']==0
                assert ei and sha(folder/'sealed-cell.json')==ei['policy_seal']['sha256']
                assert linked(ei['public_input'])==public and linked(ei['world'])==world
                assert read(folder/'evaluation/result.json')==e
                assert e['full_public_truth']==truth and e['processed_path_truth']==p_truth
                assert e['candidate']==row['candidate'] and e.get('tick')==row['tick']
                assert e['candidate_correct']==(None if row['candidate'] is None else row['candidate']==truth)
                row['candidate_correct']=e['candidate_correct']
                row['eligible']=r['status'] not in EXCLUDED
                if state:
                    ref=ei['distance_reference'];rp=REPO/ref['path'];assert sha(rp)==ref['sha256'] and rp.stat().st_size==ref['bytes']
                    anchor=read(rp)['independent_verification'];assert anchor['model_digest']==public['model_digest'] and anchor['accepted'] is True
                    dist=distance(state['snapshot']['current_x_box'],anchor['anchor']['x_box_exact']);assert dist==e['distance']
                    row.update(distance_status=dist['status'],distance_lower_p_exact=dist['lower_p_exact'],distance_upper_p_exact=dist['upper_p_exact'])
                if final and final['stop_reason']=='CERTIFIED':assert e.get('local_certificate_recheck')=='PASS_shared_pinned_numeric_helpers'
        rows.append(row)
    overall=totals(rows,6);budgets={str(b):totals([r for r in rows if r['budget_seconds']==b],3) for b in (180,1800)}
    policies={a:totals([r for r in rows if r['policy']==a],2) for a in 'LFC'}
    if summary:
        for b,v in budgets.items():
            s=summary['by_budget'][b]
            assert (s['evaluable'],s['answered'],s['correct'],s['conditional_accuracy'],s['answer_coverage_over_planned'])==(v['evaluable'],v['answered'],v['correct'],v['conditional_accuracy'],v['candidate_coverage'])
    result={'schema':'HCCTerminationSixCellIndependentComparison.v1','status':'OFFLINE_SOURCE_VERIFIED',
      'execution_contract_sha256':sha(PUB/'execution-contract.json'),'source_pins_unchanged':True,
      'public_input_sha256':inputsha,'world_sha256':sha(out/'setup/world.json'),'model_digest':public['model_digest'],
      'full_public_truth':truth,'processed_path_truth':p_truth,'overall':overall,'by_budget':budgets,'by_policy_across_two_budgets':policies,
      'rows':rows,'sequential_checks':checks,'equal_full7_states_at_common_ticks':common_state_comparisons,
      'unique_sequential_ticks':len(common_states),'setup_supervision':setup,'outer_end':end,
      'global_summary_present':summary is not None,'global_summary_seal':read(out/'summary-seal-observation.json') if (out/'summary-seal-observation.json').exists() else None,
      'study_reported_wall_seconds':summary.get('global_wall_seconds') if summary else None,
      'cost_units_combined':False,'energy':None,'rss_peak_bytes':None,
      'full_engine_accuracy':'NOT_ESTABLISHED','adoption':'NOT_MEASURED','independent_discovery_samples':0,
      'trust_limits':['no independent full-prefix nonlinear replay; pinned supplier and complete source-bound snapshots trusted','shared certificate arithmetic and trusted old6144 anchor','single selected graph/allopen syntheticworld/fixedorder/notstatisticalreplication'],
      'verification':'independent Fraction diagnostic/distance/L legacy and BFS world, same-tick full7 cross-arm equality, byte/hash/seal/count/chronology/denominator checks; no new science',
      'post_study_verification_cost':'common offline verification/archiving/report/Git delivery outside frozen setup/policy/evaluator/grace ledger, not charged to one arm'}
    put(PUB/'comparison.json',result)
    put(OP/'OFFLINE-VERIFICATION.actual.json',{'status':'PASS','comparison_sha256':sha(PUB/'comparison.json'),'cells':len(rows),'checks':checks,'raw_summary_aggregate_matches':summary is not None,'sourcepins_unchanged':True,'utc':now()})
    print(json.dumps({'overall':overall,'by_budget':budgets,'rows':[{k:r[k] for k in ('cell','status','tick','stop_reason','candidate','candidate_correct','distance_status','policy_wall_seconds')} for r in rows]},ensure_ascii=False))
if __name__=='__main__':main()
